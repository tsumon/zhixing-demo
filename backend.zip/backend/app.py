import copy
import importlib
import json
import os
from pathlib import Path
import secrets
import threading
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .store import Store
from .jobs import TaskQueue, TaskConflict
from .ontology import describe
from . import roles, integrations

ROOT = Path(__file__).resolve().parents[1]
MODULE_NAMES = ('knowledge','evaluation','essay','analytics','intervention')
MODULE_LABELS = dict(zip(MODULE_NAMES, ['教研知识库','检索评测','作文初评','学情问数','教学干预']))


def seed(role_id="principal"):
    from .demo_data import initial_modules, initial_receipt
    modules=roles.scope_modules(initial_modules(),role_id)
    state={'modules':modules,'persona_id':role_id,'persona_states':{},'persona_schema':3,'knowledge_views':{},'integrations':integrations.initial_state()}
    initial_receipt(state)
    return state


# The role layer also accepts small custom seed factories (e.g. schema repair).
# Only the application seed opts into the independently versioned content.
from .demo_data import enrich_workspace
seed.migrate_content=enrich_workspace


def create_app(data_dir=None, access_code=None):
    runtime = Path(data_dir or os.environ.get('DEMO_DATA_DIR',str(ROOT/'.runtime')))
    runtime.mkdir(parents=True,exist_ok=True)
    code_file = runtime/'access-code'
    code = access_code if access_code is not None else os.environ.get('DEMO_ACCESS_CODE')
    if code is None:
        if not code_file.exists():
            code_file.write_text(secrets.token_hex(4))
            code_file.chmod(0o600)
        code = code_file.read_text().strip()
    store = Store(runtime/'workspaces.sqlite3', seed)
    rate_lock = threading.Lock()
    rates = defaultdict(deque)
    @asynccontextmanager
    async def lifespan(application):
        jobs.start()
        try:
            yield
        finally:
            jobs.stop()

    app = FastAPI(title='知行 · 教育 AI 工作台', docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
    app.state.store = store

    @app.middleware('http')
    async def boundary(request:Request, call_next):
        try:
            if int(request.headers.get('content-length','0')) > 200_000:
                return JSONResponse({'detail':'内容超过 200 KB，请分批导入。'},status_code=413)
        except ValueError:
            return JSONResponse({'detail':'请求大小无效。'},status_code=400)
        if request.url.path.startswith('/api/'):
            # Read the actual body too: a missing Content-Length cannot bypass the cap.
            if request.method in ('POST','PUT'):
                body = await request.body()
                if len(body)>200_000:
                    return JSONResponse({'detail':'内容超过 200 KB，请分批导入。'},status_code=413)
            host = request.client.host if request.client else 'guest'
            header = request.headers.get('authorization','')
            identifier = 'ip:'+host
            if request.url.path != '/api/session' and header.startswith('Bearer '):
                try:
                    verified = store.load(header[7:])
                    identifier = 'session:'+verified['id']
                except KeyError:
                    pass
            now = time.monotonic()
            with rate_lock:
                q=rates[identifier]
                while q and now-q[0]>60:q.popleft()
                limit=120 if identifier.startswith('session:') else 30
                if len(q)>=limit:
                    return JSONResponse({'detail':'操作较频繁，请稍后再试。'},status_code=429)
                q.append(now)
                if len(rates)>1000:
                    stale=[k for k,v in rates.items() if not v or now-v[-1]>60]
                    for k in stale: del rates[k]
        response = await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='no-referrer'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'"
        if request.url.path.startswith('/api/'):response.headers['Cache-Control']='no-store'
        return response

    def token_of(request):
        header=request.headers.get('authorization','')
        if not header.startswith('Bearer '):raise HTTPException(401,'请先进入试用工作区。')
        return header[7:]

    def load(request):
        # GET may perform one-time migration too. Share the mutation lock with
        # POST, so a stale migrating GET cannot overwrite a successful action.
        with lock_for(request):
            try:
                state=store.load(token_of(request))
                expected=request.headers.get('x-demo-persona')
                if expected and request.url.path!='/api/persona' and expected!=state.get('persona_id','principal'):
                    raise HTTPException(409,'此工作区已在另一页面切换身份，请刷新当前身份后继续；本次操作未执行。')
                migrated=roles.migrate(state,seed)
                if 'integrations' not in state:
                    state['integrations']=integrations.initial_state()
                    migrated=True
                if migrated:store.save(state)
                return state
            except KeyError as exc:raise HTTPException(401,str(exc.args[0]))

    def lock_for(request):
        token_of(request)
        return store.transaction()

    @app.get('/api/health')
    def health():return {'ok':True,'service':'education-ai-demo','version':'1.4.0-demo','mode':'simulation','model_enabled':False}

    @app.get('/api/ready')
    def ready():
        try:
            store.ready()
        except Exception:
            return JSONResponse({'ok':False,'database':'unavailable','worker':'running' if jobs.running else 'stopped'},status_code=503)
        return JSONResponse({'ok':jobs.running,'database':'ready','worker':'running' if jobs.running else 'stopped'},status_code=200 if jobs.running else 503)

    @app.get('/api/access')
    def access():return {'code_required':bool(code),'model_enabled':False,'mode':'simulation'}

    @app.post('/api/session')
    def new_session(payload:dict):
        supplied=str(payload.get('code',''))
        if code and not secrets.compare_digest(supplied,code):raise HTTPException(403,'访问口令不正确。')
        try:token,wid=store.create()
        except ValueError as exc:raise HTTPException(429,str(exc))
        return {'token':token,'workspace_id':wid}

    @app.get('/api/bootstrap')
    def bootstrap(request:Request):
        state=load(request)
        return {'data':{'workspace_id':state['id'],'created_at':state['created_at'],
            'capabilities':{'model':False,'mode':'纯演示 · 零模型调用','synthetic_data':True,'simulation':True},
            'persona':roles.describe_personas(state)['current'],
            'module_counts':{k:len(v) for k,v in state['modules'].items()},
            'event_count':len(state['events']), 'model_calls':len(state['model_usage']),
            'last_events':state['events'][-8:]}}

    @app.get('/api/ontology')
    def ontology(request:Request):
        state=load(request)
        return {'data':roles.ontology_projection(state,describe(state))}

    @app.get('/api/persona')
    def get_persona(request:Request):return {'data':roles.describe_personas(load(request))}

    @app.post('/api/persona')
    def set_persona(payload:dict,request:Request):
        with lock_for(request):
            state=load(request)
            try:roles.switch(state,payload.get('id'),seed)
            except ValueError as exc:raise HTTPException(400,str(exc)) from None
            store.save(state)
            store.append_audit(state['id'],state['persona_id'],{'id':'audit-'+secrets.token_hex(8),'module':'workspace','action':'persona','status':'completed','at':time.time()})
        return {'data':{**roles.describe_personas(state),'workspace_id':state['id']}}

    @app.get('/api/admin')
    def get_admin(request:Request):
        try:return {'data':roles.admin_summary(load(request))}
        except PermissionError as exc:raise HTTPException(403,str(exc)) from None

    @app.post('/api/admin/reset')
    def admin_reset(request:Request):
        with lock_for(request):
            state=load(request)
            try:roles.reset_all(state,seed)
            except PermissionError as exc:raise HTTPException(403,str(exc)) from None
            store.save(state)
            store.append_audit(state['id'],state['persona_id'],{'id':'audit-'+secrets.token_hex(8),'module':'workspace','action':'reset_all','status':'completed','at':time.time()})
        return {'data':{'reset':True,'workspace_id':state['id'],'persona':roles.describe_personas(state)['current']}}

    @app.get('/api/todos')
    def todos(request:Request):
        from backend.todos import view
        return {'data':view(load(request))}

    @app.get('/api/events')
    def events(request:Request):
        state=load(request)
        return {'data':{'events':roles.audit_events(state),'model_usage':state['model_usage']}}

    @app.get('/api/audit')
    def audit(request:Request):
        state=load(request)
        return {'data':{'events':store.audit(state['id'],state['persona_id'])}}

    @app.get('/api/export')
    def export(request:Request):
        state=load(request)
        return JSONResponse({'format':'zhixing-demo-v1','synthetic_data':True,'simulation':True,'model_calls':0,'workspace':roles.export_current(state)},headers={'Content-Disposition':'attachment; filename="zhixing-workspace.json"'})

    @app.post('/api/reset')
    def reset(request:Request):
        with lock_for(request):
            state=load(request)
            roles.reset_current(state,seed)
            store.save(state)
            store.append_audit(state['id'],state['persona_id'],{'id':'audit-'+secrets.token_hex(8),'module':'workspace','action':'reset','status':'completed','at':time.time()})
        return {'data':{'reset':True,'workspace_id':state['id']}}

    def execute_operation(original, name, action, payload):
        # Shared by sync endpoints and the local queue; business handlers remain
        # unchanged, and no environment setting can enable a real provider.
        rid='run-'+secrets.token_hex(6)
        start=time.perf_counter()
        state=copy.deepcopy(original)
        result=None
        error_status=None
        error=None
        module=integrations if name=='integrations' else importlib.import_module('backend.modules.'+name)
        target=state if name=='integrations' else {'knowledge':state['modules']['knowledge'],'evaluation':state['modules']['evaluation']} if name=='evaluation' else state['modules'][name]
        try:
            if name=='analytics' or (name=='intervention' and action=='create_from_analysis'):
                from backend.modules.analytics import sync_essay_formal
                sync_essay_formal(state['modules']['analytics'],state['modules']['essay']['formal'])
            if name=='knowledge':
                from backend.modules.evaluation import _active_view
                target['active_policy']=_active_view(state['modules']['evaluation'],target)
                target['last_search']=copy.deepcopy(state.get('knowledge_views',{}).get(state['persona_id']))
            if name=='intervention' and action=='create_from_analysis':
                snapshot=state['modules']['analytics'].get('latest_verified_snapshot')
                if not snapshot:raise ValueError('请先在学情问数完成分析和复算检查，再创建干预方案。')
                if not isinstance(payload.get('snapshot_id'),str) or not payload['snapshot_id']:
                    raise ValueError('请刷新学情分析并核对结果后再交接：缺少分析快照编号。')
                current_plan=state['modules']['analytics'].get('plan') or {}
                if payload['snapshot_id']!=snapshot['snapshot_id'] or ('plan_id' in payload and payload['plan_id']!=current_plan.get('id')):
                    raise ValueError('这份分析已更新，请回到学情问数重新核对结果后再交接。')
                payload={**payload,'snapshot':copy.deepcopy(snapshot),'class_id':payload.get('class_id') or snapshot['rows'][0]['class_id']}
            if name!='integrations':payload=roles.authorize(state,name,action,payload)
            if name=='intervention' and action in {'create','create_from_analysis'} and payload.get('wiki_refs'):
                from backend.wiki_learning import references
                school=target['classes'][payload['class_id']]['school_id']
                kb=state['modules']['knowledge']
                payload['wiki_refs']=references(kb,payload['wiki_refs'],school)
                if any(r['version']!=kb['current_versions'][school] for r in payload['wiki_refs']):
                    raise ValueError('干预教学参考必须使用本校当前教材版本')
            # Product is deliberately demo-only. No environment setting or
            # request flag can enable an external model provider.
            result=module.handle(target,action,payload,model=None)
            if name=='knowledge':
                state.setdefault('knowledge_views',{})[state['persona_id']]=copy.deepcopy(target.get('last_search'))
                target['last_search']=None
            if name!='integrations':result=roles.project_result(state,name,result)
        except PermissionError as exc:
            error_status,error=403,str(exc)
        except (ValueError,TypeError,KeyError) as exc:
            error_status,error=400,str(exc)
        except Exception:
            error_status,error=500,'操作暂未完成，状态已回滚。'
        elapsed=round((time.perf_counter()-start)*1000,1)
        event={'id':rid,'module':name,'action':action,
            'status':('error' if error_status==500 else 'rejected') if error_status else 'completed',
            'at':time.time(),'duration_ms':elapsed,'actor_label':roles.current(original)['label']}
        record=next((result[key] for key in ('record','plan','document','delivery')
            if isinstance(result,dict) and isinstance(result.get(key),dict)),{})
        record_id=payload.get('id') or payload.get('source_id') or record.get('id')
        version=payload.get('version',record.get('version'))
        if isinstance(record_id,str):event['record_id']=record_id
        if isinstance(version,(str,int)):event['version']=version
        if error_status:
            state=original
            event['message']=error[:300]
        if action!='get' or error_status:
            state['events'].append(event)
            state['events']=state['events'][-300:]
        return state,result,event,error_status,error

    def dispatch(request, name, action, payload):
        if name not in (*MODULE_NAMES,'integrations'):raise HTTPException(404,'未找到这个工作台。')
        with lock_for(request):
            state,result,event,error_status,error=execute_operation(load(request),name,action,payload)
            if action!='get' or error_status:store.save(state)
        if error_status:raise HTTPException(error_status,error)
        return {'data':result,'request_id':event['id'],'duration_ms':event['duration_ms'],'simulation':True,'model_calls':0}

    jobs=TaskQueue(store,execute_operation,seed)
    app.state.jobs=jobs

    def task_action(request, operation):
        try:
            with lock_for(request):
                state=load(request)
                return {'data':operation(state)}
        except TaskConflict as exc:raise HTTPException(409,str(exc)) from None
        except PermissionError as exc:raise HTTPException(403,str(exc)) from None
        except KeyError as exc:raise HTTPException(404,str(exc.args[0])) from None
        except (ValueError,TypeError) as exc:raise HTTPException(400,str(exc)) from None

    @app.post('/api/tasks')
    def submit_task(payload:dict,request:Request):
        return task_action(request,lambda state:jobs.submit(state,payload))

    @app.get('/api/tasks')
    def list_tasks(request:Request):
        return task_action(request,lambda state:{'tasks':jobs.list(state)})

    @app.get('/api/tasks/{task_id}')
    def get_task(task_id:str,request:Request):
        return task_action(request,lambda state:jobs.get(state,task_id))

    @app.post('/api/tasks/{task_id}/retry')
    def retry_task(task_id:str,request:Request):
        return task_action(request,lambda state:jobs.retry(state,task_id))

    @app.post('/api/tasks/{task_id}/cancel')
    def cancel_task(task_id:str,request:Request):
        return task_action(request,lambda state:jobs.cancel(state,task_id))

    @app.get('/api/{module_name}')
    def get_module(module_name:str,request:Request):return dispatch(request,module_name,'get',{})

    @app.post('/api/{module_name}/{action}')
    def act(module_name:str,action:str,payload:dict,request:Request):
        if len(action)>50:raise HTTPException(400,'操作名无效。')
        return dispatch(request,module_name,action,payload)

    dist=ROOT/'frontend'/'dist'
    if (dist/'assets').exists():app.mount('/assets',StaticFiles(directory=dist/'assets'),name='assets')
    if (dist/'essay-samples').exists():app.mount('/essay-samples',StaticFiles(directory=dist/'essay-samples'),name='essay-samples')
    @app.get('/')
    def index():
        if not (dist/'index.html').exists():raise HTTPException(503,'前端尚未构建，请执行 npm run build。')
        return FileResponse(dist/'index.html')
    return app

app=create_app()
