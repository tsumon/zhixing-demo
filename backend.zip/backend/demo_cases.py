"""Curated, versioned synthetic teaching cases built through business handlers.

This catalog never calls a model, changes an existing record, or replaces a
visitor's current selection. IDs and historical timestamps are deterministic.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from uuid import NAMESPACE_URL, uuid5

SCAN_SAMPLES = {
    'garden-notes': {'id':'garden-notes','label':'观察日记原稿','title':'菜园里的第一片新叶','description':'连续观察与具体细节，核对后进入评阅','low_lines':[],
        'url':'./essay-samples/garden-notes.svg','text':'周一，我把一粒豆子埋进花盆，每天放学先去看看它。三天过去，土面还是原来的样子，我忍不住用手指拨开泥土。\n爸爸拦住我，说种子需要安静。我把花盆搬到窗边，在本子上记下浇水的时间，决定再等几天。\n周五清晨，泥土裂开了一条细缝，一弯淡绿的芽顶着土粒探出头来。它比我想象的小，却让我趴在窗台看了很久。\n后来我明白，观察不只是盼着结果，还要记住那些暂时看不出变化的日子。'},
    'bridge-walk': {'id':'bridge-walk','label':'游记原稿','title':'走过河上的老桥','description':'地点顺序与叙事线索，适合检查结构','low_lines':[],
        'url':'./essay-samples/bridge-walk.svg','text':'周末，外婆带我去河对岸买菜。旧石桥只容两个人并肩走，桥面被来往的脚步磨得发亮。\n走到桥中央，我想停下来拍照，后面有人推着一辆装满青菜的车。我侧身让路，外婆轻轻拉住我，让我站到石栏里面。\n卖菜的爷爷走过去时向我们点头。外婆说，她小时候每天都从这里上学，那时桥下还有摆渡的小船。\n回程时，我没有再急着拍照，而是慢慢听外婆讲那些与桥有关的人。照片能留下样子，同行的人却让我看见了桥的另一面。'},
    'library-return': {'id':'library-return','label':'校园叙事原稿','title':'最后一本归还的书','description':'人物动作与转折，准备教师独立评分','low_lines':[],
        'url':'./essay-samples/library-return.svg','text':'午休的图书角快关门了，我发现书包里还有一本该归还的书。封面右下角被我不小心折出了白痕。\n我在门口站了一会儿，想把书悄悄塞回书架。值日同学抬头看见我，问我是不是找不到借阅登记表。\n我把书递给她，指着折角说了经过。她拿出修补纸，让我先把翘起的边压平，再一起贴好。\n在登记表上写完名字，我才发现承认一件小错并没有想象中困难。那本书留下一道细细的补痕，也提醒我下次更仔细地对待借来的东西。'},
    'canteen-help': {'id':'canteen-help','label':'有疑字的原稿','title':'食堂门口的托盘','description':'两处识别存疑，确认后进入人工评阅','low_lines':[1,3],
        'url':'./essay-samples/canteen-help.svg','text':'中午下课，我端着托盘走到食堂门口，前面的低年级同学忽然停住了脚步。他的汤洒在地上，鞋尖也湿了一片。\n后面的队伍越来越长，他低着头不敢说话。我把自己的托盘放到旁边，先请后面的同学从另一边绕过去。\n值日老师拿来拖把，我陪着他重新盛了一碗汤。他小声说谢谢，仍然担心自己的饭凉了。\n我们找了靠窗的位置坐下。我发现，帮助别人有时不需要讲很多道理，先把眼前的小麻烦一起处理好就够了。'},
}
SCAN_SAMPLES['canteen-help']['ocr_text']=SCAN_SAMPLES['canteen-help']['text'].replace('队伍','队五').replace('道理','道里')

# Each text is an authored local fixture, not a generated grade or OCR claim.
TEXTS = {
 'relay':('接力赛后的掌声','接力赛轮到我时，前面的同学已经拉开了一点距离。我接过棒，刚跑两步就踩到了鞋带，差点跌倒。\n等我站稳，旁边的队伍已经超过我们。我听见场边有人喊我的名字，抬头看见同桌正挥着手，让我继续往前跑。\n最后我们没有拿到名次。回到队伍时，我准备道歉，大家却先递来水，问我的膝盖疼不疼。\n那天的掌声没有送给冠军，却让我知道，一次比赛的结果不是同伴之间最重要的事。'),
 'repair':('修好的小台灯','书桌上的台灯一闪一闪，我决定和爸爸一起找出原因。起初我只想赶快换一盏新的，爸爸却让我先把插头拔掉。\n我们检查了灯泡和开关，发现松动的是灯座旁的接线。爸爸处理线路，我负责扶住外壳，再把螺丝一颗颗装回去。\n台灯亮起来时，桌上的铅笔影子重新变得清楚。我把检查顺序写在纸上，才发现自己原来一直跳过最基本的观察。\n修好的不只是一盏灯。我学会在着急之前，先把问题拆成几个可以仔细检查的小步骤。'),
 'queue':('排队时的一句话','周末的公交站挤满了人，我和妈妈排在队伍后面。一位抱着小孩的阿姨提着两袋东西，站得很不稳。\n车门打开后，大家向前移动。我看见她腾不出手拿卡，便问能不能帮她提一袋东西，等上车再还给她。\n阿姨先看了看妈妈，才把轻一点的袋子递给我。上车后我站在扶手旁，等她抱稳孩子再把袋子放好。\n下车时，她隔着车窗朝我挥手。我记住的不是那句谢谢，而是开口询问后，陌生人之间也能建立一点安心。'),
 'debate':('一次没有输赢的讨论','班会讨论是否取消课间球类活动时，同学们很快分成了两边。我原本只准备强调运动的好处，没有想过走廊里被撞到的同学。\n对方发言后，我翻开记录，发现大家担心的是场地和秩序，并不是反对运动本身。我们试着把争论改成几个具体问题。\n最后，两个小组合写了一份建议：球类活动移到操场，器材由值日同学登记，雨天改为其他活动，一周后再听取反馈。\n这次讨论没有宣布谁获胜。比起守住原来的观点，找到能够共同试行的办法更有意义。'),
 'rainbow':('雨后的彩虹','傍晚，操场积水映着天空，我和妹妹等着雨停。她忽然指向教学楼上方，说那里有一道浅浅的彩虹。\n我举起手机，却怎么也拍不清楚。妹妹已经跑到屋檐外，一边数颜色，一边催我不要只看屏幕。\n我收起手机，和她站在同一个位置。风把云推开了一点，颜色也慢慢变淡了，我们只来得及看了几分钟。\n回家后我画下看到的样子，才发现自己记得的还有她湿掉的鞋和兴奋的声音。有些东西没有拍下来，也不会立刻消失。'),
 'key':('替邻居保管的钥匙','邻居奶奶出门前，把备用钥匙交给妈妈保管。那天下午只有我在家，门铃响时我一时不知道该不该直接开门。\n我先隔着门问清楚来人，又给妈妈打电话核对。奶奶听到我的解释，笑着说等一会儿没有关系。\n得到妈妈确认后，我才打开门，把钥匙交还。奶奶夸我记得约定，我也松了一口气。\n后来我把这件事记在日记里。帮忙不仅是动作快，还要把别人交托的事情想清楚、做稳妥。'),
 'team':('把海报贴上墙','小组的读书海报要在周五展示。我们一开始都想设计标题，等到最后一天，正文和图片却还散在不同人的本子上。\n组长把任务重新写在黑板上，我们按照整理内容、检查文字和排版装饰分成三组。我负责把重复的介绍合并，给图片补上说明。\n放学前，海报终于贴上了墙。标题没有最初想象中漂亮，内容却清楚得多，路过的同学也愿意停下来读。\n这一次我明白，合作不是每个人都做最喜欢的部分，而是有人愿意接住还没完成的事情。'),
 'reading':('书页旁的小问号','读到故事结尾时，我觉得主人公的选择很奇怪，便在旁边画了一个问号。老师没有立即解释，而是让我找出前面提到的一句话。\n我重新翻了几页，发现自己曾匆匆跳过一段对话。那段话不能回答所有疑问，却让我看见了人物犹豫的原因。\n小组讨论时，我把最初的判断和后来找到的证据一起说出来。同学指出另一个细节，我们的理解又发生了一点变化。\n现在，我仍会在书页旁留下问号。它们提醒我，读懂一个故事需要回到文字里，也需要给别人的解释留一点位置。'),
 'market':('清晨的菜市场','周日清晨，我跟着父亲去买菜。菜市场里最先传来的不是叫卖声，而是推车轮子越过石缝时的响声。\n卖豆腐的阿姨用细线把豆腐分成整齐的小块，旁边的爷爷把青菜叶上的水轻轻抖掉。父亲问过价钱，又挑了一把大小不同的胡萝卜。\n我问为什么不选一样长的，父亲说做汤不需要它们长得完全相同。我看着袋子里弯弯曲曲的胡萝卜，忽然觉得有趣。\n回家的路上天已经亮了。我记住了那些手上的动作，也第一次留意到，一顿普通的早饭之前有这么多人认真地忙碌。'),
 'ferry':('渡口边的等候','去探望亲戚时，我们在渡口等船。风把水面吹出细密的波纹，广播说船要晚十分钟到达。\n我不断看时间，爷爷却指着岸边，让我观察系船绳怎样随着水位一点点移动。他说，着急不会让水流变慢，也不会让船更早靠岸。\n船到时，工作人员先扶老人和孩子上去。我站在队伍里，终于没有再催促，只帮爷爷扶稳手里的袋子。\n那十分钟并没有发生什么大事，却让我在一次普通的等候中学会看见周围的人，也学会尊重他们需要的时间。'),
 'map':('画给新同学的地图','新同学第一天到校，总是找不到科学教室。我想带他走一遍，却发现自己习惯的那条小路经过一段正在维修的楼梯。\n我们在教学楼前停下，重新看了指示牌。我拿出纸，把安全的路线画成几条直线，再标上饮水处和楼梯的位置。\n第二天，他照着地图找到了教室，还在纸上补了一处我漏掉的转角。我们把修改后的地图贴在班级信息栏里。\n画地图这件小事让我明白，给别人指路时，不能只想着自己知道什么，还要想想对方第一次站在这里会遇到什么。'),
}


def stable_id(key):
    return str(uuid5(NAMESPACE_URL,'zhixing-content-v7:'+key))


def _replace(value, mapping):
    if isinstance(value,dict):return {k:_replace(v,mapping) for k,v in value.items()}
    if isinstance(value,list):return [_replace(v,mapping) for v in value]
    return mapping.get(value,value) if isinstance(value,str) else value


def _at(index, step=0):
    return (datetime(2026,10,24,8,tzinfo=timezone.utc)+timedelta(days=index,minutes=step)).isoformat()


def _essay_catalog():
    from backend.modules import essay
    state=essay.initial_state()
    # All unfinished teacher work belongs to the available 7A demo account.
    specs=[('repair','7A',9,'practice','published',(5,3,5)),('queue','7A',10,'practice','published',(5,3,4)),
        ('debate','7A',11,'formal','published',(5,4,5)),('team','7B',1,'practice','published',(5,5,4)),
        ('reading','7B',2,'formal','published',(4,5,5)),('market','8A',1,'practice','published',(5,5,5)),
        ('ferry','8A',2,'formal','published',(4,4,5)),('rainbow','7A',12,'practice','withdrawn',(4,4,5)),
        ('key','7A',8,'practice','approved',(4,4,5)),('map','7A',7,'formal','awaiting_approval',(4,3,5)),
        ('relay','7A',6,'practice','third_required',(3,3,3)),('library-return','7A',4,'practice','awaiting_second',(4,4,4)),
        ('canteen-help','7A',5,'practice','manual',(4,4,4)),('bridge-walk','7A',3,'practice','awaiting_ai',(4,4,4)),
        ('rain-clear','7A',1,'practice','awaiting_correction',(4,4,4)),('garden-notes','7A',2,'practice','awaiting_correction',(4,4,4))]
    for index,(slug,cls,student,kind,target,scores) in enumerate(specs):
        key='v7:essay:'+slug
        sample=essay.SAMPLES.get(slug)
        title,body=(sample['title'],sample.get('text',essay.SAMPLE)) if sample else TEXTS[slug]
        payload={'title':title,'class_id':cls,'student_id':f'{cls}-S{student:02}','assessment_type':kind,'assignment':'秋季叙事习作 · '+('单元测评' if kind=='formal' else '课堂练习')}
        payload.update(source={'kind':'sample','sample_id':slug}) if sample else payload.update(source={'kind':'text'},text=body)
        essay.handle(state,'create',payload)
        row=state['records'][-1];old_id=row['id'];row['id']=stable_id(key);row['seed_key']=key
        row['history'][0]['object_id']=row['id']
        def act(action,**values):return essay.handle(state,action,{'id':row['id'],'version':row['version'],'actor':'teacher-a',**values})
        if target!='awaiting_correction':
            act('confirm_text',text=body,confirmed_line_ids=[line['id'] for line in row['correction']['lines'] if line['needs_review']])
            if target not in {'manual','awaiting_ai'}:
                act('score')
                if target!='awaiting_second':
                    dimensions=dict(zip(('内容','结构','语言'),scores));score=sum(scores)
                    act('second',score=score,dimensions=dimensions,reason=f'合成独立评阅：结合《{title}》的事件细节、段落承接和原文表达逐项评分。')
                    if target!='third_required':
                        if row['state']=='third_required':act('third',actor='teacher-b',score=score,dimensions=dimensions,reason='合成教研复核：独立重读原稿，逐维度核对后保留本次评分，并提供具体修改建议。')
                        if target!='awaiting_approval':
                            if row['state']=='awaiting_approval':act('approve',actor='lead',score=score,dimensions=dimensions,reason='已核对独立复核与当前原稿版本，确认本次正式成绩。')
                            if target!='approved':
                                act('release',actor='lead' if kind=='formal' else 'teacher-a',key=key+':publish')
                                if target=='withdrawn':act('withdraw',reason='核对发现末段漏录一句话，先撤回成绩，等待任课教师更正原稿并重新评阅。')
        assert row['state']==target,(slug,row['state'],target)
        mapping={old_id:row['id'],row['created_at']:_at(index)}
        for step,event in enumerate(row['history']):
            event['synthetic']=True;event['seed_key']=key+':event:'+str(step)+':'+event['action'];mapping[event['id']]=stable_id(event['seed_key']);mapping[event['at']]=_at(index,step)
        if row.get('approval'):mapping[row['approval']['id']]=stable_id(key+':decision')
        if row.get('correction',{}).get('confirmed_at'):mapping[row['correction']['confirmed_at']]=_at(index,1)
        for confirmation in row['confirmation_history']:mapping[confirmation['at']]=_at(index,1)
        for grade in state['formal']:
            if grade['essay_id']!=row['id']:continue
            grade['seed_key']=key+':publication:'+str(grade['approved_version']);mapping[grade['id']]=stable_id(grade['seed_key']);mapping[grade['published_at']]=_at(index,len(row['history'])-1)
            if grade.get('withdrawn_at'):mapping[grade['withdrawn_at']]=_at(index,len(row['history']))
        state=_replace(state,mapping)
    return state


def extra_task_events():
    """Append two paired windows; the established W42-W44 facts remain intact."""
    from backend.modules import analytics
    totals={'7A':[(20,20,18,16,6),(20,19,18,4,8)],'7B':[(4,4,4,4,2),(4,4,4,4,2)],'8A':[(8,8,8,6,6),(8,8,8,8,4)]}
    sizes={'7A':100,'7B':20,'8A':40};result=[]
    for cls in analytics.CLASSES:
        for window,period in enumerate(('2026-W45','2026-W46')):
            monday=datetime.fromisocalendar(2026,int(period[-2:]),1).replace(tzinfo=timezone.utc)
            for optional,count in ((0,sizes[cls['id']]),(1,10 if cls['id']=='7A' else 4)):
                for index in range(count):
                    task=index%5+1;student=index//5+1
                    done=student<=totals[cls['id']][window][task-1] if not optional else index<2
                    late=cls['id']=='7A' and window==1 and not optional and task==4
                    prefix=f"v7:task:{cls['id']}:{period}:{optional}:{index}"
                    row={'seed_key':prefix+':1','id':stable_id(prefix+':1'),'attempt_id':stable_id(prefix+':1'),
                        'school_id':cls['school_id'],'class_id':cls['id'],'student_id':f"{cls['id']}-S{student:02}",'task_id':f"{'O' if optional else 'R'}-{task}",
                        'period':period,'completed':int(done),'optional':optional,'grade':cls['grade'],'knowledge_id':'linear' if task==5 else cls['knowledge_id'],
                        'existing_minutes':cls['existing_minutes'],'task_title':('选做：' if optional else '')+['基础概念','计算巩固','应用练习','综合练习','方程衔接'][task-1],
                        'published_at':(monday+(timedelta(days=4,hours=8) if late else timedelta(hours=9))).isoformat(),
                        'due_at':(monday+timedelta(days=6 if late else 4,hours=18)).isoformat(),'observed_at':(monday+timedelta(days=4,hours=20)).isoformat(),
                        'difficulty_level':2 if window==1 and task==5 and not optional else 1}
                    result.append(row)
                    if not optional and index<6 and done:result.append({**row,'seed_key':prefix+':2','id':stable_id(prefix+':2'),'attempt_id':stable_id(prefix+':2')})
    return result


def _snapshot(a,question,label,**conditions):
    from backend.modules import analytics
    from backend.vendor.intervention_core import digest
    plan=analytics.handle(a,'plan',{'question':question,**conditions});report=analytics.handle(a,'run',{'plan_id':plan['id']})
    snapshot=deepcopy(report['snapshot']);raw=report['raw_snapshot']
    if isinstance(raw,dict) and 'snapshot_id' in raw:
        old_hash=raw['source_hash'];raw.update(snapshot_id=stable_id(label+':raw'),captured_at='2026-11-13T20:00:00+00:00')
        raw['source_hash']=digest({k:v for k,v in raw.items() if k!='source_hash'});snapshot=_replace(snapshot,{old_hash:raw['source_hash']})
    snapshot.update(snapshot_id=stable_id(label),captured_at='2026-11-13T20:00:00+00:00')
    snapshot['source_hash']=digest({k:v for k,v in snapshot.items() if k!='source_hash'})
    return snapshot


def _intervention_catalog(essays,events):
    from backend.modules import analytics,intervention
    a=analytics.initial_state();a.update(events=analytics._events()+events,allowed_classes=['7A','7B','8A'],default_classes=['7A'])
    analytics.sync_essay_formal(a,essays['formal'])
    snapshots={
        'practice':_snapshot(a,'7A已发布练习作文薄弱维度','v7:snapshot:practice',class_ids=['7A'],assessment_type='practice'),
        'formal':_snapshot(a,'7A已发布正式作文成绩','v7:snapshot:formal',class_ids=['7A'],assessment_type='formal'),
        'timing':_snapshot(a,'7A作业完成率变化','v7:snapshot:timing',class_ids=['7A'],baseline_period='2026-W45',current_period='2026-W46'),
        'improvement':_snapshot(a,'7A作业完成率变化','v7:snapshot:improvement',class_ids=['7A'],baseline_period='2026-W44',current_period='2026-W45'),
        'stable':_snapshot(a,'7B作业完成率变化','v7:snapshot:stable',class_ids=['7B'],baseline_period='2026-W45',current_period='2026-W46'),
        'linear':_snapshot(a,'8A作业完成率变化','v7:snapshot:linear',class_ids=['8A'],baseline_period='2026-W44',current_period='2026-W45')}
    specs=[('structure','7A','practice','作文结构互评小组','awaiting_teacher',2,10,'classroom'),
        ('formal-room','7A','formal','正式测评作文反馈会','awaiting_lead',1,0,'shared_room'),
        ('window-ready','7A','timing','综合练习补交窗口核对','ready',2,0,'classroom'),
        ('window-active','7A','timing','任务发布时间核查','executed',2,0,'classroom'),
        ('fraction-complete','7A','improvement','分数应用题回看','completed',6,10,'classroom'),
        ('stable-complete','7B','stable','稳定班级常规反馈','completed',4,0,'classroom'),
        ('room-revoked','7A','improvement','跨班资源调配变更','revoked',8,10,'shared_room'),
        ('linear-stopped','8A','linear','方程衔接答疑复盘','completed',4,10,'classroom')]
    state=intervention.initial_state()
    for index,(slug,cls,source,title,target,participants,minutes,delivery) in enumerate(specs):
        key='v7:intervention:'+slug
        intervention.handle(state,'create_from_analysis',{'snapshot':snapshots[source],'class_id':cls,'title':f'{cls} · {title}', 'participants':participants,'new_minutes':minutes,'delivery_mode':delivery})
        p=state['plans'][-1];old_id=p['id'];p.update(id=stable_id(key),seed_key=key);p['history'][0]['object_id']=p['id'];intervention.orchestration(state,p)
        actor=state['classes'][cls]['teacher_id']
        def act(action,**values):return intervention.handle(state,action,{'id':p['id'],'version':p['version'],'actor':actor,**values})
        if target=='revoked':act('revoke',actor='lead')
        elif target!='awaiting_lead':
            if p['state']=='awaiting_lead':act('approve',actor='lead')
            if target!='awaiting_teacher':
                act('confirm')
                if target!='ready':
                    act('execute',key=key+':execute');act('draft',key=key+':draft')
                    if target=='completed':act('complete',key=key+':complete',outcome='stopped' if slug=='linear-stopped' else 'unchanged' if source=='stable' else 'improved',feedback='合成回看：本次核查与答疑已结束，已记录学生反馈。前后变化同时受任务内容与提交时间影响，不据此认定干预造成改善。' if source!='linear' else '合成回看：发现题目衔接需要补齐，提前停止额外练习，释放本次名额与时长，先修订讲解材料。')
        assert p['state']==target,(slug,p['state'],target)
        mapping={old_id:p['id'],p['created_at']:_at(20,780+index*10)}
        for step,event in enumerate(p['history']):event['synthetic']=True;event['seed_key']=key+':event:'+str(step)+':'+event['action'];mapping[event['id']]=stable_id(event['seed_key']);mapping[event['at']]=_at(20,780+index*10+step)
        for field in ('lead_approval','teacher_confirmation'):
            if field in p:mapping[p[field]['at']]=_at(20,780+index*10+1)
        for ledger in ('executions','completions','drafts'):
            for row in state[ledger]:
                if row['plan_id']!=p['id']:continue
                row['seed_key']=key+':'+ledger;mapping[row['id']]=stable_id(row['seed_key'])
                for time_field in ('at','executed_at','created_at'):
                    if time_field in row:mapping[row[time_field]]=_at(20,780+index*10+8 if ledger=='completions' else 780+index*10+3)
        state=_replace(state,mapping)
    return state


@lru_cache(maxsize=1)
def _catalog():
    essays=_essay_catalog();events=extra_task_events();plans=_intervention_catalog(essays,events)
    return {'essay':essays,'analytics':{'events':events},'intervention':plans}


def enrich_cases(modules):
    """Append missing case ledgers; apply only newly added active reservations."""
    catalog=_catalog();new_executions=[]
    for module,ledgers in [('essay',('records','formal','events')),('analytics',('events',)),('intervention',('plans','executions','completions','drafts','events'))]:
        for ledger in ledgers:
            target=modules[module].setdefault(ledger,[]);existing={row.get('seed_key') for row in target}
            additions=[deepcopy(row) for row in catalog[module][ledger] if row['seed_key'] not in existing]
            target.extend(additions)
            if module=='intervention' and ledger=='executions':new_executions=additions
    completed={row['execution_id'] for row in modules['intervention']['completions']}
    for effect in new_executions:
        if effect['id'] in completed:continue
        for resource in effect['resources']:modules['intervention']['resources'][resource]['used']+=effect['participants']
        modules['intervention']['classes'][effect['class_id']]['existing_minutes']+=effect['new_minutes']
