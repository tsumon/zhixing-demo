"""Versioned synthetic content, separate from schema migrations and user actions.

New workspaces copy one cached complete seed. Existing workspaces build new
content against their own document IDs, then append only identified seed rows.
Applied-key receipts make missing or withdrawn rows stay missing or withdrawn.
"""
from copy import deepcopy
from functools import lru_cache
from importlib import import_module

CONTENT_VERSION = 1
MODULE_NAMES = ('knowledge','evaluation','essay','analytics','intervention')
LEDGERS = {
    'knowledge': ('documents','suggested_questions','events','wiki.raw','wiki.pages','wiki.revisions','wiki.conflicts'),
    'evaluation': ('gold','gold_history','runs'),
    'essay': ('records','formal','events'),
    'intervention': ('plans','executions','completions','drafts','events'),
}


def _enrich(modules):
    from .demo_knowledge import enrich_knowledge
    from .demo_cases import enrich_cases
    enrich_knowledge(modules)
    enrich_cases(modules)


@lru_cache(maxsize=1)
def _template():
    modules = {name:import_module('backend.modules.'+name).initial_state() for name in MODULE_NAMES}
    from .modules import analytics, evaluation
    modules['analytics']['events'] = analytics._events()
    evaluation.handle({'knowledge':modules['knowledge'],'evaluation':modules['evaluation']},'get',{})
    _enrich(modules)
    return modules


def initial_modules():
    """Each workspace receives its own mutable copy, including linked seed IDs."""
    return deepcopy(_template())


def _rows(module, path, create=False):
    keys=path.split('.')
    target=module
    for key in keys[:-1]:
        target=target.setdefault(key,{}) if create else target.get(key,{})
    return target.setdefault(keys[-1],[]) if create else target.get(keys[-1],[])


def _key(namespace, row):
    return namespace+':'+row['seed_key']


def initial_receipt(state):
    applied=set()
    for module,paths in LEDGERS.items():
        for path in paths:
            applied.update(_key(module+'.'+path,row) for row in _rows(state['modules'][module],path) if row.get('seed_key'))
    namespace='persona:'+state['persona_id']+':analytics.events'
    applied.update(_key(namespace,row) for row in state['modules']['analytics']['events'] if row.get('seed_key'))
    state['demo_content_version']=CONTENT_VERSION
    state['demo_seed_keys']=sorted(applied)


def _new_active_effects(original, candidate, applied):
    """Only newly inserted, uncompleted executions may consume capacity."""
    current=original['intervention']; proposed=candidate['intervention']
    existing_ids={row['id'] for row in current['executions']}
    completed={row['execution_id'] for row in proposed['completions']}
    resources=deepcopy(current['resources']); classes=deepcopy(current['classes'])
    effects=[]; blocked=set()
    for row in proposed['executions']:
        if not row.get('seed_key') or row['id'] in existing_ids or _key('intervention.executions',row) in applied or row['id'] in completed:
            continue
        cls=classes.get(row['class_id'])
        enough=cls is not None and all(resource in resources and
            resources[resource]['used']+row['participants']<=resources[resource]['capacity'] for resource in row['resources'])
        if enough and row['new_minutes']:
            policy=current['policies'].get(str(cls['grade'])+'-'+cls['region'])
            enough=bool(policy) and cls['existing_minutes']+row['new_minutes']<=policy['max_minutes']
        if not enough:
            blocked.add(row['plan_id'])
            continue
        effects.append(row)
        for resource in row['resources']:resources[resource]['used']+=row['participants']
        cls['existing_minutes']+=row['new_minutes']
    return effects,blocked


def enrich_workspace(state):
    """One atomic append-only content revision; caller owns the SQLite write."""
    if state.get('demo_content_version',0)>=CONTENT_VERSION:
        return False
    candidate=deepcopy(state['modules'])
    _enrich(candidate)
    applied=set(state.get('demo_seed_keys',[]))
    effects,blocked=_new_active_effects(state['modules'],candidate,applied)
    counts={}

    def append(target,source,namespace,skip=lambda row:False):
        existing_keys={row.get('seed_key') for row in target if row.get('seed_key')}
        existing_ids={row.get('id') for row in target if row.get('id')}
        added=0
        for row in source:
            if not row.get('seed_key'):continue
            key=_key(namespace,row)
            already=key in applied or row['seed_key'] in existing_keys or (row.get('id') and row['id'] in existing_ids)
            applied.add(key)
            if already or skip(row):continue
            target.append(deepcopy(row)); added+=1
            existing_keys.add(row['seed_key'])
            if row.get('id'):existing_ids.add(row['id'])
        if added:counts[namespace]=added
        return added

    for module,paths in LEDGERS.items():
        for path in paths:
            def skip(row):
                if module!='intervention':return False
                owner=row['id'] if path=='plans' else row.get('plan_id',row.get('object_id'))
                return owner in blocked
            append(_rows(state['modules'][module],path,create=True),_rows(candidate[module],path),module+'.'+path,skip)
    if counts.get('evaluation.gold'):
        evaluation=state['modules']['evaluation']
        evaluation['gold_revision']=max(evaluation['gold_revision']+1,candidate['evaluation'].get('gold_revision',1))
    inserted_execution_ids={row['id'] for row in state['modules']['intervention']['executions']}
    for effect in effects:
        if effect['id'] not in inserted_execution_ids or effect['plan_id'] in blocked:continue
        intervention=state['modules']['intervention']
        for resource in effect['resources']:intervention['resources'][resource]['used']+=effect['participants']
        intervention['classes'][effect['class_id']]['existing_minutes']+=effect['new_minutes']
    from .roles import ROLES
    slots={**state.get('persona_states',{}),state['persona_id']:state}
    for role_id,slot in slots.items():
        role=ROLES[role_id]
        source=[row for row in candidate['analytics']['events'] if row.get('school_id') in role['school_ids'] and row.get('class_id') in role['class_ids']]
        append(slot['modules']['analytics']['events'],source,'persona:'+role_id+':analytics.events')
    state['demo_content_version']=CONTENT_VERSION
    state['demo_seed_keys']=sorted(applied)
    state['demo_content_migration']={'version':CONTENT_VERSION,'added_counts':counts,'skipped_plan_ids':sorted(blocked)}
    return True
