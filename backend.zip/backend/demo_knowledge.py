"""Authored, local-only V7 teaching records and replayable evaluation snapshots.

The caller passes the target workspace's complete modules. Existing records are
never rewritten: the original corpus uses workspace-specific document IDs.
"""
from copy import deepcopy
from dataclasses import asdict
from uuid import NAMESPACE_URL, uuid5

from backend.modules import evaluation, knowledge
from backend.vendor.rag_core import chunk_pages


PREFIX = 'content-v7:'


def _id(key):
    return str(uuid5(NAMESPACE_URL, 'zhixing-education-demo/' + key))


# Each published case supplies an explanation, worked observation and an actual
# classroom arrangement. Draft and withdrawn editions remain inspectable only.
CASES = (
    {
        'key': 'qx-fraction', 'school': 'school-qx', 'topic': 'fraction',
        'title': '青溪六等分纸条诊断：从错式到复练',
        'pages': [
            '青溪六等分纸条诊断记录。错式1/2+1/3=2/5把分母当成可以直接累加的数量，忽略了两种分数单位不同。教师先让学生把同样长的纸条分别分成二份和三份，再统一折成六等份。二分之一覆盖三格，三分之一覆盖两格，合起来覆盖五格，结果是5/6。判断错因时先看单位是否统一，不把一次计算失误直接归结为学生不认真。要求学生解释每一格代表什么，并保留原错式与改正理由。',
            '纸条诊断的订正证据。先圈出两个不同的分数单位，再写出把分子和分母同时扩大相同倍数的等值变换，最后用同一条纸条核对覆盖部分。例：1/2写成3/6，1/3写成2/6；只把分母改成6而不改分子仍不正确。教师分别标记“单位未统一”“等值变换漏改分子”“结果未约分”，同一份订正可有多项标记。复练使用不同数值，不能只照抄刚才的算式。',
            '青溪六等分纸条诊断站每周二开展，每次12分钟，每位学生完成三道复练题。前4分钟用纸条解释原错式，中间5分钟独立完成变式，后3分钟同伴核对并写一句理由。李老师负责七年级A班的本班活动；若申请共享教室，另走资源审批，不因为教案写了地点就视为已经预留。退出条件是三道题均有等值变换过程，并能口头说明为什么分母不能直接相加；未满足时留下错因记录，下次再跟进。',
        ],
        'questions': [('青溪六等分纸条诊断怎样解释错式1/2+1/3=2/5？', 1), ('青溪六等分纸条诊断站每周几开展，每位学生完成几道复练题？', 3)],
        'draft': '青溪蓝桥观课档案试行稿。拟让每位观课教师准备三页观察表，分别记录学生原话、纸条操作和独立变式过程；尚未确认活动日期，不能作为本周排课依据。观察表不登记真实姓名，以班内合成编号关联习作。教师先记录事实，再填写可能的误区解释，避免把同伴提示后的答案当成学生独立掌握。',
        'withdrawn': '青溪纸条齐答旧稿。旧安排让全组先听教师给出通分结果，再一起填写同一道题的答案；合唱式齐答无法区分谁能独立解释分数单位。原来的记录只记最终对错，没有保留原错式与订正依据，因此不能据此确定下一轮分组。该稿已撤回，仅用于比较教学记录方式的变化。',
    },
    {
        'key': 'sy-fraction', 'school': 'school-sy', 'topic': 'fraction',
        'title': '松原数轴等距诊断：刻度与分数单位',
        'pages': [
            '松原数轴等距诊断把从0到1的线段视为整体。分母表示整体被等分成几段，不表示画了几条刻度线：从0到1分成四段会出现五条边界刻度，1/4对应第一段的右端点。教师要求先数相等间隔，再标端点；若间隔不等长，不能把每段都叫四分之一。出现“有五条线所以分母是5”的答案时，让学生对照一条线段与两个端点说明区别，保留原图再重画。',
            '数轴对齐的变式记录。例：比较1/2与2/4，先把两条长度相同的单位线段对齐0和1，再检查两点是否重合；不能把不同长度纸上的同样厘米数当成相同分数。把3/4与1/2相减时，统一为四等分单位，两个位置相隔一段，差是1/4。记录包含单位线段、等分段数、目标端点和一句理由，教师用这些字段区分读图错误与计算错误。',
            '松原数轴等距诊断站每周五开展，每次16分钟，每位学生完成四道位置判断题。先用6分钟标出单位线段与端点，再用6分钟独立比较，最后4分钟交换图纸检查间隔是否相等。活动由松原校内数学教师组织，不引用青溪的李老师或研学教室标识。四题分别覆盖端点计数、等分检查、等值分数与位置差；不把所有错误都压成一个总分，下一次按实际错因安排。',
        ],
        'questions': [('松原数轴等距诊断中，为什么五条边界刻度不能直接写成分母5？', 1), ('松原数轴等距诊断站每周几开展，每位学生完成几道位置判断题？', 3)],
        'draft': '松原透明尺互评试行稿。拟加入透明尺叠放环节，让学生先判断单位线段是否等长，再讨论分数端点是否重合；材料仍在教研复核，不替代已发布数轴教案。草稿要求把“两个点看起来接近”改成可复核的端点对应关系，互评者只能标出观察结果，最终订正仍由原作者独立完成。',
        'withdrawn': '松原刻度计数旧稿。旧资料把数轴上的边界线条数直接当作等分数，容易使学生把四个间隔误读成五份。教师已经停止使用这一口径，保留原图是为了展示为什么先确定0与1、再数间隔。此稿不得进入新一轮问答与知识页整理；如需讲错例，应使用已发布诊断资料中的完整纠错说明。',
    },
    {
        'key': 'qx-linear', 'school': 'school-qx', 'topic': 'linear',
        'title': '青溪校服租借建模：固定费与按件计费',
        'pages': [
            '青溪校服租借建模案例使用合成金额。一次固定整理费12元，每件校服租借费4元，总付款36元。设租借件数为x，数量关系是按件费用加固定费用等于总付款，列式4x+12=36。两边同时减12得到4x=24，再两边同时除以4得到x=6。检验需把6件代入费用关系，4×6+12=36，并检查件数为非负整数；只核对计算结果、不核对数量意义还不完整。',
            '固定费建模的单位核对。4的单位是元每件，x的单位是件，相乘后的单位是元，才能与12元相加。不能列成4(x+12)=36，因为它把固定金额当成件数。讨论优惠时必须先说明是减免固定费还是每件降价，两种条件产生不同方程。记录表分为已知量、未知量、等量关系、求解、回代与取值限制，不要求学生机械套用题型口令。',
            '青溪校服租借建模复核站每周四开展，每次14分钟，每位学生完成两道费用变式。前5分钟画出固定费与按件费用的两部分，中间6分钟独立列式，后3分钟做单位与回代检查。七年级B班材料由本班任课教师安排，不能用七年级A班身份直接提交执行。完成标准同时包括等量关系、正确计算、单位和整数件数解释；有一项缺失就记录需补充的证据。',
        ],
        'questions': [('青溪校服租借建模如何列出4x+12=36并检验租借件数？', 1), ('青溪校服租借建模复核站每周几开展，每位学生完成几道费用变式？', 3)],
        'draft': '青溪优惠条件比较稿。准备比较“免固定整理费”与“每件减一元”的不同效果，学生须先逐句改写费用关系，再列方程。当前仅为待审核的拓展题，不能用其中拟定优惠作为既有收费事实。教师复核时检查题目是否给足条件，尤其不能把“打折”一词直接转换成固定减数，也不能拿不同件数的总价直接比较。',
        'withdrawn': '青溪只验算式旧稿。旧资料把“算出x后计算一次”当成完整检验，没有要求代回原始数量关系，也没有检查租借件数的整数限制。这样可能保留计算无误却不符合场景的答案。旧稿已撤回，当前教学改用费用、单位与取值限制三层核验；保留旧稿供教研对照，不再作为作业讲评依据。',
    },
    {
        'key': 'sy-linear', 'school': 'school-sy', 'topic': 'linear',
        'title': '松原图书修补建模：准备时间与单件工时',
        'pages': [
            '松原图书修补建模案例使用合成工时。准备工具需要5分钟，每本图书修补需要2分钟，一组学生可用的总时间是21分钟。设能够修补的本数为x，关系式为2x+5=21，先减去5分钟准备时间，再除以每本2分钟，得到x=8。代回2×8+5=21检查总时长，同时说明本数应为非负整数。本题假设每本耗时一致、工作顺序进行，没有提供多人并行效率。',
            '修补工时的条件检查。若可用时间变为22分钟，剩余17分钟只能完成八本并剩1分钟，不能报告八点五本已完成图书。等式求解与实际安排要区分：安排最多本数时必须满足不超过总时长，而不是把小数直接四舍五入。教师观察学生是否区分准备时间与单件工时，遇到工具故障或难度差异时先补充记录，不能继续沿用每本2分钟的前提。',
            '松原图书修补建模站每周三开展，每次18分钟，每位学生完成三道工时条件题。先用5分钟区分固定准备与重复工作，再用8分钟求解，最后5分钟讨论剩余时间和整数本数。八年级A班使用松原校内资源，实际活动名额须在方案中确认。本教案只给教学练习的计算前提，不声明志愿活动已开展，也不把模拟本数作为真实服务成效。',
        ],
        'questions': [('松原图书修补建模怎样用准备5分钟、每本2分钟和总计21分钟求修补本数？', 1), ('松原图书修补建模站每周几开展，每位学生完成几道工时条件题？', 3)],
        'draft': '松原不等式边界拓展稿。拟把“恰好用满时间”改成“最多能完成多少本”，让学生先解释剩余时间，再选择整数安排。此稿用于下一次教研讨论，不能直接替换当前方程课的学习目标。审核清单要求保留原方程例题，并明确哪些结论只在单件工时一致时成立；未完成的半本不能计入已完成图书数。',
        'withdrawn': '松原四舍五入安排旧稿。旧表格把求得的8.5本四舍五入成9本，导致安排超出总时长。实际数量约束要求向下取可完成的整数，不是套用通用小数近似规则。旧稿现已撤回，保留反例与原口径便于复核过往资料；已经完成的课堂记录仍可回看，新练习应引用已发布的工时条件说明。',
    },
    {
        'key': 'qx-argument', 'school': 'school-qx', 'topic': 'argument',
        'title': '青溪校园树荫提案：观察、观点与证据边界',
        'pages': [
            '青溪校园树荫提案使用合成观察记录。两块同面积区域在一次晴天下午分别测得28℃与33℃，可以写“本次观察中树荫区域读数较低”，不能据一次观察断言“种树一定使所有时段降低5℃”。观点可以是增加遮阴设施值得讨论，证据是这次测量条件和读数，解释应说明遮阴可能影响暴晒，同时承认风、地面材质与仪器差异尚未控制。学生必须分别标出观察事实、主张与待验证解释。',
            '树荫提案的论证修订。先复述反方顾虑，例如维护成本与冬季采光，再判断现有观察能否回应，不能把反方改写成“不关心同学”。可提出补充不同天气、相同时段和相同地面的记录作为下一步，但不能把计划采集的数据写成已经证实。引用合成记录时标明记录编号、条件与整理者；语言有说服力不能代替来源可核对。教师分别评阅论点、材料相关性和证据边界。',
            '青溪树荫提案证据复核会每周一开展，每次15分钟，每位学生对照三条材料。前5分钟区分观察和主张，中间6分钟检查材料是否支持当前句子，最后4分钟改写一处过度推断。七年级A班只整理合成材料，不采集真实学生个人信息。初评建议需教师独立复核后按用途显式发布；这份教案不自动给出成绩，也不替代正式测评的独立复核和校长确认。',
        ],
        'questions': [('青溪校园树荫提案怎样区分28℃与33℃的观察记录、观点和待验证解释？', 1), ('青溪树荫提案证据复核会每周几开展，每次安排多少分钟？', 3)],
        'draft': '青溪反方观点互换稿。计划让两组学生交换维护成本与遮阴需求的论证，先用一句话准确复述对方最强理由，再选择一条能够回应的材料。当前稿尚未通过教研审核，示例中的调查数量只是拟定条件。互换活动须保留对方原句和自己的回应，不能只写“我不同意”，也不能把没有材料支持的推断用肯定语气发布。',
        'withdrawn': '青溪单次观察结论旧稿。旧段落把一次温度差直接写成种树的固定效果，省略测量条件与其他可能解释，容易使学生把相关性当成因果。该稿已停止引用，教师保留它用于对照限定语和证据边界的修改。旧稿中的5℃只描述那一次合成读数差，不能转换为校园改造的真实效果或未来保证。',
    },
    {
        'key': 'sy-argument', 'school': 'school-sy', 'topic': 'argument',
        'title': '松原论证证据工坊：阅读视角与反方回应',
        'pages': [
            '松原论证证据工坊比较两则合成阅读材料。材料甲由故事中的旁观者叙述冲突，材料乙由当事人回顾同一片段；两者细节不同，先标出谁在说、看到了什么、哪些内容只是猜测。学生可以主张多视角阅读有助于理解分歧，但应引用具体叙述差异并解释联系，不能只列作品名称。反方若认为单一可靠叙述更清晰，回应应承认信息核对成本，再说明何时需要补充视角。',
            '证据卡整理规则。每张卡记录主张、原句、来源位置和解释，四项不可互相代替；引用别人的评价时要区分材料事实与评价者意见。没有作者、篇目或位置的网摘不能假装是可核对出处。给合成材料补写说明时，必须保留“合成阅读材料”标签，不能虚构真实作者。教师的复核重点是引用是否逐字可找、解释是否超出原句，而不是看论据数量是否足够多。',
            '松原论证证据工坊每周四开放，每次20分钟，每位学生填写两页证据卡。前6分钟核对叙述者与原句，中间8分钟把原句连接到主张，后6分钟准确复述并回应一个反方理由。八年级A班由本校语文教师复核，使用松原班级与资源范围。证据卡评语先保存为草稿，教师完成核对后再发布；没有来源位置的卡片退回补充，不以流畅表述替代来源检查。',
        ],
        'questions': [('松原论证证据工坊怎样用旁观者与当事人的叙述差异支持多视角阅读主张？', 1), ('松原论证证据工坊每周几开放，每位学生填写多少页证据卡？', 3)],
        'draft': '松原篇章对照拓展稿。拟把同一冲突的第三个叙述视角加入证据卡，先检查它补充了什么可核对事实，再判断是否改变原有结论。新增片段尚未审核，不得把草稿当成正式阅读材料。学生须保留修订前主张与修订理由，说明哪些证据支持、哪些仍有缺口，不能因为多了一则材料就自动提高评价等级。',
        'withdrawn': '松原星火旧版展评说明曾要求每组安排四名观察员，并只按引用数量给分。该活动口径已撤回：堆放四条不相关材料并不能支撑主张，引用数量也不能代替逐字可核对性。保留这段旧说明是为了说明为什么改用主张、原句、位置与解释的证据卡；当前活动安排以已发布工坊教案为准。',
    },
)


def _document(case, state):
    key = PREFIX + 'document:' + case['key'] + ':' + state
    version = '2025' if state == 'withdrawn' else '2026'
    if state == 'published':
        pages = case['pages']
        title = case['title']
    else:
        title = case['title'] + (' · 待教研补充稿' if state == 'draft' else ' · 已撤回旧稿')
        pages = [case[state],
                 '教研核对与使用边界。先选一份合成学生作答，对照原始过程逐项检查材料中的条件、算式或引文，再记录改动理由。核对者应分别写出可观察事实、教学解释和仍需补齐的材料，不能用“总体不错”代替具体记录。'
                 + ('本稿仍待审核，日期、名额和资源安排未生效；审核通过后须显式发布，才能进入资料检索。修订时保留当前已发布材料，比较每项变化是否影响既有题集与引用。' if state == 'draft' else '本稿已经撤回，只能查看历史；新一轮教学问答不得引用其中旧口径。需要恢复相关教学活动时，应新建修订稿，写清改正内容并重新审核发布，不直接把旧稿状态改回可用。')]
    text = '\f'.join(pages)
    doc = knowledge._make_document(title, case['school'], version, case['topic'], text, state)
    doc.update(id=_id(key), seed_key=key, series_id=_id(PREFIX + 'series:' + case['key']),
               created_at='2026-10-20T01:00:00+00:00', synthetic=True)
    doc['chunks'] = [asdict(c) for c in chunk_pages(case['school'], version, doc['id'], enumerate(pages, 1), 700)]
    return doc


def _gold(key, question, school, version, document=None, page=None):
    item = evaluation._gold_item(question, school, version, [document] if document else [], document['topic_id'] if document else 'no_evidence')
    item.update(id=_id(key), seed_key=key, synthetic=True)
    if document:
        item['evidence'] = [e for e in item['evidence'] if any(c['chunk_id'] == e['chunk_id'] and c['page'] == page for c in document['chunks'])]
        item['evidence_ids'] = [e['chunk_id'] for e in item['evidence']]
    else:
        item['document_id'] = _id(key + ':no-document')
        item['lineage'] = [_id(key + ':no-source')]
    return item


def _append_new(rows, additions):
    known = {row.get('seed_key') for row in rows}
    rows.extend(row for row in additions if row['seed_key'] not in known)


def _report(wrapper, key, label, **payload):
    run = evaluation.handle(wrapper, 'run', payload)
    # The generated signatures do not contain the report identity. Preserve all
    # computed metrics, output records, gates and timestamps without rewriting.
    run.update(id=_id(key), seed_key=key, seed_scenario_label=label, synthetic=True)
    run.pop('activation', None)
    return run


def enrich_knowledge(modules):
    """Append authored records once, leaving user content and active policy intact."""
    kb, state = modules['knowledge'], modules['evaluation']
    if all(any(d.get('seed_key') == PREFIX + 'document:' + case['key'] + ':published' for d in kb['documents']) for case in CASES) and any(r.get('seed_key') == PREFIX + 'report:pending' for r in state['runs']):
        return
    before = deepcopy({'knowledge': kb, 'evaluation': state})
    additions = [_document(case, status) for case in CASES for status in ('published', 'draft', 'withdrawn')]
    _append_new(kb['documents'], additions)
    docs = {d['seed_key']: d for d in kb['documents'] if d.get('seed_key')}
    gold, questions = [], []
    for case in CASES:
        doc = docs[PREFIX + 'document:' + case['key'] + ':published']
        for number, (question, page) in enumerate(case['questions'], 1):
            key = PREFIX + 'gold:' + case['key'] + ':' + str(number)
            gold.append(_gold(key, question, case['school'], '2026', doc, page))
            qkey = PREFIX + 'question:' + case['key'] + ':' + str(number)
            questions.append({'id': _id(qkey), 'seed_key': qkey, 'question': question, 'school_id': case['school'],
                              'version': '2026', 'topic_id': case['topic'], 'synthetic': True})
    refusal_specs = [
        ('draft', '青溪蓝桥观课档案要求每位观课教师准备多少页观察表？', 'school-qx', '2026'),
        ('withdrawn', '松原星火旧版展评每组安排多少名观察员？', 'school-sy', '2026'),
        ('old-version', '青溪六等分纸条诊断站每周几开展，每位学生完成几道复练题？', 'school-qx', '2025'),
        ('other-school', '松原论证证据工坊每周几开放，每位学生填写多少页证据卡？', 'school-qx', '2026'),
    ]
    for name, question, school, version in refusal_specs:
        gold.append(_gold(PREFIX + 'gold:refusal:' + name, question, school, version))
    old_gold_count = len(state['gold'])
    _append_new(state['gold'], gold)
    if len(state['gold']) > old_gold_count:
        state['gold_revision'] += 1
    _append_new(kb.setdefault('suggested_questions', []), questions)

    # Make histories from actual local handlers. A legacy user's original gold
    # may be inconsistent; then the demonstration uses its independent authored
    # population and remains stale relative to that user's untouched population.
    working = deepcopy({'knowledge': kb, 'evaluation': state})
    try:
        evaluation.validate_manifest([{k: row[k] for k in evaluation.GOLD_FIELDS} for row in working['evaluation']['gold']])
    except (KeyError, ValueError):
        working['evaluation']['gold'] = deepcopy(gold)
    try:
        evaluation.validate_manifest([{k: row[k] for k in evaluation.GOLD_FIELDS} for row in before['evaluation']['gold']])
    except (KeyError, ValueError):
        before['evaluation'] = evaluation.initial_state()
    reports = [_report(before, PREFIX + 'report:before', '资料扩充前的旧快照', candidate_strategy='hybrid')]
    missing_source = deepcopy(working)
    knowledge.handle(missing_source['knowledge'], 'withdraw', {'document_id': additions[0]['id']})
    reports.append(_report(missing_source, PREFIX + 'report:missing-source', '一份来源撤回后的失败检查', candidate_strategy='hybrid', candidate_top_k=1, recall_floor=1.0))
    reports.append(_report(working, PREFIX + 'report:keyword', '关键词检索对照，等待逐题核对', candidate_strategy='keyword', candidate_top_k=6))
    reports.append(_report(working, PREFIX + 'report:pending', '完整新增资料对照，待教研验收', candidate_strategy='hybrid', candidate_top_k=6))
    _append_new(state['runs'], reports)
    if state.get('last_run') is None:
        state['last_run'] = deepcopy(next(r for r in state['runs'] if r.get('seed_key') == PREFIX + 'report:pending'))

    # Compile on a clean working copy. An existing teacher-edited page must not
    # be overwritten, duplicated or acquire synthetic unresolved conflicts.
    working_kb = deepcopy(kb)
    working_kb['wiki'] = deepcopy(knowledge.initial_state()['wiki'])
    compiled = knowledge.handle(working_kb, 'wiki_compile', {'school_id': 'school-qx', 'version': '2026'})['wiki']
    existing_scopes = {(p['school_id'], p['version'], p['topic_id']) for p in kb['wiki']['pages']}
    for page in compiled['pages']:
        if (page['school_id'], page['version'], page['topic_id']) in existing_scopes:
            continue
        key = PREFIX + 'wiki:' + page['school_id'] + ':' + page['version'] + ':' + page['topic_id']
        page.update(id=_id(key), seed_key=key, synthetic=True, publication="published", reviewed_revision=page["revision"], review={"by":"synthetic-curriculum-seed", "note":"预置合成教学资料已随内容版本核对", "revision":page["revision"]})
        kb['wiki']['pages'].append(page)
    known_raw = {r['document_id'] for r in kb['wiki']['raw']}
    for raw in compiled['raw']:
        if raw['document_id'] not in known_raw:
            key = PREFIX + 'raw:' + raw['document_id']
            raw.update(id=_id(key), seed_key=key, synthetic=True)
            kb['wiki']['raw'].append(raw)
