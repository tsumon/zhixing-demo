"""Local-only office channel simulation. No HTTP client, secrets, webhook or model."""
from copy import deepcopy
from datetime import datetime, timezone
from uuid import uuid4

from backend import roles
from backend.modules import intervention, essay
from backend.vendor.intervention_core import digest

PROVIDERS = {'wecom':'企业微信','dingtalk':'钉钉','feishu':'飞书'}
STATE_LABELS = {**intervention.LABELS, **essay.STATE_LABELS}


def now():
    return datetime.now(timezone.utc).isoformat()


def initial_state():
    return {'channels':{key:{'enabled':True,'updated_at':None} for key in PROVIDERS},
            'deliveries':[], 'callbacks':{}}


def _text(value,label,cap=120):
    if not isinstance(value,str) or not value.strip() or len(value)>cap:
        raise ValueError(f'请填写{label}，最多 {cap} 字符')
    return value.strip()


def _visible(row,role):
    return row.get('school_id') in role['school_ids'] and row.get('class_id') in role['class_ids']


def _record(state,kind,source_id):
    if kind not in {'intervention','essay'}:
        raise ValueError('来源仅支持教学干预方案或作文记录')
    key='plans' if kind=='intervention' else 'records'
    row=next((r for r in state['modules'][kind][key] if r['id']==source_id),None)
    if row is None:
        raise ValueError('来源记录不存在于当前访客工作区')
    if not _visible(row,roles.current(state)):
        raise PermissionError('来源记录不在当前身份的学校班级范围内')
    return row


def _fingerprint(kind,row):
    # Bind the approval stage as well as content/version: approve and confirm do
    # not increment the source version, but an earlier card still must expire.
    return digest({'kind':kind,'id':row['id'],'version':row['version'],'state':row['state'],
                   'content':row.get('plan_hash') if kind=='intervention' else digest({'text':row['text'],'rubric':row['rubric']})})


def _approval_step(row):
    if row['state']=='awaiting_lead':
        return 'approve','principal','lead'
    if row['state']=='awaiting_teacher' and _visible(row,roles.ROLES['teacher']):
        return 'confirm','teacher',row.get('evidence',{}).get('teacher_id','teacher-li')
    return None,None,None


def _source(kind,row):
    step,recipient,_=_approval_step(row) if kind=='intervention' else (None,None,None)
    return {'source_kind':kind,'source_id':row['id'],'title':row.get('title') or row.get('proposal',{}).get('title','教学干预方案'),
            'school_id':row['school_id'],'class_id':row['class_id'],'version':row['version'],
            'state':row['state'],'state_label':STATE_LABELS.get(row['state'],row['state']),
            'allowed_intents':['notification']+(['approval'] if step else []),
            'approval_step':step,'recipient_role':recipient,
            'approval_note':'作文审批仍在作文工作台完成，此处仅通知' if kind=='essay' else
              ('7B 的任课确认请回教学干预工作台演示，不扩大李老师 7A 身份范围' if row['state']=='awaiting_teacher' and not step else '')}


def _identity(provider,role_id):
    return {'provider':provider,'persona_id':role_id,'label':roles.ROLES[role_id]['label'],
            'external_user_id':f'demo-{provider}-{role_id}','simulated':True}


def _card_payload(provider,delivery):
    title,summary,href=delivery['title'],delivery['summary'],delivery['href']
    action='打开审批待办' if delivery['intent']=='approval' else '打开工作台'
    # Intentionally display mappings, not production schemas or authenticated calls.
    if provider=='wecom':
        body={'msgtype':'template_card','template_card':{'card_type':'text_notice',
              'main_title':{'title':title,'desc':summary},'jump_list':[{'title':action,'url':href}],
              'task_id':delivery['id']}}
    elif provider=='dingtalk':
        body={'msgtype':'actionCard','actionCard':{'title':title,'text':summary,'btnOrientation':'0',
              'btns':[{'title':action,'actionURL':href}]}}
    else:
        body={'msg_type':'interactive','content':{'header':{'title':{'tag':'plain_text','content':title}},
              'elements':[{'tag':'div','text':{'tag':'plain_text','content':summary}},
                          {'tag':'action','actions':[{'tag':'button','text':{'tag':'plain_text','content':action},'url':href}]}]}}
    return {**body,'simulation':True,'recipient':_identity(provider,delivery['recipient_role'])['external_user_id'],
            'mapping_note':'仅演示渠道字段映射，未使用生产认证、真实 URL 或外部接口'}


def _delivery(state,delivery_id):
    delivery=next((d for d in state['integrations']['deliveries'] if d['id']==delivery_id),None)
    if delivery is None:
        raise ValueError('消息记录不存在于当前访客工作区')
    if not _visible(delivery,roles.current(state)):
        raise PermissionError('消息记录不在当前身份的学校班级范围内')
    return delivery


def _stale(state,delivery):
    try:row=_record(state,delivery['source_kind'],delivery['source_id'])
    except ValueError:return True
    return _fingerprint(delivery['source_kind'],row)!=delivery['source_hash']


def _enabled(state,provider):
    if provider not in PROVIDERS:
        raise ValueError('请选择企业微信、钉钉或飞书演示渠道')
    if not state['integrations']['channels'][provider]['enabled']:
        raise ValueError('该演示渠道已关闭，请由系统管理员启用后再试')


def _business_role(state):
    if state['persona_id'] not in {'principal','teacher'}:
        raise PermissionError('只有对应校长或教师可以投递和处理业务卡片，管理员不代办审批')


def _delivery_view(state,delivery):
    out=deepcopy(delivery)
    stale=_stale(state,delivery)
    connected=state['integrations']['channels'][delivery['provider']]['enabled']
    business=state['persona_id'] in {'principal','teacher'}
    completed=bool(delivery.get('callback_result'))
    out['status_label']='模拟投递成功' if delivery['status']=='delivered' else '模拟投递失败 · 待手动重试'
    out['callback_status']=('completed' if completed else 'expired' if stale else 'pending') if delivery['intent']=='approval' else None
    out['can_retry']=business and connected and not stale and delivery['status']=='failed'
    out['can_callback']=business and connected and not stale and not completed and delivery['status']=='delivered' and delivery['intent']=='approval' and state['persona_id']==delivery['recipient_role']
    return out


def view(state):
    role=roles.current(state)
    rows=[_source(kind,row) for kind,key in [('essay','records'),('intervention','plans')]
          for row in reversed(state['modules'][kind][key]) if _visible(row,role)]
    deliveries=[_delivery_view(state,d) for d in reversed(state['integrations']['deliveries']) if _visible(d,role)]
    todos=[]
    for d in deliveries:
        if d['intent']!='approval':continue
        status=d['callback_status']
        if status=='pending' and d['status']!='delivered':status='waiting_delivery'
        todos.append({'id':'todo-'+d['id'],'delivery_id':d['id'],'title':d['title'],'provider':d['provider'],
                      'source_kind':d['source_kind'],'source_id':d['source_id'],'source_version':d['source_version'],
                      'action':d['approval_action'],'recipient_role':d['recipient_role'],'status':status,'can_callback':d['can_callback']})
    return {'simulation':True,'network_calls':0,'model_calls':0,'mode':'三渠道本地模拟',
            'channels':[{'provider':p,'label':label,**deepcopy(state['integrations']['channels'][p]),'mode':'simulated'} for p,label in PROVIDERS.items()],
            'identities':[_identity(p,rid) for p in PROVIDERS for rid in ROLES_FOR_IDENTITY if set(roles.ROLES[rid]['school_ids'])&set(role['school_ids'])],
            'sources':rows,'deliveries':deliveries,'todos':todos,
            'permissions':{'connect':role['id']=='admin','send':role['id'] in {'principal','teacher'},
                           'retry':role['id'] in {'principal','teacher'},'callback':role['id'] in {'principal','teacher'}},
            'scope_note':'仅本访客授权范围内的合成记录；渠道卡片、待办和回执全部本地模拟，不向真实组织发送消息。'}


ROLES_FOR_IDENTITY=('principal','teacher','researcher')


def _attempt(delivery,failed=False):
    delivery['status']='failed' if failed else 'delivered'
    delivery['attempts'].append({'number':len(delivery['attempts'])+1,'status':delivery['status'],'at':now(),
                                'reason':'演示临时投递失败，请手动重试' if failed else '仅本地模拟成功，未产生外部消息'})


def handle(state,action,payload=None,model=None):
    payload=payload or {}
    if action=='get':return view(state)
    if action=='connect':
        if state['persona_id']!='admin':raise PermissionError('只有系统管理员可以启停演示渠道')
        provider=payload.get('provider')
        if provider not in PROVIDERS:raise ValueError('请选择企业微信、钉钉或飞书演示渠道')
        if type(payload.get('enabled')) is not bool:raise ValueError('渠道开关必须是布尔值')
        state['integrations']['channels'][provider].update(enabled=payload['enabled'],updated_at=now())
        return view(state)
    _business_role(state)
    if action=='send':
        provider=payload.get('provider');_enabled(state,provider)
        kind=payload.get('source_kind');row=_record(state,kind,payload.get('source_id'))
        intent=payload.get('intent')
        if intent not in {'approval','notification'}:raise ValueError('请选择审批卡片或状态通知')
        failure=payload.get('failure_mode','none')
        if failure not in {'none','retryable'}:raise ValueError('不支持的失败演示模式')
        step,recipient,actor=_approval_step(row) if kind=='intervention' else (None,None,None)
        if intent=='approval' and not step:
            raise ValueError('当前记录不支持审批卡片；作文审批请在作文工作台完成，干预需处于对应待审批阶段')
        key=_text(payload.get('idempotency_key'),'投递幂等键')
        source_hash=_fingerprint(kind,row)
        request_hash=digest({'provider':provider,'kind':kind,'id':row['id'],'source_hash':source_hash,'intent':intent})
        previous=next((d for d in state['integrations']['deliveries'] if d['idempotency_key']==key),None)
        if previous:
            if previous['request_hash']!=request_hash:raise ValueError('同一投递幂等键不能用于另一条记录、版本、渠道或用途')
            return {**view(state),'delivery':_delivery_view(state,previous),'replayed':True}
        title=_source(kind,row)['title']
        status=STATE_LABELS.get(row['state'],row['state'])
        summary=f"{row['class_id']} · 第 {row['version']} 版 · {status}。"
        if kind=='intervention':
            summary+=f"演示方案安排 {row['proposal']['participants']} 人、新增 {row['proposal']['new_minutes']} 分钟。"
        else:summary+='仅通知评阅进度，正文和盲评分数留在作文工作台。'
        summary+='审批和执行以工作台当前版本为准。'
        if intent=='notification':recipient='teacher' if state['persona_id']=='principal' and _visible(row,roles.ROLES['teacher']) else 'principal'
        delivery={'id':str(uuid4()),'provider':provider,'source_kind':kind,'source_id':row['id'],
                  'school_id':row['school_id'],'class_id':row['class_id'],'source_version':row['version'],'source_hash':source_hash,
                  'source_state':row['state'],'intent':intent,'idempotency_key':key,'request_hash':request_hash,
                  'title':title,'summary':summary,'href':'#'+kind,'created_at':now(),'created_by':state['persona_id'],
                  'recipient_role':recipient,'approval_action':step if intent=='approval' else None,
                  'approval_actor':actor if intent=='approval' else None,'attempts':[],'callback_result':None}
        delivery['payload']=_card_payload(provider,delivery)
        _attempt(delivery,failure=='retryable')
        state['integrations']['deliveries'].append(delivery)
        return {**view(state),'delivery':_delivery_view(state,delivery),'replayed':False}
    if action not in {'retry','callback'}:raise ValueError('不支持的渠道操作')
    delivery=_delivery(state,payload.get('id'))
    _enabled(state,delivery['provider'])
    if action=='retry':
        if _stale(state,delivery):raise ValueError('这张卡片已过期，请按当前业务版本重新投递')
        if delivery['status']=='delivered':return {**view(state),'delivery':_delivery_view(state,delivery),'replayed':True}
        _attempt(delivery)
        return {**view(state),'delivery':_delivery_view(state,delivery),'replayed':False}
    if delivery['intent']!='approval':raise ValueError('状态通知没有审批回调')
    if state['persona_id']!=delivery['recipient_role']:
        raise PermissionError('请切换到此待办指定的业务身份，不能代替他人审批或确认')
    if payload.get('decision')!='approved':raise ValueError('本演示回调只支持通过；修改或撤回请回业务工作台操作')
    event_id=_text(payload.get('event_id'),'回调事件 ID')
    old=state['integrations']['callbacks'].get(event_id)
    if old and old['delivery_id']!=delivery['id']:raise ValueError('回调事件 ID 已用于其他卡片，不能重复关联')
    if delivery.get('callback_result'):
        receipt=delivery['callback_result']
        state['integrations']['callbacks'][event_id]=deepcopy(receipt)
        return {**view(state),'delivery':_delivery_view(state,delivery),'callback_result':deepcopy(receipt),'replayed':True}
    if _stale(state,delivery):raise ValueError('这张审批卡片已过期；记录版本、内容或审批阶段已改变，请重新投递')
    if delivery['status']!='delivered':raise ValueError('卡片尚未投递成功，不能处理审批回调')
    business_payload=roles.authorize(state,'intervention',delivery['approval_action'],
        {'id':delivery['source_id'],'version':delivery['source_version'],'actor':delivery['approval_actor']})
    result=intervention.handle(state['modules']['intervention'],delivery['approval_action'],business_payload,model=None)
    receipt={'delivery_id':delivery['id'],'event_id':event_id,'action':delivery['approval_action'],
             'source_id':delivery['source_id'],'source_version':delivery['source_version'],'persona_id':state['persona_id'],
             'business_state':result['plan']['state'],'at':now(),'simulation':True}
    delivery['callback_result']=receipt
    state['integrations']['callbacks'][event_id]=deepcopy(receipt)
    return {**view(state),'delivery':_delivery_view(state,delivery),'callback_result':deepcopy(receipt),'replayed':False}
