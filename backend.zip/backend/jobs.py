"""Single durable runner for local synthetic work. No external calls or retries.

A committed running marker survives a crash. Business effects, audit, and the
result commit together; an interrupted operation rolls back and needs an
explicit retry. One OS file lock owns recovery and execution for this runtime.
"""
import hashlib
import json
import logging
import os
import secrets
import threading
import time

from . import roles, integrations

logger = logging.getLogger(__name__)
TASK_ACTIONS = {('knowledge','search'), ('knowledge','wiki_compile'),
    ('evaluation','run'), ('essay','score'), ('analytics','run'),
    ('intervention','execute'), ('integrations','send')}
COLUMNS = ('id','workspace_id','module','action','payload','request_hash','idempotency_key',
    'status','actor_id','actor_label','created_at','started_at','finished_at','error','result','retry_of')


class TaskConflict(ValueError):
    pass


class TaskQueue:
    def __init__(self, store, execute, seed):
        self.store, self.execute, self.seed = store, execute, seed
        self.wake = threading.Event()
        self.stopping = threading.Event()
        self.thread = None
        self.lock_file = None
        self._sync_mode = os.environ.get('ZHIXING_SYNC_TASKS') == '1'
        self._sync_running = False
        with store.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, module TEXT NOT NULL,
                action TEXT NOT NULL, payload TEXT NOT NULL, request_hash TEXT NOT NULL,
                idempotency_key TEXT NOT NULL, status TEXT NOT NULL, actor_id TEXT NOT NULL,
                actor_label TEXT NOT NULL, created_at REAL NOT NULL, started_at REAL,
                finished_at REAL, error TEXT, result TEXT, retry_of TEXT UNIQUE,
                UNIQUE(workspace_id,actor_id,idempotency_key))''')
            db.execute('CREATE INDEX IF NOT EXISTS tasks_workspace ON tasks(workspace_id,actor_id,created_at)')
            db.execute('CREATE INDEX IF NOT EXISTS tasks_status ON tasks(status,created_at)')

    @property
    def running(self):
        if self._sync_mode:
            return self._sync_running
        return self.thread is not None and self.thread.is_alive() and not self.stopping.is_set()

    def _row(self, row):
        return dict(zip(COLUMNS,row)) if row else None

    def _event(self, task, status):
        self.store.append_audit(task['workspace_id'],task['actor_id'],{
            'id':'task-event-'+secrets.token_hex(8), 'task_id':task['id'],
            'module':task['module'], 'action':task['action'], 'status':status,
            'actor_label':task['actor_label'], 'at':time.time()})

    def _get(self, task_id):
        with self.store.connect() as db:
            row=db.execute('SELECT '+','.join(COLUMNS)+' FROM tasks WHERE id=?',(task_id,)).fetchone()
        return self._row(row)

    def _visible(self, task, state):
        if not task or task['workspace_id']!=state['id'] or (task['actor_id']!=state['persona_id'] and state['persona_id']!='admin'):
            raise KeyError('未找到此任务。')
        return task

    def _view(self, task, state):
        own=task['actor_id']==state['persona_id']
        with self.store.connect() as db:
            child=db.execute('SELECT id FROM tasks WHERE retry_of=?',(task['id'],)).fetchone()
        fields=('id','module','action','status','actor_id','actor_label','created_at',
            'started_at','finished_at','error','retry_of')
        return {**{key:task[key] for key in fields},
            'result':json.loads(task['result']) if own and task['result'] is not None else None,
            'can_open_result':own and task['status']=='succeeded',
            'can_retry':own and task['status'] in {'failed','interrupted'} and not child,
            'can_cancel':own and task['status']=='queued',
            'retry_task_id':child[0] if child else None}

    def get(self, state, task_id):
        return self._view(self._visible(self._get(task_id),state),state)

    def list(self, state):
        with self.store.connect() as db:
            sql='SELECT '+','.join(COLUMNS)+' FROM tasks WHERE workspace_id=?'
            params=[state['id']]
            if state['persona_id']!='admin':
                sql+=' AND actor_id=?'; params.append(state['persona_id'])
            rows=db.execute(sql+' ORDER BY created_at DESC,id DESC',params).fetchall()
        return [self._view(self._row(row),state) for row in rows]

    def submit(self, state, request):
        module,action=request.get('module'),request.get('action')
        if not isinstance(module,str) or not isinstance(action,str) or (module,action) not in TASK_ACTIONS:
            raise ValueError('此操作不支持后台任务。')
        payload=request.get('payload',{})
        key=request.get('idempotency_key')
        if not isinstance(payload,dict):raise ValueError('任务参数必须是对象。')
        if not isinstance(key,str) or not key.strip() or len(key)>128:
            raise ValueError('请提供不超过 128 字符的任务幂等键。')
        fingerprint=hashlib.sha256(json.dumps([module,action,payload],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        with self.store.transaction() as db:
            previous=db.execute('SELECT '+','.join(COLUMNS)+' FROM tasks WHERE workspace_id=? AND actor_id=? AND idempotency_key=?',
                (state['id'],state['persona_id'],key)).fetchone()
            if previous:
                task=self._row(previous)
                if task['request_hash']!=fingerprint:raise TaskConflict('同一幂等键不能用于不同的任务参数。')
                return self._view(task,state)
            # Capture authorized defaults (record ID and business actor) at submit.
            if module=='integrations':
                integrations._business_role(state)
            else:
                payload=roles.authorize(state,module,action,payload)
            task=self._new(state,module,action,payload,key,fingerprint)
        if self._sync_mode:
            while self._run_next():
                pass
            return self._view(self._get(task['id']),state)
        self.wake.set()
        return self._view(task,state)

    def _new(self, state, module, action, payload, key, fingerprint, retry_of=None):
        task=dict(zip(COLUMNS,('task-'+secrets.token_hex(10),state['id'],module,action,
            json.dumps(payload,ensure_ascii=False),fingerprint,key,'queued',state['persona_id'],
            roles.current(state)['label'],time.time(),None,None,None,None,retry_of)))
        with self.store.connect() as db:
            db.execute('INSERT INTO tasks ('+','.join(COLUMNS)+') VALUES('+','.join('?' for _ in COLUMNS)+')',
                tuple(task[column] for column in COLUMNS))
        self._event(task,'queued')
        return task

    def retry(self, state, task_id):
        with self.store.transaction() as db:
            task=self._visible(self._get(task_id),state)
            if task['actor_id']!=state['persona_id']:
                raise PermissionError('只能由提交任务的角色重试；管理员不能代办业务。')
            if task['status'] not in {'failed','interrupted'}:
                raise TaskConflict('仅失败或中断的任务可以重试；已成功的任务不会重复执行。')
            previous=db.execute('SELECT '+','.join(COLUMNS)+' FROM tasks WHERE retry_of=?',(task_id,)).fetchone()
            if previous:return self._view(self._row(previous),state)
            payload=json.loads(task['payload'])
            if task['module']=='integrations':integrations._business_role(state)
            else:roles.authorize(state,task['module'],task['action'],payload)
            child=self._new(state,task['module'],task['action'],payload,'retry:'+task_id,task['request_hash'],task_id)
        if self._sync_mode:
            while self._run_next():
                pass
            return self._view(self._get(child['id']),state)
        self.wake.set()
        return self._view(child,state)

    def cancel(self, state, task_id):
        with self.store.transaction() as db:
            task=self._visible(self._get(task_id),state)
            if task['actor_id']!=state['persona_id']:
                raise PermissionError('只能由提交任务的角色取消。')
            if task['status']=='cancelled':return self._view(task,state)
            if task['status']!='queued':raise TaskConflict('只有尚未开始的任务可以取消。')
            db.execute("UPDATE tasks SET status='cancelled',finished_at=? WHERE id=?",(time.time(),task_id))
            self._event(task,'cancelled')
            return self._view(self._get(task_id),state)

    def start(self):
        if self.running:return
        if self._sync_mode:
            self._sync_running = True
            return
        lock_file=open(self.store.path.with_suffix('.worker.lock'),'a+b')
        try:
            if os.name=='nt':
                import msvcrt
                lock_file.seek(0); lock_file.write(b'0'); lock_file.flush(); lock_file.seek(0)
                msvcrt.locking(lock_file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(lock_file.fileno(),fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            lock_file.close()
            raise RuntimeError('此运行目录已有任务服务；请只启动一个服务进程。') from None
        self.lock_file=lock_file
        try:
            with self.store.transaction() as db:
                rows=db.execute('SELECT '+','.join(COLUMNS)+" FROM tasks WHERE status='running'").fetchall()
                for row in rows:self._event(self._row(row),'interrupted')
                db.execute("UPDATE tasks SET status='interrupted',finished_at=?,error=? WHERE status='running'",
                    (time.time(),'上次服务中断，业务更改已回滚；请核对后手动重试。'))
            self.stopping.clear()
            self.thread=threading.Thread(target=self._loop,name='simulation-task-worker',daemon=True)
            self.thread.start()
        except BaseException:
            self.lock_file.close(); self.lock_file=None
            raise

    def stop(self):
        self._sync_running = False
        self.stopping.set(); self.wake.set()
        if self.thread:self.thread.join()
        self.thread=None
        if self.lock_file:self.lock_file.close(); self.lock_file=None

    def _loop(self):
        try:
            while not self.stopping.is_set():
                self.wake.clear()
                if not self._run_next():self.wake.wait(1)
        except Exception:
            # Leave the durable running marker for explicit recovery at restart.
            logger.exception('Local task runner stopped; readiness is now unhealthy')

    def _run_next(self):
        with self.store.transaction() as db:
            row=db.execute('SELECT '+','.join(COLUMNS)+" FROM tasks WHERE status='queued' ORDER BY created_at,id LIMIT 1").fetchone()
            if not row:return False
            task=self._row(row)
            db.execute("UPDATE tasks SET status='running',started_at=? WHERE id=?",(time.time(),task['id']))
            self._event(task,'running')
        # The running marker commits first. Everything below is atomic: no
        # external effects are allowed, so a process crash rolls all of it back.
        with self.store.transaction() as db:
            original=self.store.load_id(task['workspace_id'])
            roles.migrate(original,self.seed)
            active_role=original['persona_id']
            roles.switch(original,task['actor_id'],self.seed)
            state,result,event,error_status,error=self.execute(original,task['module'],task['action'],json.loads(task['payload']))
            event['task_id']=task['id']
            self.store.capture_events(state)
            roles.switch(state,active_role,self.seed)
            self.store.save(state)
            status='failed' if error_status else 'succeeded'
            db.execute('UPDATE tasks SET status=?,finished_at=?,error=?,result=? WHERE id=?',
                (status,time.time(),error,json.dumps(result,ensure_ascii=False) if not error_status else None,task['id']))
            self._event(task,status)
        return True
