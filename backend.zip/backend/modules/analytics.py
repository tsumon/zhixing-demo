"""Visitor-isolated learning analytics simulation. No SQL or model is executed."""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import re
from uuid import NAMESPACE_URL, uuid4, uuid5

from backend.vendor.analytics_core import (
    MetricDefinition, Snapshot, independent_review, release,
)
from backend.vendor.intervention_core import digest

PERIODS = ["2026-W42", "2026-W43", "2026-W44", "2026-W45", "2026-W46"]
CLASSES = [
    {"id": "7A", "name": "七年级一班", "school_id": "school-qx", "grade": 7, "knowledge_id": "fraction", "existing_minutes": 65},
    {"id": "7B", "name": "七年级二班", "school_id": "school-qx", "grade": 7, "knowledge_id": "fraction", "existing_minutes": 70},
    {"id": "8A", "name": "八年级一班", "school_id": "school-sy", "grade": 8, "knowledge_id": "linear", "existing_minutes": 60},
]
FACT_COLUMNS = {
    "school_id": "TEXT", "class_id": "TEXT", "student_id": "TEXT", "task_id": "TEXT",
    "period": "TEXT", "completed": "INT", "optional": "INT", "grade": "INT",
    "knowledge_id": "TEXT", "existing_minutes": "INT", "task_title": "TEXT",
    "published_at": "TEXT", "due_at": "TEXT", "observed_at": "TEXT", "difficulty_level": "INT",
}
CATALOG = {"facts": FACT_COLUMNS, "task_events": {**FACT_COLUMNS, "attempt_id": "TEXT"}}
EXAMPLES = [
    {"question": "七年级本周作业完成率为什么下降？", "label": "比较两个班", "class_ids": ["7A", "7B"], "include_optional": False},
    {"question": "只看7A的作业完成率，算上选做", "label": "切换选做口径", "class_ids": ["7A"], "include_optional": True},
    {"question": "7B的作业完成率有变化吗？", "label": "查看单个班级", "class_ids": ["7B"], "include_optional": False},
    {"question":"7A作业完成率回升了多少？","label":"回看完成率恢复","class_ids":["7A"],"baseline_period":"2026-W44","current_period":"2026-W45","dataset":"workspace"},
    {"question":"7B作业完成率保持稳定吗？","label":"稳定班级对照","class_ids":["7B"],"baseline_period":"2026-W45","current_period":"2026-W46","dataset":"workspace"},
    {"question":"7A作业完成率下降与提交窗口有关吗？","label":"未到截止的窗口","class_ids":["7A"],"baseline_period":"2026-W45","current_period":"2026-W46","dataset":"workspace"},
    {"question":"8A作业完成率变化怎么样？","label":"方程任务回看","class_ids":["8A"],"baseline_period":"2026-W44","current_period":"2026-W45","dataset":"workspace"},
]
ESSAY_EXAMPLE = {"question": "7A已发布作文的成绩和薄弱维度怎么样？", "label": "看作文薄弱维度", "class_ids": ["7A"], "assessment_type": "practice"}
DEMO_CASES = [{"id": "normal", "label": "正确口径"}, {"id": "wrong_denominator", "label": "错误分母"}, {"id": "write", "label": "写入语句"}]
DATASETS = [
    {'id': 'workspace', 'label': '当前工作区任务', 'description': '沿用当前保存的任务记录，不改动原数据。'},
    {'id': 'attribution_example', 'label': '完整归因案例', 'description': '独立的合成任务案例，含发布时间与截止记录；不会覆盖当前工作区任务。'},
]
DATASET_LABELS = {item['id']: item['label'] for item in DATASETS}


def _events():
    result = []
    configurations = {"7A": (100, [75, 80, 60]), "7B": (20, [16, 18, 18]), "8A": (40, [30, 35, 32])}
    for cls in CLASSES:
        size, completed = configurations[cls["id"]]
        for period, done in zip(PERIODS, completed):
            year, week = period.split('-W')
            monday = datetime.fromisocalendar(int(year), int(week), 1).replace(tzinfo=timezone.utc)
            for optional, n, done_n in [(0, size, done), (1, 10 if size == 100 else 4, 2)]:
                for index in range(n):
                    task_number = index % 5 + 1
                    # Completion differences concentrate in a traceable assignment,
                    # while preserving the established class/week totals.
                    rank = sum((n + 4 - j) // 5 for j in range(task_number - 1)) + index // 5
                    delayed = cls['id'] == '7A' and period == PERIODS[2] and not optional and task_number == 4
                    published = monday + (timedelta(days=4, hours=8) if delayed else timedelta(hours=9))
                    due = monday + timedelta(days=6 if delayed else 4, hours=18)
                    event_key = f"zhixing-task-v1:{cls['id']}:{period}:{optional}:{index}"
                    row = {"school_id": cls["school_id"], "class_id": cls["id"],
                           "student_id": f'{cls["id"]}-S{index // 5 + 1:02}',
                           "task_id": f'{"O" if optional else "R"}-{index % 5 + 1}',
                           "period": period, "completed": int(rank < done_n), "optional": optional,
                           "grade": cls["grade"], "knowledge_id": 'linear' if task_number == 5 else cls["knowledge_id"],
                           "existing_minutes": cls["existing_minutes"], "attempt_id": str(uuid5(NAMESPACE_URL, event_key + ':1')),
                           "task_title": ('选做：' if optional else '') + ['基础概念', '计算巩固', '应用练习', '综合练习', '方程衔接'][task_number - 1],
                           "published_at": published.isoformat(), "due_at": due.isoformat(),
                           "observed_at": (monday + timedelta(days=4, hours=20)).isoformat(), "difficulty_level": 1}
                    result.append(row)
                    # A second submission is another event, never another assignment.
                    if not optional and rank < min(done_n, 6):
                        result.append({**row, "attempt_id": str(uuid5(NAMESPACE_URL, event_key + ':2'))})
    return result


def initial_state():
    allowed = ["7A", "7B"]
    return {"events": [x for x in _events() if x["class_id"] in allowed], "allowed_classes": allowed, "auth_epoch": 1,
            "plan": None, "result": None, "latest_verified_snapshot": None, "history": [], "essay_formal": []}


def sync_essay_formal(state, formal_rows):
    """Project server-owned published scores into this private analysis view."""
    schools = {x['id']: x['school_id'] for x in CLASSES}
    rows = [deepcopy(x) for x in formal_rows if x.get('class_id') in state['allowed_classes']
            and x.get('school_id') == schools.get(x.get('class_id')) and x.get('published_at')]
    changed = digest(state.get('essay_formal', [])) != digest(rows)
    state['essay_formal'] = rows
    if changed and (state.get('plan') or {}).get('metric_kind') == 'essay_quality':
        state.update(plan=None, result=None, latest_verified_snapshot=None)


def _essay_source(state, conditions):
    if conditions['auth_epoch'] != state['auth_epoch'] or not set(conditions['class_ids']) <= set(state['allowed_classes']):
        raise ValueError('权限发生变化，请重新规划并取数')
    latest = {}
    for row in state.get('essay_formal', []):
        if row.get('class_id') not in conditions['class_ids'] or not row.get('published_at'):
            continue
        key = (row['school_id'], row['class_id'], row['essay_id'])
        version = int(row['approved_version'])
        prior = latest.get(key)
        if prior is None or version > int(prior['approved_version']):
            latest[key] = row
        elif version == int(prior['approved_version']) and row != prior:
            raise ValueError('同一作文发布版本存在冲突，请先核对正式成绩')
    # Choose the latest publication first. A withdrawn or reclassified latest
    # version must not silently revive an older published practice score.
    selected = [latest[k] for k in sorted(latest)
                if latest[k].get('status', 'published') == 'published'
                and latest[k].get('assessment_type') == conditions['assessment_type']]
    origin = conditions.get('source_essay')
    if origin is not None:
        if (not isinstance(origin, dict) or not isinstance(origin.get('essay_id'), str)
                or type(origin.get('approved_version')) is not int or origin['approved_version'] < 1):
            raise ValueError('作文分析来源格式无效，请从当前发布记录重新进入')
        if not any(row['essay_id'] == origin['essay_id'] and int(row['approved_version']) == origin['approved_version'] for row in selected):
            raise ValueError('来源作文已撤回、更新或不在当前班级与成绩类型内，请回作文评阅查看当前发布记录')
    return deepcopy(selected)


def _essay_sql(conditions):
    classes = ', '.join(repr(x) for x in conditions['class_ids'])
    return f'''-- 仅讲解：published_essay_latest 是每篇作文最新正式发布版本
SELECT school_id, class_id, SUM(score) AS numerator,
       SUM(max_score) AS denominator, COUNT(*) AS record_count
FROM published_essay_latest
WHERE class_id IN ({classes}) AND assessment_type = '{conditions['assessment_type']}'
GROUP BY school_id, class_id'''


def _essay_rows(source):
    grouped = defaultdict(list)
    for row in source:
        score, maximum = Decimal(str(row['score'])), Decimal(str(row['max_score']))
        if not score.is_finite() or not maximum.is_finite() or maximum <= 0 or not 0 <= score <= maximum:
            raise ValueError('正式成绩分数或满分无效，请先核对发布记录')
        grouped[row['class_id']].append(row)
    result = []
    for class_id, records in sorted(grouped.items()):
        cls = next(x for x in CLASSES if x['id'] == class_id)
        if any(x['school_id'] != cls['school_id'] for x in records):
            raise ValueError('正式成绩学校与班级归属不一致')
        total = sum(Decimal(str(x['score'])) for x in records)
        maximum = sum(Decimal(str(x['max_score'])) for x in records)
        dimensions = defaultdict(lambda: {'score': Decimal(0), 'max_score': Decimal(0), 'record_count': 0})
        reviewed = [x for x in records if x.get('dimension_source') == 'reviewer']
        for record in reviewed:
            parts = record.get('dimensions', [])
            if len({d['name'] for d in parts}) != len(parts) or sum(Decimal(str(d['score'])) for d in parts) != Decimal(str(record['score'])) or sum(Decimal(str(d['max_score'])) for d in parts) != Decimal(str(record['max_score'])):
                raise ValueError('正式成绩的逐维度得分与总分不一致')
            for part in parts:
                value, cap = Decimal(str(part['score'])), Decimal(str(part['max_score']))
                if not value.is_finite() or not cap.is_finite() or cap <= 0 or not 0 <= value <= cap:
                    raise ValueError('正式成绩的逐维度得分无效')
                dim = dimensions[part['name']]
                dim['score'] += value; dim['max_score'] += cap; dim['record_count'] += 1
        details = [{'name': name, 'score': float(d['score']), 'max_score': float(d['max_score']),
                    'score_rate': float(d['score']/d['max_score']), 'record_count': d['record_count']}
                   for name,d in dimensions.items()]
        result.append({'class_id': class_id, 'group_id': class_id, 'school_id': cls['school_id'],
            'grade': cls['grade'], 'region': 'qingxi' if cls['school_id'] == 'school-qx' else 'shuyuan',
            'knowledge_id': 'argument', 'existing_minutes': cls['existing_minutes'], 'metric_kind': 'essay_quality',
            'assessment_type': records[0]['assessment_type'], 'score_total': float(total), 'max_score_total': float(maximum),
            'current': float(total), 'numerator': float(total), 'denominator': float(maximum), 'score_rate': float(total/maximum),
            'record_count': len(records), 'student_count': len({x['student_id'] for x in records if x.get('student_id') and x.get('student_linked', True)}),
            'unknown_student_records': sum(not x.get('student_id') or not x.get('student_linked', True) for x in records),
            'average_score': float(total/len(records)), 'dimensions': details,
            'dimension_record_count': len(reviewed), 'weak_dimensions': [d for d in details if d['score_rate'] < .7],
            'formal_ids': [x['id'] for x in records], 'simulation': True})
    if not result:
        raise ValueError('当前范围还没有这类已发布作文成绩。请先在作文初评完成复核和发布，再回来分析')
    return result


def _essay_report(state, plan, payload):
    source = _essay_source(state, plan['conditions'])
    if digest(source) != plan['source_hash']:
        raise ValueError('已发布成绩发生变化，请重新生成分析计划')
    shown_sql, case = _demo_statement(plan, payload)
    rows = _essay_rows(source)
    if case == 'wrong_denominator':
        rows[0]['denominator'] += 1
    return source, rows, shown_sql, case


def _verify_essay(source, rows, plan):
    # Recompute directly from the formal records, never from the displayed SQL.
    for row in rows:
        subset = [x for x in source if x['class_id'] == row['class_id']]
        expected = sum(Decimal(str(x['max_score'])) for x in subset)
        score = sum(Decimal(str(x['score'])) for x in subset)
        if row['denominator'] != expected or row['numerator'] != score or row['record_count'] != len(subset):
            raise ValueError('模拟复算门禁：作文得分分母必须是已发布作文满分之和，不能使用作业任务数')
    total, maximum = sum(x['score_total'] for x in rows), sum(x['max_score_total'] for x in rows)
    schools = {x['school_id'] for x in rows}
    snapshot = {'schema_version': 1, 'tenant_id': next(iter(schools)) if len(schools)==1 else 'education-demo',
                'snapshot_id': str(uuid4()), 'metric_version': 'essay-quality-v1', 'metric_kind': 'essay_quality',
                'captured_at': datetime.now(timezone.utc).isoformat(), 'rows': rows, 'published_source_hash': plan['source_hash']}
    snapshot['source_hash'] = digest(snapshot)
    count = sum(x['record_count'] for x in rows)
    kind_label = '正式测评' if plan['conditions']['assessment_type'] == 'formal' else '练习'
    return {'metric_kind': 'essay_quality', 'verified': True, 'verification_kind': '模拟复算门禁',
            'simulation': True, 'sql_executed': False, 'model_calls': 0,
            'summary': {'score_total': total, 'max_score_total': maximum, 'score_rate': total/maximum,
                        'record_count': count, 'student_count': len({(x['class_id'],x['student_id']) for x in source if x.get('student_id') and x.get('student_linked', True)}),
                        'unknown_student_records': sum(not x.get('student_id') or not x.get('student_linked', True) for x in source),
                        'average_score': total/count}, 'groups': rows, 'snapshot': snapshot,
            'raw_snapshot': source, 'review': {'passed': True, 'observational_only': True,
                'source': 'P3最新已发布成绩', 'weak_threshold': .7, 'threshold_kind': '演示排查阈值，不是及格线'},
            'conclusion': f'{count} 份已发布{kind_label}作文，合计得分 {total:g}/{maximum:g}，得分率 {total/maximum:.2%}。',
            'interpretation': '只统计当前选定范围已发布的作文，不推算全班成绩或作业完成率。薄弱维度只用人工逐维度复核分数，少于70%仅提示优先检查；没有逐维度记录时不猜测薄弱项。分数分布不能证明学习问题的原因，也不能证明后续干预有效。'}


def _selection(state, payload):
    dataset = _dataset_id(payload.get('dataset', 'workspace'))
    classes = payload.get("class_ids", state.get("default_classes", state["allowed_classes"]))
    if not isinstance(classes, list) or not classes or not all(isinstance(x, str) for x in classes):
        raise ValueError("请至少选择一个已授权班级")
    classes = sorted(set(classes))
    if not set(classes) <= set(state["allowed_classes"]):
        raise ValueError("所选班级不在当前访客的授权范围内")
    before, after = payload.get("baseline_period", PERIODS[1]), payload.get("current_period", PERIODS[2])
    if before not in PERIODS or after not in PERIODS or PERIODS.index(before) >= PERIODS.index(after):
        raise ValueError("基准周必须早于当前周，请使用演示提供的统计窗口")
    include = payload.get("include_optional", False)
    if not isinstance(include, bool):
        raise ValueError("选做开关必须是布尔值")
    return {"class_ids": classes, "baseline_period": before, "current_period": after,
            "include_optional": include, "auth_epoch": state["auth_epoch"], 'dataset': dataset}


def _question_selection(state, question, payload):
    """Small, explicit language grammar; the UI exposes every resolved condition."""
    selected = dict(payload)
    mentioned, excluded = set(), set()
    known_ids = {x['id'] for x in CLASSES}
    ids = re.findall(r'(?<![A-Za-z0-9])\d+[A-Za-z](?![A-Za-z0-9])', question)
    if any(x.upper() not in known_ids for x in ids):
        raise ValueError('问题包含演示范围外的班级，请从页面选择已授权班级')
    aliases = '|'.join(re.escape(x['name']) for x in CLASSES) + r'|(?<![A-Za-z0-9])(?:7A|7B|8A)(?![A-Za-z0-9])'
    negative_spans = [m.group(0) for m in re.finditer(rf'(?:排除|不看|不要|不含|去掉)\s*(?:{aliases})(?:\s*(?:和|及|、|与)\s*(?:{aliases}))*', question, re.I)]
    grade_text = question
    for cls in CLASSES:
        alias = rf'(?:(?<![A-Za-z0-9]){cls["id"]}(?![A-Za-z0-9])|{cls["name"]})'
        if re.search(alias, question, re.I):
            mentioned.add(cls["id"])
        if any(re.search(alias, span, re.I) for span in negative_spans):
            excluded.add(cls["id"])
        grade_text = grade_text.replace(cls['name'], '')
    grades = {'七': 7, '7': 7, '八': 8, '8': 8}
    positive_grades, negative_grades = set(), set()
    for m in re.finditer(r'(排除|不看|不要|不含|去掉)?\s*([一二三四五六七八九十\d]+)年级', grade_text):
        if m[2] not in grades:
            raise ValueError('该年级不在演示范围，请选择七年级或八年级的已授权班级')
        (negative_grades if m[1] else positive_grades).add(grades[m[2]])
    if re.search(r'(?:只看|仅看|排除|不含|去掉)\s*(?:知识点[：:]?)?(?:分数运算|一元一次方程|女生|男生|未提交|已提交|未完成)', question):
        raise ValueError('当前筛选仅支持班级、年级、统计周和选做开关；知识点可在结果里查看贡献，暂不支持该子集筛选')
    requested = mentioned - excluded
    excluded |= {x['id'] for x in CLASSES if x['grade'] in negative_grades}
    # A broad grade phrase narrows the selected/authorized scope; it must not
    # silently add another class. Explicit class names still pass the final
    # authorization check rather than being silently removed.
    selection_scope = selected.get('class_ids', state.get('default_classes', state['allowed_classes']))
    if not isinstance(selection_scope, list):
        raise ValueError('请至少选择一个已授权班级')
    if not requested:
        requested = set(selection_scope)
    if positive_grades:
        grade_classes = {x['id'] for x in CLASSES if x['grade'] in positive_grades}
        requested &= grade_classes
    requested -= excluded
    if mentioned or positive_grades or excluded:
        selected["class_ids"] = sorted(requested)
    optional_exclusion = r'(?:不包含|不包括|不计入|不含|排除|不算|不计|不要(?:计入|包含|包括)?|去掉)\s*(?:的)?选做'
    no_optional = bool(re.search(optional_exclusion, question))
    yes_optional = bool(re.search(r'(?:计入|算上|包含|包括)\s*(?:的)?选做', re.sub(optional_exclusion, '', question)))
    if no_optional and yes_optional:
        raise ValueError("问题同时要求计入和排除选做，请保留一个统计口径")
    if no_optional or yes_optional:
        selected["include_optional"] = yes_optional
    weeks = [f'{year or "2026"}-W{week}' for year, week in re.findall(r'(?<![A-Za-z0-9])(?:(\d{4})-)?[Ww](\d{2})(?!\d)', question)]
    if weeks:
        if len(weeks) != 2:
            raise ValueError('完成率对比需要两个统计周，请明确基准窗口和当前窗口')
        selected.update(baseline_period=weeks[0], current_period=weeks[1])
    elif re.search(r'本月|上月|昨天|昨日|近\d+天|最近\d+天', question):
        raise ValueError('当前演示只提供 W42、W43、W44 统计周，请使用页面窗口，不按月或日悄悄替代')
    return _selection(state, selected)


def _default_sql(conditions):
    opt = "" if conditions["include_optional"] else " AND optional = 0"
    scope = " AND class_id IN (" + ', '.join(repr(x) for x in conditions['class_ids']) + ')'
    return f'''WITH base AS (
  SELECT class_id, SUM(completed) AS baseline, COUNT(*) AS baseline_denominator
  FROM facts WHERE period = '{conditions["baseline_period"]}'{opt}{scope} GROUP BY class_id
), cur AS (
  SELECT school_id, class_id, grade, existing_minutes,
         SUM(completed) AS current, COUNT(*) AS denominator
  FROM facts WHERE period = '{conditions["current_period"]}'{opt}{scope}
  GROUP BY school_id, class_id, grade, existing_minutes
)
SELECT cur.class_id AS group_id, base.baseline, base.baseline_denominator,
       cur.current, cur.current AS numerator, cur.denominator,
       cur.school_id, cur.class_id, cur.grade, cur.existing_minutes
FROM cur JOIN base ON cur.class_id = base.class_id
ORDER BY cur.class_id
-- 关注知识点另按该班任务的实际负贡献选择；不是把多知识点分组当成班级总数。'''


def _dataset_id(value):
    if not isinstance(value, str) or value not in DATASET_LABELS:
        raise ValueError('请选择当前工作区任务或完整归因案例这两个数据案例')
    return value


def _dataset_events(state, dataset):
    dataset = _dataset_id(dataset)
    events = _events() if dataset == 'attribution_example' else state['events']
    return [row for row in events if row['class_id'] in state['allowed_classes']]


def _source_statistics(events, conditions):
    dataset = _dataset_id(conditions.get('dataset', 'workspace'))
    periods = {conditions['baseline_period'], conditions['current_period']} if 'baseline_period' in conditions else None
    events = [row for row in events if (not conditions.get('class_ids') or row['class_id'] in conditions['class_ids'])
              and (periods is None or row['period'] in periods)
              and (conditions.get('include_optional', True) or not row['optional'])]
    unique = {(row['class_id'], row['student_id'], row['task_id'], row['period']): row for row in events}
    return {'dataset': dataset, 'label': DATASET_LABELS[dataset], 'events': len(events),
            'unique_tasks': len(unique), 'duplicate_events': len(events) - len(unique), 'preview': deepcopy(events[:8]),
            'class_ids': sorted({row['class_id'] for row in events}), 'periods': sorted({row['period'] for row in events}),
            'missing_timing_records': sum(any(not row.get(field) for field in ('published_at', 'due_at', 'observed_at')) for row in unique.values())}


def _authorized_events(state, conditions):
    if conditions["auth_epoch"] != state["auth_epoch"] or not set(conditions["class_ids"]) <= set(state["allowed_classes"]):
        raise ValueError("权限发生变化，请重新规划并取数")
    return [x for x in _dataset_events(state, conditions.get('dataset', 'workspace')) if x["class_id"] in conditions["class_ids"]]


def _demo_statement(plan, payload):
    case = payload.get("demo_case", "normal")
    if case not in {x["id"] for x in DEMO_CASES}:
        raise ValueError("请选择正确口径、错误分母或写入语句这三个演示场景")
    shown_sql = plan["sql"]
    if case == "wrong_denominator":
        shown_sql = shown_sql.replace("COUNT(*) AS denominator", "COUNT(*) + 1 AS denominator").replace("SUM(max_score) AS denominator", "SUM(max_score) + 1 AS denominator")
    elif case == "write":
        shown_sql = "DELETE FROM task_events"
    supplied = payload.get("sql", shown_sql)
    if not isinstance(supplied, str) or len(supplied) > 10000 or re.sub(r"\s+", "", supplied) != re.sub(r"\s+", "", shown_sql):
        raise ValueError("SQL 只用于展示，任意编辑不会执行。请恢复示例 SQL，或选择下方预设门禁对照")
    if case == "write":
        raise ValueError("模拟 SQL 门禁：写入语句被拒绝。本次没有连接数据库，也没有执行 DELETE")
    return shown_sql, case


def _demo_query(events, plan, payload):
    """Select a declared demonstration, never interpret or execute arbitrary SQL."""
    shown_sql, case = _demo_statement(plan, payload)
    raw, _ = _raw_snapshot(events, plan["conditions"])
    groups = defaultdict(list)
    for row in raw.export()["rows"]:
        groups[row["class_id"]].append(row)
    rows = []
    for class_id, items in sorted(groups.items()):
        first = items[0]
        row = {k: first[k] for k in ("school_id", "class_id", "grade", "knowledge_id", "existing_minutes")}
        row['knowledge_id'], row['knowledge_selection'] = _knowledge_focus(items)
        row.update(group_id=class_id, baseline=sum(x["baseline"] for x in items), baseline_denominator=len(items),
                   current=sum(x["current"] for x in items), numerator=sum(x["current"] for x in items), denominator=len(items))
        rows.append(row)
    if case == "wrong_denominator":
        rows[0]["denominator"] += 1
    return rows, shown_sql, case


def _knowledge_focus(rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[row['knowledge_id']].append(row)
    candidates = [{'knowledge_id': key, 'baseline': sum(x['baseline'] for x in subset),
                   'current': sum(x['current'] for x in subset), 'assignments': len(subset)}
                  for key, subset in sorted(grouped.items())]
    declining = [x for x in candidates if x['current'] < x['baseline']]
    selected = min(declining, key=lambda x: (x['current']-x['baseline'], x['knowledge_id'])) if declining else max(candidates, key=lambda x: x['assignments'])
    return selected['knowledge_id'], {'basis': 'largest_negative_contribution' if declining else 'largest_assignment_group',
        'candidates': candidates, 'note': '班级完成率是全部所选任务的统计；关注知识点按本班实际任务变化选择，不代表已证明学习原因。'}


def _raw_snapshot(events, conditions):
    """Independent event fold; never consumes edited SQL results or intermediate totals."""
    dedup = {}
    for event in events:
        if event["period"] not in {conditions["baseline_period"], conditions["current_period"]}:
            continue
        if not conditions["include_optional"] and event["optional"]:
            continue
        cls = next((x for x in CLASSES if x['id'] == event['class_id']), None)
        if cls is None or cls['school_id'] != event['school_id'] or cls['grade'] != event['grade']:
            raise ValueError('任务记录的学校、班级或年级归属冲突，请先核对来源')
        if event['completed'] not in (0, 1) or not isinstance(event['completed'], (int, bool)):
            raise ValueError('任务完成状态只能是 0 或 1，不能作为任意完成数量累加')
        key = (event["school_id"], event["class_id"], event["student_id"], event["task_id"])
        item = dedup.setdefault(key, {"event": event, "before": None, "after": None})
        if any(item['event'][field] != event[field] for field in ('knowledge_id','optional','grade')):
            raise ValueError('同一配对任务的知识点或必选做口径发生变化，请先核对任务范围')
        period_key = "before" if event["period"] == conditions["baseline_period"] else "after"
        item[period_key] = max(item[period_key] or 0, event["completed"])
        evidence = item.setdefault(period_key + '_evidence', {})
        for field in ('published_at','due_at','observed_at','difficulty_level'):
            if field not in event: continue
            if field in evidence and evidence[field] != event[field]:
                raise ValueError('同一任务统计窗口的时间或难度记录冲突，不能用最后一条记录覆盖前面证据')
            evidence[field] = event[field]
    rows = []
    for key, item in sorted(dedup.items()):
        if item["before"] is None or item["after"] is None:
            raise ValueError("两周的任务范围发生变化，需要先解释分母变化，不能直接做这份配对分析")
        event = item["event"]
        rows.append({"group_id": event["class_id"], "baseline": item["before"], "current": item["after"],
                     "numerator": item["after"], "denominator": 1, "optional": bool(event["optional"]),
                     "school_id": event["school_id"], "class_id": event["class_id"], "grade": event["grade"],
                     "knowledge_id": event["knowledge_id"], "existing_minutes": event["existing_minutes"],
                     "student_id": event["student_id"], "task_id": event["task_id"],
                     'dataset': conditions.get('dataset', 'workspace'),
                     "task_title": event.get('task_title', event['task_id']),
                     "baseline_evidence": item['before_evidence'], "current_evidence": item['after_evidence']})
    if not rows:
        raise ValueError("当前范围没有可比较的任务，不把空结果当作完成率为零")
    metric = MetricDefinition(version="completion-demo-v1-" + ("all" if conditions["include_optional"] else "required") + '-' + conditions.get('dataset', 'workspace'), exclude_optional=not conditions["include_optional"])
    schools = {row['school_id'] for row in rows}
    tenant = next(iter(schools)) if len(schools) == 1 else 'education-demo'
    return Snapshot.create(tenant, metric.version, rows), metric


def _rate_contributions(groups):
    """Symmetric numerator/denominator decomposition, additive across any partition."""
    before_n = Decimal(sum(x['baseline_required'] for x in groups))
    after_n = Decimal(sum(x['current_required'] for x in groups))
    if before_n <= 0 or after_n <= 0:
        raise ValueError('两期都需要有效分母，不能解释空范围的完成率变化')
    before_c = Decimal(sum(x['baseline_completed'] for x in groups))
    after_c = Decimal(sum(x['current_completed'] for x in groups))
    completion_weight = (1 / before_n + 1 / after_n) / 2
    denominator_weight = -(before_c + after_c) / (2 * before_n * after_n)
    result = []
    for row in groups:
        completion = Decimal(row['current_completed'] - row['baseline_completed']) * completion_weight * 100
        denominator = Decimal(row['current_required'] - row['baseline_required']) * denominator_weight * 100
        result.append({**row,
            'baseline_rate': row['baseline_completed'] / row['baseline_required'] if row['baseline_required'] else None,
            'current_rate': row['current_completed'] / row['current_required'] if row['current_required'] else None,
            'completion_effect_pp': float(completion), 'denominator_effect_pp': float(denominator),
            'contribution_pp': float(completion + denominator)})
    return result


def _evidence_totals(rows):
    before, after, count = sum(x['baseline'] for x in rows), sum(x['current'] for x in rows), len(rows)
    return {'baseline_completed': before, 'baseline_required': count, 'current_completed': after,
            'current_required': count, 'baseline_rate': before / count if count else None,
            'current_rate': after / count if count else None}


def _timestamp(evidence, field):
    try:
        value = datetime.fromisoformat(evidence[field])
        return value if value.tzinfo is not None else None
    except (KeyError, TypeError, ValueError):
        return None


def _clue_matches(row, kind):
    before, after = row['baseline_evidence'], row['current_evidence']
    if kind == 'difficulty_increase':
        levels = [x.get('difficulty_level') for x in (before, after)]
        return levels[1] > levels[0] if all(type(x) is int for x in levels) else None
    fields = ('published_at', 'observed_at') if kind == 'late_release' else ('due_at', 'observed_at')
    times = [[_timestamp(item, field) for field in fields] for item in (before, after)]
    if any(value is None for pair in times for value in pair):
        return None
    if kind == 'late_release':
        hours = [(observed - published).total_seconds() / 3600 for published, observed in times]
        return hours[1] >= 0 and hours[1] <= 24 and hours[0] - hours[1] >= 24
    return times[1][0] > times[1][1] and times[0][0] <= times[0][1]


def _task_evidence(rows):
    records = {}
    for row in rows:
        record = {'class_id': row['class_id'], 'task_id': row['task_id'], 'title': row['task_title'],
                  'baseline': deepcopy(row['baseline_evidence']), 'current': deepcopy(row['current_evidence'])}
        for period in ('baseline', 'current'):
            published, observed = [_timestamp(record[period], field) for field in ('published_at', 'observed_at')]
            record[period]['available_hours'] = (observed - published).total_seconds() / 3600 if published and observed else None
        # Preserve distinct per-student windows instead of hiding accommodations.
        key = digest(record)
        records.setdefault(key, {**record, 'assignment_count': 0})['assignment_count'] += 1
    return list(records.values())


def _attribution_clues(rows):
    definitions = [
        ('late_release', '任务发布偏晚，完成时间缩短', ['published_at', 'observed_at'], '核对任务发布记录，为时间不足的任务安排补交窗口，再比较到期后的完成率。'),
        ('deadline_open', '统计时任务尚未到截止时间', ['due_at', 'observed_at'], '等相同提交窗口结束后再复查，区分尚未到期与到期未完成。'),
        ('difficulty_increase', '任务难度提高', ['difficulty_level'], '核对题目与错误类型；只有难度标记变化不足以判定学生能力下降。'),
    ]
    clues = []
    for kind, label, fields, next_step in definitions:
        flags = [_clue_matches(row, kind) for row in rows]
        exposed = [row for row, flag in zip(rows, flags) if flag is True]
        classes = {row['class_id'] for row in exposed}
        control = [row for row, flag in zip(rows, flags) if flag is False and row['class_id'] in classes]
        strata = []
        for class_id in sorted(classes):
            a = _evidence_totals([row for row in exposed if row['class_id'] == class_id])
            b = _evidence_totals([row for row in control if row['class_id'] == class_id])
            difference = ((a['current_rate'] - a['baseline_rate']) - (b['current_rate'] - b['baseline_rate'])) * 100 if b['baseline_required'] else None
            strata.append({'class_id': class_id, 'exposed': a, 'comparison': b, 'difference_in_change_pp': difference})
        evidence = {'exposed': _evidence_totals(exposed), 'comparison': _evidence_totals(control),
                    'difference_in_change_pp': None, 'source_fields': fields,
                    'class_comparisons': strata, 'comparison_method': '先按班级分别比较变化，再按符合条件的任务数加权；不直接比较跨班混合比例',
                    'task_keys': sorted({f"{row['class_id']}:{row['task_id']}" for row in exposed}),
                    'class_ids': sorted(classes), 'missing_evidence_rows': flags.count(None),
                    'compared_assignments': len(rows) - flags.count(None), 'matching_assignments': len(exposed),
                    'task_records': _task_evidence(exposed)}
        if any(flag is None for flag in flags):
            status, finding = 'insufficient_data', f'当前范围有 {flags.count(None)} 份任务缺少完整的记录，不能判断这条线索。'
        elif not exposed:
            status, finding = 'not_supported', '两期记录中没有符合这项变化的任务，当前数据不支持这条解释。'
        elif any(x['difference_in_change_pp'] is None for x in strata):
            status, finding = 'insufficient_data', '找到了符合条件的任务，但同班没有未受该条件影响的对照任务，暂不能区分这条线索。'
        else:
            a, b = evidence['exposed'], evidence['comparison']
            delta = (a['current_rate'] - a['baseline_rate']) * 100
            difference = sum(x['difference_in_change_pp'] * x['exposed']['baseline_required'] for x in strata) / len(exposed)
            evidence['difference_in_change_pp'] = difference
            status = 'supported' if delta < -1e-9 and difference < -1e-9 else 'not_supported'
            finding = f"相关任务完成率变化 {delta:+.2f} 个百分点；按班级分别对照后，加权变化差为 {difference:+.2f} 个百分点。" + ('值得优先核查这条线索。' if status == 'supported' else '当前对照未显示该条件伴随更大的下降。')
        clues.append({'id': kind, 'label': label, 'status': status, 'finding': finding, 'evidence': evidence,
                      'next_step': next_step, 'limitation': '同任务前后与同班其他任务对照是观察性证据；任务内容和学生差异未被实验控制，不能证明因果。'})
    return clues


def _completion_attribution(rows):
    class_labels = {x['id']: x['name'] for x in CLASSES}
    knowledge_labels = {'fraction': '分数运算', 'linear': '一元一次方程', 'argument': '议论文论证'}
    partitions = [('class', '按班级', lambda x: (x['class_id'], class_labels.get(x['class_id'], x['class_id']))),
                  ('knowledge', '按知识点', lambda x: (x['knowledge_id'], knowledge_labels.get(x['knowledge_id'], x['knowledge_id']))),
                  ('task', '按任务', lambda x: (f"{x['class_id']}:{x['task_id']}", f"{x['class_id']} · {x['task_title']}（{x['task_id']}）"))]
    breakdowns = []
    for dimension, label, identity in partitions:
        grouped = defaultdict(list)
        for row in rows:
            grouped[identity(row)].append(row)
        groups = [{'key': key, 'label': name, **_evidence_totals(subset)} for (key, name), subset in sorted(grouped.items())]
        breakdowns.append({'dimension': dimension, 'label': label, 'rows': _rate_contributions(groups)})
    classes = breakdowns[0]['rows']
    total = sum(x['contribution_pp'] for x in classes)
    main = min(breakdowns[2]['rows'], key=lambda x: x['contribution_pp'])
    if total < -1e-9:
        headline = f"完成率下降 {abs(total):.2f} 个百分点；{main['label']}贡献 {main['contribution_pp']:+.2f} 个百分点，优先核查该任务。"
    elif total > 1e-9:
        headline = f'完成率提高 {total:.2f} 个百分点，可按班级、知识点和任务查看变化来源。'
    else:
        headline = '整体完成率没有变化；继续查看各任务是否存在相互抵消的变化。'
    clues = _attribution_clues(rows)
    next_steps = []
    for cls in classes:
        if cls['contribution_pp'] >= -1e-9:
            continue
        class_rows = [x for x in rows if x['class_id'] == cls['key']]
        class_clues = _attribution_clues(class_rows)
        supported = [x for x in class_clues if x['status'] == 'supported']
        title = '先核对任务时间，再安排跟进' if any(x['id'] in {'late_release', 'deadline_open'} for x in supported) else '核对未完成任务，再安排跟进'
        detail = supported[0]['next_step'] if supported else '核查未完成任务与学生反馈，补齐发布时间、截止窗口和题目难度证据，再决定教学安排。'
        next_steps.append({'title': title, 'detail': detail, 'class_id': cls['key'], 'module': 'intervention'})
    return {'headline': headline, 'observational_only': True, 'total_change_pp': total,
            'method': '对称分子与分母贡献分解',
            'method_note': '各维度独立拆分同一总体变化，不把三个维度相加。完成数贡献＝完成数变化×两期总分母倒数均值；分母贡献＝任务数变化×负的两期完成数之和÷两倍总分母乘积。当前报告要求两周任务范围完整配对，范围缺失时先核对数据。',
            'decomposition': {key: sum(x[key] for x in classes) for key in ('completion_effect_pp', 'denominator_effect_pp')},
            'breakdowns': breakdowns, 'clues': clues, 'next_steps': next_steps}


def _attribution_summary(rows, conditions, source_hash):
    attribution = _completion_attribution(rows)
    return {key: attribution[key] for key in ('headline', 'observational_only', 'clues', 'next_steps')} | {
        'source_hash': source_hash, 'source': '已复算的配对任务明细',
        'scope': {'class_id': rows[0]['class_id'], 'baseline_period': conditions['baseline_period'],
                  'current_period': conditions['current_period'], 'dataset': conditions.get('dataset', 'workspace'),
                  'dataset_label': DATASET_LABELS[conditions.get('dataset', 'workspace')]}}


def _verify_and_report(events, conditions, rows):
    raw, metric = _raw_snapshot(events, conditions)
    raw_body = raw.export()
    expected = independent_review(raw, metric)
    required = {"group_id", "baseline", "baseline_denominator", "current", "numerator", "denominator", "school_id", "class_id", "grade", "knowledge_id", "existing_minutes"}
    if not rows or any(not required <= set(x) for x in rows):
        raise ValueError("模拟结果不含完整指标与范围字段，不能生成演示报告")
    if len({x["group_id"] for x in rows}) != len(rows):
        raise ValueError("查询结果存在重复班级，独立复算未通过")
    expected_by_group = defaultdict(list)
    for x in raw_body["rows"]:
        expected_by_group[x["group_id"]].append(x)
    if {x["group_id"] for x in rows} != set(expected_by_group):
        raise ValueError("SQL 结果遗漏或增加班级，独立复算未通过")
    for row in rows:
        source = expected_by_group[row["group_id"]]
        reference = {"baseline": sum(x["baseline"] for x in source), "baseline_denominator": len(source),
                     "current": sum(x["current"] for x in source), "numerator": sum(x["numerator"] for x in source), "denominator": len(source)}
        reference.update({k: source[0][k] for k in ("school_id", "class_id", "grade", "knowledge_id", "existing_minutes")})
        reference['knowledge_id'], reference['knowledge_selection'] = _knowledge_focus(source)
        if any(row.get(k) != v for k, v in reference.items()):
            raise ValueError("模拟复算门禁：预设结果与演示任务口径不一致，报告已拦截，请检查分母")
    denominator = sum(x["denominator"] for x in rows)
    if denominator <= 0:
        raise ValueError("分母为零，无法计算完成率")
    draft = {"snapshot_id": raw_body["snapshot_id"], "metric_version": metric.version, "source_hash": raw_body["source_hash"],
             "contributions": {x["group_id"]: str(x["current"] - x["baseline"]) for x in rows},
             "total_change": str(sum(x["current"] - x["baseline"] for x in rows)),
             "ratio": str(Decimal(sum(x["numerator"] for x in rows)) / Decimal(denominator))}
    checked = release(raw, draft, expected)
    attribution = _completion_attribution(raw_body['rows'])
    before = sum(x["baseline"] for x in rows)
    before_n = sum(x["baseline_denominator"] for x in rows)
    after = sum(x["current"] for x in rows)
    before_rate, after_rate = before / before_n, after / denominator
    detail = [{**x, "baseline_rate": x["baseline"] / x["baseline_denominator"],
               "current_rate": x["current"] / x["denominator"],
               "count_change": x["current"] - x["baseline"],
               "change_pp": (x["current"] / x["denominator"] - x["baseline"] / x["baseline_denominator"]) * 100} for x in rows]
    exported = Snapshot.create(raw_body['tenant_id'], metric.version, [{**x, "optional": False, "region": "qingxi" if x["school_id"] == "school-qx" else "shuyuan",
        "baseline_period": conditions["baseline_period"], "current_period": conditions["current_period"],
        'dataset': conditions.get('dataset', 'workspace'), 'dataset_label': DATASET_LABELS[conditions.get('dataset', 'workspace')],
        "simulation": True, "raw_snapshot_hash": raw_body["source_hash"],
        "attribution_summary": _attribution_summary([item for item in raw_body['rows'] if item['class_id'] == x['class_id']], conditions, raw_body['source_hash'])} for x in rows]).export()
    # Store exact bytes-derived objects; callers get independent JSON copies.
    return {"verified": True, "verification_kind": "模拟复算门禁", "simulation": True, "sql_executed": False, "model_calls": 0, "summary": {"baseline_completed": before, "baseline_required": before_n,
            "current_completed": after, "current_required": denominator, "baseline_rate": before_rate,
            "current_rate": after_rate, "change_pp": (after_rate - before_rate) * 100,
            "count_change": after - before}, "groups": detail, "review": checked,
            "snapshot": exported, "raw_snapshot": raw_body, "attribution": attribution,
            "conclusion": f"本期完成率 {after_rate:.2%}，基准期 {before_rate:.2%}，变化 {(after_rate-before_rate)*100:+.2f} 个百分点。完成数量变化 {after-before:+d} 份。",
            "interpretation": "贡献拆解说明变化发生在哪些任务；原因线索依据任务记录与前后对照，仍需核查。统计贡献和线索支持不等于已证明原因，不能据此认定学生能力下降或干预有效。"}


def _view(state):
    allowed = set(state["allowed_classes"])
    conditions = (state.get('plan') or {}).get('conditions', {})
    selected = conditions.get('dataset', 'workspace')
    datasets = [{**item, 'source': _source_statistics(_dataset_events(state, item['id']), {**conditions, 'dataset': item['id']})} for item in DATASETS]
    source = next(item['source'] for item in datasets if item['id'] == selected)
    return {"mode": "预设场景模拟 · 无数据库查询、无模型调用", "simulation": True, "sql_executed": False, "model_calls": 0,
            "data_source": "合成教学演示数据", "examples": [x for x in [*EXAMPLES, ESSAY_EXAMPLE] if set(x['class_ids']) <= allowed], "demo_cases": DEMO_CASES,
            "classes": [x for x in CLASSES if x["id"] in allowed], "periods": PERIODS,
            "catalog": CATALOG, 'datasets': datasets, 'selected_dataset': selected,
            "defaults": {"class_ids": state.get("default_classes", sorted(allowed)), "baseline_period": PERIODS[1], "current_period": PERIODS[2], "include_optional": False, 'dataset': selected},
            "source": source,
            "essay_source": {"published_records": len(state.get('essay_formal', [])), 'note': '来自P3正式发布记录；练习与正式测评分开统计'},
            "plan": state["plan"], "result": state["result"], "history": state["history"][-8:]}


def handle(state, action, payload, model=None):
    if action == "get":
        return deepcopy(_view(state))
    if action == "plan":
        question = payload.get("question", "本周各班作业完成率为什么下降？")
        if not isinstance(question, str) or not question.strip() or len(question) > 1200:
            raise ValueError("请填写 1–1200 字的问题")
        is_essay = bool(re.search(r'作文|评阅|写作', question) and re.search(r'成绩|平均分|得分|维度|薄弱', question))
        if is_essay and not re.search(r'完成率|交作业|提交率', question):
            conditions = _question_selection(state, question, payload)
            if conditions['dataset'] != 'workspace':
                raise ValueError('作文成绩请使用当前工作区已发布记录；完整归因案例只支持作业完成率')
            conditions = {k: conditions[k] for k in ('class_ids', 'auth_epoch', 'dataset')}
            kind = payload.get('assessment_type', 'practice')
            if kind not in {'practice', 'formal'}:
                raise ValueError('请选择练习作文或正式测评，不混合两种成绩')
            conditions.update(assessment_type=kind, window='当前已发布版本，每篇作文取最新发布记录')
            if 'source_essay' in payload:
                conditions['source_essay'] = deepcopy(payload['source_essay'])
            source = _essay_source(state, conditions)
            plan = {'id': str(uuid4()), 'supported': True, 'simulation': True, 'question': question.strip(),
                'conditions': conditions, 'metric_kind': 'essay_quality', 'mode': '已发布作文分析演示',
                'metric': '作文得分率 = 已发布作文总得分 ÷ 对应满分总和；均分另按篇数计算',
                'grain': '学校＋班级＋作文；每篇最新发布版本，不含草稿或AI初评分',
                'planning_note': '统计当前已发布记录；练习与正式测评不混算，不使用作业完成率分母。SQL仅用于讲解。',
                'source_hash': digest(source), 'sql': _essay_sql(conditions),
                'steps': ['选择已发布成绩类型', '每篇保留最新发布版本', '单独核对得分分母', '查看人工复核的薄弱维度', '生成作文干预快照']}
            state.update(plan=plan, result=None, latest_verified_snapshot=None)
            return deepcopy(plan)
        if is_essay or not any(word in question for word in ["完成", "提交", "交作业"]) or any(word in question for word in ["平均分", "得分率", "正确率", "出勤率", "男女比例"]):
            state.update(plan=None, result=None, latest_verified_snapshot=None)
            return {"supported": False, "simulation": True,
                    "message": "这个问题还没有对应演示。完成率与作文成绩需分开分析；你可以先试完成率、选做口径，或已发布作文的薄弱维度。",
                    "examples": deepcopy([x for x in EXAMPLES if set(x['class_ids']) <= set(state['allowed_classes'])])}
        conditions = _question_selection(state, question, payload)
        plan = {"id": str(uuid4()), "supported": True, "simulation": True, "question": question.strip(), "conditions": conditions,
                "mode": "预设场景模拟", "metric_kind": "completion", "metric": "完成率 = 已完成学生×任务实例 ÷ 应完成学生×任务实例",
                "grain": "学校＋班级＋学生＋任务＋统计周；同任务重复提交只计一次",
                "planning_note": "按预设场景展示问数流程；统计周由表单指定。SQL 仅作讲解，不执行数据库查询。",
                "sql": _default_sql(conditions), "steps": ["选择演示班级", "查看任务去重口径", "选择窗口与选做条件", "展示查询结果", "模拟复算门禁"]}
        plan['source'] = _source_statistics(_authorized_events(state, conditions), conditions)
        state.update(plan=plan, result=None, latest_verified_snapshot=None)
        return deepcopy(plan)
    if action in {"run", "query"}:
        plan = state.get("plan")
        if not plan or payload.get("plan_id") != plan["id"]:
            raise ValueError("请先生成当前分析计划，旧计划不能重放为新条件")
        essay_mode = plan.get('metric_kind') == 'essay_quality'
        if essay_mode:
            source, rows, shown_sql, case = _essay_report(state, plan, payload)
        else:
            events = _authorized_events(state, plan["conditions"])
            rows, shown_sql, case = _demo_query(events, plan, payload)
        dataset = plan['conditions'].get('dataset', 'workspace')
        dataset_label = ('当前工作区已发布' + ('正式测评作文' if plan['conditions']['assessment_type'] == 'formal' else '练习作文')) if essay_mode else DATASET_LABELS[dataset]
        if action == "query":
            return {"rows": rows, "count": len(rows), "sql": shown_sql, "query_ms": None, "report_published": False,
                    "simulation": True, "sql_executed": False, "model_calls": 0, "demo_case": case,
                    'dataset': dataset, 'dataset_label': dataset_label}
        report = _verify_essay(source, rows, plan) if essay_mode else _verify_and_report(events, plan["conditions"], rows)
        report.update(sql=shown_sql, query_ms=None, demo_case=case, conditions=plan["conditions"], mode=plan["mode"], plan_id=plan["id"])
        report.update(dataset=dataset, dataset_label=dataset_label)
        if not essay_mode:
            report['source'] = _source_statistics(events, plan['conditions'])
        state["result"] = report
        state["latest_verified_snapshot"] = deepcopy(report["snapshot"])
        state["history"].append({"id": report["snapshot"]["snapshot_id"], "question": plan["question"], "conclusion": report["conclusion"], "at": datetime.now(timezone.utc).isoformat(), 'dataset': report['dataset']})
        return deepcopy(report)
    raise ValueError("不支持的学情分析操作")
