"""Preset essay demo with local evidence checks, versioned review and no model calls."""
from copy import deepcopy
from datetime import datetime, timezone
from uuid import uuid4
import re
import base64
import binascii
import struct
from hashlib import sha256

from backend.vendor.essay_core import ocr_text, validate_score, qwk
from backend.demo_cases import SCAN_SAMPLES

SAMPLE = """放学后，教室窗外忽然下起了雨，我忘了带伞。\n同桌小雨把书包放好，说我们一起走吧。\n走到校门口，我发现她的右肩已经湿了，伞却一直偏向我。\n我把伞往她那边推了推，两个人笑着踩过浅浅的水洼。\n那天我明白，帮助别人不一定要做很大的事，也可以是雨里让出的一点位置。"""
ACTORS = {"teacher-a": "李老师 · 二评", "teacher-b": "周老师 · 三评", "lead": "王老师 · 负责人"}
RUBRIC = {"id": "rubric-narrative-v1", "version": 1, "dimensions": {"内容": 6, "结构": 6, "语言": 6}}
STATE_LABELS = {"awaiting_correction": "待核对识别稿", "awaiting_ai": "待初评", "manual": "人工评阅", "awaiting_second": "待教师盲评", "third_required": "待教研员独立复核", "awaiting_approval": "正式成绩待校长确认", "approved": "已确认待发布", "published": "已发布", "withdrawn": "已撤回，待更正重评"}

SAMPLES = {
    "rain-clear": {"id": "rain-clear", "label": "清晰扫描件", "description": "单页习作，核对识别稿后开始初评", "title": "雨中的一件小事", "low_lines": [], "url": "./essay-samples/rain-clear.svg"},
    "rain-blurry": {"id": "rain-blurry", "label": "模糊照片", "description": "两处识别存疑，校对后交人工评阅", "title": "雨中的一件小事", "low_lines": [2, 4], "url": "./essay-samples/rain-blurry.svg"},
}
SAMPLES.update(SCAN_SAMPLES)


def checked_preview(value):
    """Accept only a small raster preview, never an arbitrary URL or SVG."""
    if not isinstance(value, str) or len(value) > 110000:
        raise ValueError("图片预览超过80KB或格式无效")
    match = re.fullmatch(r"data:image/(jpeg|png);base64,([A-Za-z0-9+/=]+)", value)
    if not match:
        raise ValueError("图片预览仅支持JPEG或PNG")
    try:
        raw = base64.b64decode(match[2], validate=True)
    except (binascii.Error, ValueError):
        raise ValueError("图片预览编码无效") from None
    if not 1 <= len(raw) <= 80 * 1024:
        raise ValueError("图片预览超过80KB")
    width = height = 0
    if match[1] == "png" and raw.startswith(b"\x89PNG\r\n\x1a\n") and len(raw) >= 45 and raw[12:16] == b"IHDR" and raw.endswith(b"IEND\xaeB`\x82"):
        width, height = struct.unpack(">II", raw[16:24])
    elif match[1] == "jpeg" and raw.startswith(b"\xff\xd8\xff") and raw.endswith(b"\xff\xd9"):
        pos = 2
        while pos + 4 <= len(raw) and raw[pos] == 255:
            kind = raw[pos + 1]
            if kind in (0xDA, 0xD9):
                break
            length = int.from_bytes(raw[pos + 2:pos + 4], "big")
            if length < 2 or pos + 2 + length > len(raw):
                break
            if kind in (0xC0, 0xC1, 0xC2) and length >= 8:
                height, width = struct.unpack(">HH", raw[pos + 5:pos + 9])
                break
            pos += 2 + length
    if not (1 <= width <= 2400 and 1 <= height <= 2400):
        raise ValueError("图片预览文件头或尺寸无效")
    return {"preview": value, "preview_width": width, "preview_height": height, "storage": "preview"}


def ingestion(payload):
    source = payload["source"]
    if not isinstance(source, dict):
        raise ValueError("请选择作文原稿来源")
    kind = source.get("kind")
    if kind == "sample":
        sample = SAMPLES.get(source.get("sample_id"))
        if not sample:
            raise ValueError("请选择已有扫描件示例")
        original = sample.get("ocr_text", sample.get("text", SAMPLE))
        low = sample["low_lines"]
        if low and "ocr_text" not in sample:
            original = original.replace("右肩", "右启").replace("位置", "位直")
        clean_source = {"kind": kind, "sample_id": sample["id"], "name": sample["label"], "storage": "bundled", "pages": [{"number": 1, "url": sample["url"]}]}
        engine = "fixture"
    elif kind == "upload":
        if source.get("mime") not in {"image/jpeg", "image/png"}:
            raise ValueError("自选图片仅支持JPG或PNG")
        clean_source = {"kind": kind, "name": text(source.get("name"), "图片文件名", 150), "mime": source["mime"],
                        "size": integer(source.get("size"), "图片大小", 1, 20 * 1024 * 1024),
                        "width": integer(source.get("width"), "图片宽度", 1, 20000), "height": integer(source.get("height"), "图片高度", 1, 20000),
                        "storage": "browser-session", "pages": []}
        if "preview" not in source:
            raise ValueError("请附上可保存的图片预览，以便后续对照原稿复核")
        clean_source.update(checked_preview(source["preview"]))
        original, low, engine = "", [], "unavailable"
    elif kind == "text":
        clean_source = {"kind": kind, "name": "文字录入", "storage": "none", "pages": []}
        original, low, engine = text(payload.get("text"), "作文正文"), [], "manual"
    else:
        raise ValueError("请选择扫描件、图片或文字来源")
    lines = [{"id": str(i + 1), "text": line, "confidence": .62 if i in low else .99, "needs_review": i in low} for i, line in enumerate(original.splitlines())]
    correction = {"confirmed": False, "ocr_engine": engine, "lines": lines, "confirmed_line_ids": []}
    quality = {"mode": "扫描件识别稿" if kind == "sample" else "人工录入" if kind == "text" else "图片待人工转写",
               "low_lines": len(low), "lines": len(lines), "ratio": len(low) / len(lines) if lines else 0,
               "manual_required": kind == "upload" or (bool(lines) and len(low) / len(lines) > .2)}
    return clean_source, original, correction, quality


def now():
    return datetime.now(timezone.utc).isoformat()


def initial_state():
    pairs = [[i % 6, i % 6 if i % 7 else min(5, i % 6 + 1)] for i in range(36)]
    return {"sample_text": SAMPLE, "rubric": deepcopy(RUBRIC), "actors": ACTORS,
            "records": [], "active_id": None, "formal": [], "calibration_pairs": pairs,
            "bucket": qwk(pairs, 6), "events": []}


def integer(value, label, low=0, high=30000):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label}必须是 {low}～{high} 的整数")
    return value


def text(value, label, limit=30000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"请填写{label}，最多 {limit} 字符")
    return value.strip()


def actor_of(payload, required=None):
    actor = payload.get("actor", "teacher-a")
    if actor not in ACTORS or (required and actor not in required):
        raise ValueError("当前演示角色不能执行这一步，请切换到对应教师")
    return actor


def record_of(state, payload):
    rid = payload.get("id") or state["active_id"]
    for row in state["records"]:
        if row["id"] == rid:
            return row
    raise ValueError("请先提交一篇作文")


def check_version(row, payload):
    if type(payload.get("version")) is not int or payload["version"] != row["version"]:
        raise ValueError("作文版本已经变化，请刷新后再操作")


def emit(state, row, action, actor, detail):
    event = {"id": str(uuid4()), "at": now(), "action": action, "actor": actor,
             "object_type": "essay", "object_id": row["id"], "version": row["version"], "detail": detail}
    row.setdefault("history", []).append(event)
    state["events"].append(event)


def public_record(row, actor):
    out = deepcopy(row)
    out["state_label"] = STATE_LABELS[row["state"]]
    visible = row.get("second_actor") == actor or (actor == "lead" and row["state"] in {"awaiting_approval", "approved", "published"})
    # Third reviewer also remains blind until their independent score has committed.
    visible = visible or row.get("third_actor") == actor
    if not visible:
        for key in ["ai_score", "invalidated_candidate", "second_score", "third_score", "final_score", "approval", "second_dimensions", "third_dimensions", "final_dimensions"]:
            out.pop(key, None)
        for event in out.get("history", []):
            if event["action"] in {"second", "third", "approve"}:
                event["detail"] = "独立评分已提交；本人评分前隐藏他人判断"
    out["candidate_hidden"] = not visible and "ai_score" in row
    return out


def view(state, actor="teacher-a"):
    return {"sample_text": state["sample_text"], "rubric": state["rubric"], "actors": ACTORS,
            "records": [public_record(r, actor) for r in reversed(state["records"])],
            "active_id": state["active_id"], "formal": deepcopy(state["formal"]),
            "bucket": state["bucket"], "calibration_pairs": state["calibration_pairs"],
            "current_published_count": len({r["essay_id"] for r in state["formal"] if r.get("status", "published") == "published"}),
            "samples": deepcopy(list(SAMPLES.values())),
            "input_mode": "扫描件 → 核对识别稿 → 确认 → 初评与教师复核"}


def local_candidate(essay, rubric):
    """Preset scores let visitors play the review flow; they are not inferred grading."""
    paragraphs = [p.strip() for p in essay.splitlines() if p.strip()]
    if essay == SAMPLE:
        scores = {"内容": 6, "结构": 6, "语言": 5}
        reasons = ["以忘带伞引出同桌的帮助，事件和人物交代清楚。", "从放学遇雨、共伞回家到领悟，叙事顺序完整。", "“伞却一直偏向我”用动作表现关心，结尾可以更含蓄。"]
    else:
        # Transparent local length/paragraph exercise, never inferred quality.
        length = len(essay)
        scores = {"内容": min(5, 1 + length // 55), "结构": min(5, 1 + len(paragraphs)), "语言": min(5, 1 + len(re.findall(r"[。！？]", essay)) // 2)}
        reasons = ["请结合这段原文核对事件是否具体、是否贴合作文题目。", "请对照全文核对段落承接与叙事顺序，再确定结构分。", "请核对用词、句式和标点，并指出一处可修改的表达。"]
    quotes = [paragraphs[0][:32], paragraphs[min(1, len(paragraphs) - 1)][:32], paragraphs[-1][:32]]
    if essay == SAMPLE:
        quotes[2] = paragraphs[2]
    return {"dimensions": [{"name": name, "score": min(scores[name], maximum), "quote": quotes[i], "reason": reasons[i]} for i, (name, maximum) in enumerate(rubric["dimensions"].items())]}


def review_dimensions(row, score, supplied=None):
    limits = row["rubric"]["dimensions"]
    if supplied is not None:
        if not isinstance(supplied, dict) or set(supplied) != set(limits):
            raise ValueError("人工维度评分必须覆盖全部评分细则")
        values = {name: integer(supplied[name], f"{name}维度", 0, cap) for name, cap in limits.items()}
        if sum(values.values()) != score:
            raise ValueError("人工维度评分合计必须等于总分")
        source = "reviewer"
    else:
        # Old score-only demos remain usable, but never become independent
        # dimension evidence for learning analytics.
        values = {name: score * cap // row["max_score"] for name, cap in limits.items()}
        remainder = score - sum(values.values())
        for name, cap in limits.items():
            add = min(remainder, cap - values[name]); values[name] += add; remainder -= add
        source = "demo_total_allocation"
    return [{"name": name, "score": values[name], "max_score": cap} for name, cap in limits.items()], source


def finalize_review(row, score, actor, reason, dimensions, source):
    row.update(final_score=score, final_dimensions=deepcopy(dimensions), dimension_source=source,
               approval={"id": str(uuid4()), "actor": actor, "reason": reason,
                         "text_sha256": sha256(row["text"].encode()).hexdigest()}, state="approved")


def handle(state, action, payload=None, model=None):
    payload = payload or {}
    if action == "get":
        return view(state, actor_of(payload))
    if action == "create":
        actor = actor_of(payload)
        source = correction = None
        if "source" in payload:
            source, parsed, correction, input_quality = ingestion(payload)
            manual = input_quality["manual_required"]
        else:
            essay = text(payload.get("text"), "作文正文")
            lines = [p.strip() for p in essay.splitlines() if p.strip()]
            low = integer(payload.get("low_confidence_lines", 0), "模拟低置信行数", 0, len(lines))
            parsed, manual = ocr_text([{"text": p, "confidence": .6 if i < low else .99} for i, p in enumerate(lines)])
            input_quality = {"mode": "模拟输入", "low_lines": low, "lines": len(lines), "ratio": low / len(lines)}
        manual = manual or not state["bucket"]["enabled"]
        class_id = payload.get("class_id", "7A")
        if class_id not in {"7A", "7B", "8A"}:
            raise ValueError("请选择演示班级")
        assessment_type = payload.get("assessment_type", "practice")
        if assessment_type not in {"practice", "formal"}:
            raise ValueError("请选择课堂练习或正式成绩")
        student_id = payload.get("student_id", f"{class_id}-S01")
        if not isinstance(student_id, str) or not re.fullmatch(re.escape(class_id) + r"-S\d{2,4}", student_id):
            raise ValueError("学生编号须属于当前班级，例如 7A-S01")
        row = {"id": str(uuid4()), "version": 1, "school_id": "school-sy" if class_id == "8A" else "school-qx",
               "class_id": class_id, "student_id": student_id, "assessment_type": assessment_type,
               "knowledge_id": "argument", "text": parsed, "title": text(payload.get("title", "雨中的一件小事"), "作文题目", 100),
               "rubric": deepcopy(state["rubric"]), "max_score": sum(state["rubric"]["dimensions"].values()), "gap": 3,
               "quality": input_quality, "assignment": text(payload.get("assignment", "叙事习作练习"), "作业名称", 100),
               "state": "awaiting_correction" if source else "manual" if manual else "awaiting_ai", "created_at": now(), "history": []}
        if source:
            row.update(source=source, correction=correction)
        row.update(source_text=parsed, confirmation_history=[])
        state["records"].append(row); state["active_id"] = row["id"]
        emit(state, row, "create", actor, "原稿已登记，等待核对并确认识别稿" if source else "提交文本；低置信比例超过20%或桶关闭时转人工")
        return {"record": public_record(row, actor)}
    if action == "calibrate":
        actor_of(payload, {"teacher-b"})
        pairs = payload.get("pairs", state["calibration_pairs"])
        if not isinstance(pairs, list) or len(pairs) > 500 or any(not isinstance(p, list) or len(p) != 2 for p in pairs):
            raise ValueError("评分配对必须为最多500行的二维数组，每行两个分数")
        scale = integer(payload.get("scale", 6), "档位数量", 2, 20)
        result = qwk(pairs, scale, min_samples=30)
        state["calibration_pairs"] = deepcopy(pairs);state["bucket"] = result
        if not result["enabled"]:
            for row in state["records"]:
                if row["state"] == "awaiting_ai":
                    row.update(state="manual", version=row["version"] + 1)
                    emit(state, row, "route_manual", "teacher-b", "QWK桶关闭，保留作文ID转人工")
                elif row["state"] not in {"published", "withdrawn"} and "ai_score" in row:
                    # An untrusted candidate cannot keep a practice approval valid.
                    row["invalidated_candidate"] = row.pop("ai_score")
                    row["version"] += 1
                    if "third_score" not in row:
                        for key in ("approval", "final_score", "final_dimensions", "dimension_source"):
                            row.pop(key, None)
                        row["state"] = "third_required" if "second_score" in row else "manual"
                        row["review_reason"] = "评分质量门禁关闭，需教研员独立复核"
                    emit(state, row, "route_manual", "teacher-b", "评分质量门禁关闭，未发布的自动候选失效；已完成的独立人工复核保留")
        return {"calibration": result, "pair_source": "可编辑合成评分配对"}
    row = record_of(state, payload)
    if action == "release":
        practice = row.get("assessment_type", "formal") == "practice"
        expected = row.get("second_actor", "teacher-a") if practice else "lead"
        actor = actor_of(payload)
        if actor != expected:
            raise ValueError("课堂练习由原任课教师发布；正式成绩由校长批准并发布")
        key = text(payload.get("key"), "发布幂等键", 100)
        prior = next((r for r in state["formal"] if r["key"] == key), None)
        if prior:
            if prior["essay_id"] != row["id"] or prior["approved_version"] != payload.get("version") or row["state"] != "published":
                raise ValueError("同一发布键不能用于不同作文或批准版本")
            return {"formal": deepcopy(prior), "replayed": True, "record": public_record(row, actor)}
        check_version(row, payload)
        if row["state"] != "approved" or not row.get("approval"):
            raise ValueError("必须完成当前类型要求的评阅与确认，再显式发布")
        text_hash = sha256(row["text"].encode()).hexdigest()
        if row["approval"].get("text_sha256", text_hash) != text_hash:
            raise ValueError("正文与确认评分不一致，请重新评阅")
        formal = {"id": str(uuid4()), "essay_id": row["id"], "approved_version": row["version"], "key": key,
                  "version": row["version"], "school_id":row["school_id"], "class_id":row["class_id"],
                  "student_id":row.get("student_id", f"{row['class_id']}-S01"), "knowledge_id":row["knowledge_id"],
                  "assessment_type":row.get("assessment_type", "formal"), "score": row["final_score"], "max_score": row["max_score"],
                  "dimensions":deepcopy(row.get("final_dimensions", [])), "dimension_source":row.get("dimension_source", "legacy_total_only"),
                  "decision_id": row["approval"]["id"], "published_at": now(), "status": "published",
                  "text_sha256": text_hash, "text_snapshot": row["text"], "assignment": row.get("assignment", ""), "title": row["title"]}
        for previous in state["formal"]:
            if previous["essay_id"] == row["id"] and previous.get("status", "published") == "published":
                previous["status"] = "superseded"
        state["formal"].append(formal);row.update(state="published", version=row["version"] + 1)
        emit(state, row, "publish", actor, "课堂练习反馈已发布；相同业务键复用结果" if practice else "正式成绩已发布；相同业务键复用结果")
        return {"formal": deepcopy(formal), "replayed": False, "record": public_record(row, actor)}
    check_version(row, payload)
    if action == "withdraw":
        expected = row.get("second_actor", "teacher-a") if row.get("assessment_type", "formal") == "practice" else "lead"
        actor = actor_of(payload, {expected})
        reason = text(payload.get("reason"), "撤回原因", 1000)
        if row["state"] != "published":
            raise ValueError("仅当前已发布成绩可以撤回；撤回后由任课教师更正并重新评阅")
        at = now()
        for published in state["formal"]:
            if published["essay_id"] == row["id"] and published.get("status", "published") == "published":
                published.update(status="withdrawn", withdrawn_at=at, withdrawn_by=actor, withdrawal_reason=reason)
        row.update(state="withdrawn", version=row["version"] + 1)
        emit(state, row, "withdraw", actor, f"已从当前成绩统计撤回，原发布历史保留：{reason}")
        return {"record": public_record(row, actor)}
    if action == "confirm_text":
        actor = actor_of(payload, {"teacher-a"})
        if row["state"] != "awaiting_correction" or not row.get("correction"):
            raise ValueError("当前识别稿不能重复确认")
        revised = text(payload.get("text"), "校对后的作文正文")
        confirmed = payload.get("confirmed_line_ids", [])
        required = {line["id"] for line in row["correction"]["lines"] if line["needs_review"]}
        if not isinstance(confirmed, list) or any(not isinstance(item, str) for item in confirmed) or not required.issubset(set(confirmed)):
            raise ValueError("请逐项核对并勾选待确认段落")
        row["correction"].update(confirmed=True, confirmed_line_ids=sorted(required), confirmed_at=now(), confirmed_by=actor)
        row.update(text=revised, version=row["version"] + 1,
                   state="manual" if row["quality"].get("manual_required") or not state["bucket"]["enabled"] else "awaiting_ai")
        row["confirmed_text_sha256"] = sha256(revised.encode()).hexdigest()
        row.setdefault("confirmation_history", []).append({"version": row["version"], "text": revised, "text_sha256": row["confirmed_text_sha256"], "actor": actor, "at": now()})
        emit(state, row, "confirm_text", actor, "已对照原稿确认正文；" + ("输入质量要求人工评阅" if row["state"] == "manual" else "可以开始初评"))
        return {"record": public_record(row, actor)}
    if action == "revise":
        actor = actor_of(payload)
        if row["state"] == "published":
            raise ValueError("已发布正文不可变；请先撤回成绩，再在同一作文记录上更正并重新评阅")
        revised = text(payload.get("text"), "修订正文")
        lines = [p.strip() for p in revised.splitlines() if p.strip()]
        low = integer(payload.get("low_confidence_lines", 0), "模拟低置信行数", 0, len(lines))
        revised, manual = ocr_text([{"text": p, "confidence": .6 if i < low else .99} for i, p in enumerate(lines)])
        for key in ["ai_score", "invalidated_candidate", "second_score", "second_actor", "third_score", "third_actor", "final_score", "approval", "scoring_mode", "second_dimensions", "third_dimensions", "second_dimension_source", "third_dimension_source", "final_dimensions", "dimension_source", "review_reason", "confirmed_text_sha256"]:
            row.pop(key, None)
        row.update(text=revised, state="manual" if manual or not state["bucket"]["enabled"] else "awaiting_ai", version=row["version"] + 1,
                   quality={"mode": "模拟输入", "low_lines": low, "lines": len(lines), "ratio": low / len(lines)})
        if row.get("source"):
            row["correction"].update(confirmed=False, confirmed_line_ids=[])
            row["correction"].pop("confirmed_at", None)
            row["correction"].pop("confirmed_by", None)
            # Revisions cannot erase the original capture's quality gate.
            original = ingestion({"source": row["source"], "text": revised})[3]
            row.update(state="awaiting_correction", quality=original)
        emit(state, row, "revise", actor, "正文新版本，原评分与批准失效；重新确认后方可评阅" if row.get("source") else "正文新版本，原评分与批准失效")
        return {"record": public_record(row, actor)}
    if action == "score":
        if row.get("correction") and not row["correction"]["confirmed"]:
            raise ValueError("请先对照原稿确认识别稿，再开始初评")
        if row["state"] != "awaiting_ai" or not state["bucket"]["enabled"]:
            raise ValueError("当前作文只允许人工评阅，不能再次自动初评")
        # Even a legacy mode=model payload or injected adapter never triggers a model.
        raw = local_candidate(row["text"], row["rubric"])
        try:
            scored = validate_score(raw, row["rubric"], row["text"])
        except (ValueError, TypeError, KeyError, AttributeError):
            raise ValueError("候选分未通过维度、分数或原文引用校验，未写入") from None
        scored["text_sha256"] = sha256(row["text"].encode()).hexdigest()
        row.update(ai_score=scored, scoring_mode="预设候选点评（模拟评分，非模型结果）", state="awaiting_second", version=row["version"] + 1)
        emit(state, row, "candidate", "scorer", "候选已通过引用与细则检查；教师独立二评前隐藏")
        return {"record": public_record(row, "teacher-a")}
    if action in {"second", "third", "approve"}:
        actor = actor_of(payload)
        if actor != {"second":"teacher-a", "third":"teacher-b", "approve":"lead"}[action]:
            raise ValueError("需要另一位独立教研员复核；教师、教研员与校长不能代替彼此评阅")
        score = integer(payload.get("score"), "评分", 0, row["max_score"])
        reason = text(payload.get("reason"), "评阅理由", 1000)
        dimensions, source = review_dimensions(row, score, payload.get("dimensions"))
        practice = row.get("assessment_type", "formal") == "practice"
        if action == "second":
            if row["state"] not in {"awaiting_second", "manual"}:
                raise ValueError("当前状态不能提交二评")
            row.update(second_score=score, second_actor=actor, second_dimensions=deepcopy(dimensions), second_dimension_source=source)
            needs_review = not practice or "ai_score" not in row or abs(row["ai_score"]["total"] - score) > row["gap"]
            if needs_review:
                row["state"] = "third_required"
                row["review_reason"] = "正式成绩独立复核" if not practice else "输入质量或评分分歧需独立复核"
            else:
                finalize_review(row, score, actor, reason, dimensions, source)
        elif action == "third":
            if row["state"] != "third_required" or actor == row.get("second_actor"):
                raise ValueError("需要另一位教师独立复核，不能由二评教师重复提交")
            row.update(third_score=score, third_actor=actor, third_dimensions=deepcopy(dimensions), third_dimension_source=source)
            if practice: finalize_review(row, score, actor, reason, dimensions, source)
            else: row["state"] = "awaiting_approval"
        else:
            if practice or row["state"] != "awaiting_approval" or "third_score" not in row:
                raise ValueError("二评及必要的分歧复核完成后，负责人才能确认")
            reviewed_dimensions = row["third_dimensions"]
            if score != row["third_score"] or (
                payload.get("dimensions") is not None
                and {d["name"]: d["score"] for d in dimensions}
                != {d["name"]: d["score"] for d in reviewed_dimensions}
            ):
                raise ValueError("校长只能确认教研员独立复核的分数与维度；如有异议，请由任课教师更正后重新评阅")
            finalize_review(row, row["third_score"], actor, reason,
                            reviewed_dimensions, row["third_dimension_source"])
        row["version"] += 1;emit(state, row, action, actor, reason)
        return {"record": public_record(row, actor)}
    raise ValueError("不支持的作文操作")
