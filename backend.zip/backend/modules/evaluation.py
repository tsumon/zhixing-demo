"""P2: a simulated evaluation workflow over synthetic, preset materials."""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import json
import time
from uuid import uuid4

from backend.modules import knowledge
from backend.vendor.eval_core import METRIC_VERSION, sha, validate_manifest, score_population, quality_reasons


def _now():
    return datetime.now(timezone.utc).isoformat()


def initial_state():
    return {"synthetic": True, "gold": [], "gold_revision": 1, "runs": [], "last_run": None, "active_policy": None, "gold_history": []}


GOLD_FIELDS = {"id", "document_id", "version_id", "split", "question", "refusal_expected", "relevance", "evidence_ids", "evidence", "stratum", "human_label", "lineage"}


def _gold_item(question, school, version, documents, stratum):
    evidence = [{"chunk_id": c["chunk_id"], "document_id": d["id"], "version_id": d["version"], "text": c["text"]} for d in documents for c in d["chunks"]]
    return {"id": str(uuid4()), "question": question, "school_id": school, "document_id": documents[0]["id"] if documents else str(uuid4()),
            "version_id": version, "split": "test", "refusal_expected": not bool(documents),
            "relevance": {d["id"]: 3 for d in documents}, "evidence_ids": [e["chunk_id"] for e in evidence], "evidence": evidence,
            "stratum": stratum, "human_label": int(bool(documents)), "lineage": [d["series_id"] for d in documents] or [str(uuid4())]}


def _ensure_gold(state, kb):
    if state["gold"]:
        return
    # The reference labels are tied to actual synthetic source documents, not
    # generated from retrieval outputs. Both systems receive the same questions.
    questions = {"fraction": "异分母分数相加应该怎么做，例题怎么算？", "linear": "移项为什么要变号，解方程之后怎样检查？", "argument": "论点、论据和论证的区别是什么？"}
    for doc in kb["documents"]:
        if doc.get("seed_document") and doc["topic_id"] in questions:
            state["gold"].append(_gold_item(questions[doc["topic_id"]], doc["school_id"], doc["version"], [doc], doc["topic_id"]))
    for school in knowledge.SCHOOLS:
        state["gold"].append(_gold_item("海王星到太阳的精确距离是多少公里？", school["id"], "2026", [], "no_evidence"))
    validate_manifest([{k: row[k] for k in GOLD_FIELDS} for row in state["gold"]])


def _gold_integrity(kb, items):
    documents = {d["id"]: d for d in kb["documents"]}
    invalid = []
    for item in items:
        if item["refusal_expected"]:
            continue
        docs = [documents.get(doc_id) for doc_id in item["relevance"]]
        valid_docs = all(d and d["status"] == "published" and d["school_id"] == item["school_id"] and d["version"] == item["version_id"] for d in docs)
        valid_evidence = valid_docs and all(any(c["chunk_id"] == ref["chunk_id"] and c["text"] == ref["text"] for c in documents[ref["document_id"]]["chunks"])
                                          for ref in item["evidence"] if ref["document_id"] in item["relevance"])
        if not valid_docs or not valid_evidence:
            invalid.append("GOLD_EVIDENCE_STALE:" + item["id"])
    return invalid


def _policy(items, payload):
    # The small sample is a functional regression gate, not a production-quality
    # or statistical significance claim. Thresholds are shown alongside scores.
    floor = payload.get("recall_floor", .8)
    if type(floor) not in (int, float) or not 0 <= floor <= 1:
        raise ValueError("召回率门槛需在 0 到 1 之间")
    return {"floors": {"recall_at_6": floor, "ndcg_at_6": .7, "citation_accuracy": .8, "faithfulness": .8, "refusal_recall": 1.0, "cohen_kappa": .6},
            "max_version_error_rate": 0., "min_judge_samples": 2, "max_regression": .05,
            "strata": {s: ({"refusal_recall": 1.} if s == "no_evidence" else {"recall_at_6": min(floor, .75), "citation_accuracy": .5}) for s in sorted({i["stratum"] for i in items})}}


def _execute(kb, items, strategy, top_k):
    outputs, judgments, answers = [], [], []
    started = time.perf_counter()
    for item in items:
        result = knowledge.retrieve(kb, item["question"], item["school_id"], item["version_id"], strategy, top_k)
        citations = [{k: c[k] for k in ("chunk_id", "document_id", "version_id")} for c in result["citations"]]
        # Demo score uses selected source identity, not LLM answer quality.
        exact = any(result["source_excerpt"] == e["text"] and any(c["chunk_id"] == e["chunk_id"] and c["document_id"] == e["document_id"] and c["version_id"] == e["version_id"] for c in citations) for e in item["evidence"])
        outputs.append({"id": item["id"], "docs": [h["document_id"] for h in result["hits"]], "citations": citations,
                        "version_id": result["version"], "refused": result["refused"], "answer": result["answer"]})
        judgments.append({"id": item["id"], "faithful": exact, "label": int(not result["refused"])})
        answers.append({"id": item["id"], "question": item["question"], "school_id": item["school_id"], "version": item["version_id"],
                        "answer": result["answer"], "refused": result["refused"], "hits": result["hits"], "citations": citations,
                        "expected_document_ids": list(item["relevance"]), "source_exact_match": exact, "trace": result["trace"]})
    metrics, strata, rows = score_population(items, outputs, judgments)
    return {"strategy": strategy, "top_k": top_k, "duration_ms": round((time.perf_counter() - started) * 1000, 2),
            "metrics": metrics, "strata": strata, "per_item": rows, "answers": answers, "outputs": outputs,
            "judgment_kind": "模拟评分：预设资料与引用匹配，不是实际模型测评", "simulated": True, "model_calls": 0}



def _corpus_hash(kb):
    # Only live retrieval material is part of this release. An unpublished draft
    # does not invalidate a report; published content and real chunks do.
    fields = ("id", "school_id", "version", "title", "topic_id", "source_hash", "text", "chunks", "relation_assertions", "seed_document")
    docs = [{key: d.get(key) for key in fields} for d in kb["documents"] if d["status"] == "published"]
    return sha({"documents": sorted(docs, key=lambda d: d["id"]), "current_versions": kb["current_versions"]})


def _input_signature(run):
    payload = {"corpus": run["corpus_hash"], "gold": run["gold_hash"],
                "strategy": run["candidate"]["strategy"], "top_k": run["candidate"]["top_k"],
                "policy": run["policy"], "metric_version": run["metric_version"], "baseline_policy_id": run.get("baseline_policy_id")}
    if "retrieval_version" in run:
        payload["retrieval_version"] = run["retrieval_version"]
    return sha(payload)


def _result_signature(run):
    return sha({k: run[k] for k in ("input_signature", "baseline", "candidate", "delta", "gate")})


def _activation(state, kb, run):
    reasons = []
    if run.get("retrieval_version") != knowledge.RETRIEVAL_VERSION: reasons.append("检索规则已更新")
    if run.get("corpus_hash") != _corpus_hash(kb): reasons.append("已发布资料发生变化")
    if run.get("gold_hash") != sha(state["gold"]): reasons.append("评测金标发生变化")
    if run.get("input_signature") != _input_signature(run) or run.get("result_signature") != _result_signature(run):
        reasons.append("报告参数或结果签名不一致")
    active_id = (state.get("active_policy") or {}).get("run_id")
    if active_id not in {run["id"], run.get("baseline_policy_id")}:
        reasons.append("当前检索基线已切换")
    accepted = run.get("business_acceptance") or {}
    business = accepted.get("accepted") is True and accepted.get("result_signature") == run.get("result_signature")
    technical = run["gate"]["passed"] is True
    return {"fresh": not reasons, "stale_reasons": reasons, "technical_passed": technical,
            "business_accepted": business, "can_activate": not reasons and technical and business,
            "active": state.get("active_policy", {}).get("run_id") == run["id"] if state.get("active_policy") else False}


def _run_view(state, kb, run):
    return {**copy.deepcopy(run), "activation": _activation(state, kb, run)} if run else None


def _find_run(state, payload):
    run = next((r for r in state["runs"] if r["id"] == payload.get("run_id")), None)
    if run is None: raise ValueError("评测报告不存在，请重新选择或运行评测")
    return run


def _latest_run(state):
    last = state.get("last_run")
    return next((r for r in state["runs"] if last and r["id"] == last["id"]), last)


def _active_view(state, kb):
    active = copy.deepcopy(state.get("active_policy"))
    if active:
        active["needs_review"] = active.get("retrieval_version") != knowledge.RETRIEVAL_VERSION or active["corpus_hash"] != _corpus_hash(kb) or active["gold_hash"] != sha(state["gold"])
    return active


def handle(wrapper, action, payload=None, model=None):
    payload = payload or {}
    state, kb = wrapper["evaluation"], wrapper["knowledge"]
    _ensure_gold(state, kb)
    if action == "get":
        return {"synthetic": True, "gold": state["gold"], "gold_revision": state["gold_revision"],
                "runs": [{k: v for k, v in r.items() if k not in {"baseline", "candidate", "gold_snapshot"}} for r in state["runs"]],
                "last_run": _run_view(state, kb, _find_run(state, payload) if payload.get("run_id") else _latest_run(state)), "active_policy": _active_view(state, kb), "simulated": True, "method": "模拟评测流程：同一套预设问题与资料，演示排序差异、分母、引用检查与发布门禁，不代表真实模型效果"}
    if action in {"gold_add", "gold_update"}:
        previous = next((g for g in state["gold"] if g["id"] == payload.get("gold_id")), None) if action == "gold_update" else None
        if action == "gold_update" and previous is None:
            raise ValueError("标注题目不存在，请重新选择")
        question = knowledge._text(payload.get("question"), "评测问题", 1000)
        school, version = knowledge._scope(kb, payload)
        if previous and school != previous["school_id"]:
            raise ValueError("修订不能改变原题所属学校，请在对应学校新增题目")
        if any(g["id"] != (previous or {}).get("id") and g["school_id"] == school and g["version_id"] == version
               and "".join(g["question"].split()).casefold() == "".join(question.split()).casefold() for g in state["gold"]):
            raise ValueError("当前学校和版本已有这道题，请修订已有标注，避免重复计分")
        ids = payload.get("document_ids", [])
        if not isinstance(ids, list) or any(not isinstance(i, str) for i in ids):
            raise ValueError("相关文档需使用文档 ID 列表")
        docs = [d for d in kb["documents"] if d["id"] in ids and d["school_id"] == school and d["version"] == version and d["status"] == "published"]
        if {d["id"] for d in docs} != set(ids):
            raise ValueError("相关文档必须是当前学校和版本的已发布资料")
        if not ids and payload.get("refusal_expected") is not True:
            raise ValueError("请指定相关文档，或明确勾选应拒答")
        if ids and payload.get("refusal_expected") is True:
            raise ValueError("应拒答样本不能同时标注相关文档")
        if previous is None and len(state["gold"]) >= 40:
            raise ValueError("演示金标最多 40 题")
        item = _gold_item(question, school, version, docs, docs[0]["topic_id"] if docs else "no_evidence")
        if previous:
            if question == previous["question"] and version == previous["version_id"] and set(ids) == set(previous["relevance"]) and item["refusal_expected"] == previous["refusal_expected"]:
                return {"item": copy.deepcopy(previous), "gold_revision": state["gold_revision"], "replayed": True}
            item["id"] = previous["id"]
        prospective = [item if previous and g["id"] == previous["id"] else g for g in state["gold"]] if previous else [*state["gold"], item]
        validate_manifest([{k: row[k] for k in GOLD_FIELDS} for row in prospective])
        if previous:
            state.setdefault("gold_history", []).append({"school_id": previous["school_id"], "item": copy.deepcopy(previous), "at": _now()})
        state["gold"] = prospective
        state["gold_revision"] += 1
        return {"item": item, "gold_revision": state["gold_revision"]}
    if action == "run":
        strategy = payload.get("candidate_strategy", "hybrid")
        if strategy not in {"hybrid", "graph", "keyword"}:
            raise ValueError("请选择有效候选检索策略")
        top_k = payload.get("candidate_top_k", 6)
        if type(top_k) is not int or not 1 <= top_k <= 6:
            raise ValueError("候选返回条数必须是 1 到 6 的整数")
        items = copy.deepcopy(state["gold"])
        validate_manifest([{k: row[k] for k in GOLD_FIELDS} for row in items])
        policy = _policy(items, payload)
        active = state.get("active_policy") or {}
        baseline = _execute(kb, items, active.get("strategy", "hybrid"), active.get("top_k", 6))
        candidate = _execute(kb, items, strategy, top_k)
        reasons = quality_reasons(candidate["metrics"], candidate["strata"], policy) + _gold_integrity(kb, items)
        delta = {}
        for metric in policy["floors"]:
            a, b = baseline["metrics"].get(metric), candidate["metrics"].get(metric)
            delta[metric] = b - a if a is not None and b is not None else None
            if delta[metric] is not None and delta[metric] < -policy["max_regression"]:
                reasons.append("REGRESSION:" + metric)
        run = {"id": str(uuid4()), "at": _now(), "synthetic": True, "gold_revision": state["gold_revision"], "gold_hash": sha(items),
               "corpus_hash": _corpus_hash(kb), "metric_version": METRIC_VERSION, "retrieval_version": knowledge.RETRIEVAL_VERSION, "sample_count": len(items),
               "baseline_policy_id": active.get("run_id"), "baseline": baseline, "candidate": candidate, "delta": delta, "policy": policy,
               "gate": {"passed": not reasons, "reasons": reasons, "scope": "模拟门禁结果，仅演示合成资料流程；不是实际模型或生产效果验收，不会自动发布资料"},
               "gold_snapshot": items, "model_calls": 0, "simulated": True, "mode": "模拟评测 · 预设资料演示",
               "comparable": True, "changed_variables": (["检索策略"] if strategy != baseline["strategy"] else []) + (["候选 top_k"] if top_k != baseline["top_k"] else [])}
        run["input_signature"] = _input_signature(run)
        run["result_signature"] = _result_signature(run)
        run["business_acceptance"] = None
        state["runs"].append(run)
        recent = state["runs"][-10:]
        active_id = (state.get("active_policy") or {}).get("run_id")
        retained = [r for r in state["runs"][:-10] if r["id"] == active_id]
        state["runs"] = retained + recent
        state["last_run"] = run
        return _run_view(state, kb, run)
    if action in {"business_accept", "activate"}:
        run = _find_run(state, payload)
        status = _activation(state, kb, run)
        withdrawing_acceptance = action == "business_accept" and payload.get("accepted") is False
        if not status["fresh"] and not withdrawing_acceptance:
            raise ValueError("评测报告已过期：" + "；".join(status["stale_reasons"]) + "，请重新评测")
        if action == "business_accept":
            if type(payload.get("accepted")) is not bool:
                raise ValueError("业务验收需明确通过或不通过")
            note = payload.get("note", "")
            if not isinstance(note, str) or len(note) > 1000:
                raise ValueError("验收说明不能超过 1000 字符")
            run["business_acceptance"] = {"accepted": payload["accepted"], "note": note.strip(), "at": _now(),
                                          "result_signature": run["result_signature"]}
            if payload["accepted"] is False and status["active"]:
                state["active_policy"] = None
            return {"run": _run_view(state, kb, run), "business_acceptance": copy.deepcopy(run["business_acceptance"])}
        if not status["technical_passed"]:
            raise ValueError("技术门禁未通过，不能启用这个检索策略")
        if not status["business_accepted"]:
            raise ValueError("尚未通过教研员业务验收，不能启用这个检索策略")
        if status["active"]:
            return {"active_policy": _active_view(state, kb), "replayed": True}
        state["active_policy"] = {"run_id": run["id"], "strategy": run["candidate"]["strategy"], "top_k": run["candidate"]["top_k"],
                                  "corpus_hash": run["corpus_hash"], "gold_hash": run["gold_hash"],
                                  "input_signature": run["input_signature"], "retrieval_version": run["retrieval_version"], "activated_at": _now(), "simulated": True}
        return {"active_policy": _active_view(state, kb), "replayed": False}
    if action == "export":
        run = next((r for r in state["runs"] if r["id"] == payload.get("run_id")), None) if payload.get("run_id") else _latest_run(state)
        if not run:
            raise ValueError("请先运行一轮评测")
        return {"filename": f"retrieval-evaluation-{run['id'][:8]}.json", "content_type": "application/json", "content": json.dumps(_run_view(state, kb, run), ensure_ascii=False, indent=2)}
    raise ValueError("不支持的评测操作")
