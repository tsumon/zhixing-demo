"""Executable fixed-role orchestration with human pause, atomic effects and no outbound messages."""
from copy import deepcopy
from datetime import datetime, timezone
from uuid import uuid4

from backend.vendor.intervention_core import Proposal, digest, rule_check

ACTORS = {"analyst": "分析员", "lead": "教研负责人", "teacher-li": "李老师 · 7A/7B任课教师", "teacher-chen": "陈老师 · 8A任课教师"}
LABELS = {"rules_rejected": "规则未通过", "awaiting_lead": "等待负责人审批", "awaiting_teacher": "等待任课教师确认", "ready": "确认完成待执行", "executed": "执行中待回看", "completed": "已完成并释放资源", "revoked": "批准已撤回"}
RULE_REASONS = {"passed": "课后任务时长在政策范围内", "policy_missing": "缺少适用政策，停止审批", "policy_not_applicable": "政策不适用于当前年级或区域", "minutes_missing": "缺少有效时长", "minutes_exceeded": "原有任务加新增任务超过每日上限"}


def now():
    return datetime.now(timezone.utc).isoformat()


def initial_state():
    classes = {"7A": {"class_id": "7A", "school_id": "school-qx", "grade": 7, "region": "qingxi", "existing_minutes": 65, "teacher_id": "teacher-li"},
               "7B": {"class_id": "7B", "school_id": "school-qx", "grade": 7, "region": "qingxi", "existing_minutes": 70, "teacher_id": "teacher-li"},
               "8A": {"class_id": "8A", "school_id": "school-sy", "grade": 8, "region": "shuyuan", "existing_minutes": 60, "teacher_id": "teacher-chen"}}
    raw = {"snapshot_id": str(uuid4()), "metric_version": "completion-v1", "captured_at": now(),
           "rows": [{"class_id": k, "school_id": v["school_id"], "knowledge_id": "fraction" if k != "8A" else "linear", "completed": 21, "assigned": 30, "completion_rate": .7, "baseline_rate": .85} for k, v in classes.items()],
           "source": "合成示例分析快照"}
    raw["source_hash"] = digest(raw)
    return {"classes": classes, "policies": {"7-qingxi": {"version": 1, "grade": 7, "region": "qingxi", "max_minutes": 90}, "8-shuyuan": {"version": 1, "grade": 8, "region": "shuyuan", "max_minutes": 90}},
            "resources": {"room-1": {"id": "room-1", "name": "青溪学习教室席位", "school_id": "school-qx", "capacity": 30, "used": 0}, "teacher-li": {"id": "teacher-li", "name": "李老师辅导名额", "school_id": "school-qx", "capacity": 30, "used": 0},
                          "room-2": {"id": "room-2", "name": "松原学习教室席位", "school_id": "school-sy", "capacity": 30, "used": 0}, "teacher-chen": {"id": "teacher-chen", "name": "陈老师辅导名额", "school_id": "school-sy", "capacity": 30, "used": 0}},
            "sample_snapshot": raw, "plans": [], "active_id": None, "executions": [], "completions": [], "drafts": [], "events": []}


def text(value, label, cap=200):
    if not isinstance(value, str) or not value.strip() or len(value) > cap:
        raise ValueError(f"请填写{label}，最多 {cap} 字符")
    return value.strip()


def integer(value, label, low=0, high=1440):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label}必须为 {low}～{high} 的整数")
    return value


def actor_of(payload, permitted):
    actor = payload.get("actor", "analyst")
    if actor not in permitted:
        raise ValueError("请切换到对应演示角色；负责人和任课教师必须分别确认")
    return actor


def plan_of(state, payload):
    plan = next((p for p in state["plans"] if p["id"] == (payload.get("id") or state["active_id"])), None)
    if not plan:
        raise ValueError("请先创建干预方案")
    return plan


def check_version(plan, payload):
    if type(payload.get("version")) is not int or payload["version"] != plan["version"]:
        raise ValueError("方案版本已变化；旧批准不能用于新方案，请刷新")


def emit(state, plan, action, actor, detail):
    event = {"id": str(uuid4()), "at": now(), "action": action, "actor": actor, "object_type": "intervention_plan", "object_id": plan["id"], "version": plan["version"], "detail": detail}
    plan.setdefault("history", []).append(event);state["events"].append(event)


def policy_for(state, cls):
    return state["policies"].get(f"{cls['grade']}-{cls['region']}")


def validate_snapshot(state, raw, class_id):
    if not isinstance(raw, dict) or not isinstance(raw.get("rows"), list) or not raw.get("snapshot_id") or not raw.get("metric_version"):
        raise ValueError("缺少完整的已验证分析快照")
    if raw.get("source_hash") != digest({k: v for k, v in raw.items() if k != "source_hash"}):
        raise ValueError("分析快照哈希不一致，不能建立方案")
    if class_id not in state["classes"]:
        raise ValueError("请选择演示班级")
    rows = [r for r in raw["rows"] if isinstance(r, dict) and r.get("class_id") == class_id]
    if len(rows) != 1:
        raise ValueError("快照必须包含当前班级的唯一记录")
    evidence = rows[0]
    if evidence.get("school_id") != state["classes"][class_id]["school_id"] or evidence.get("knowledge_id") not in {"fraction", "linear", "argument"}:
        raise ValueError("分析快照的学校或知识点不匹配")
    metric_kind = raw.get("metric_kind", "essay_quality" if raw["metric_version"].startswith("essay-quality") else "completion")
    if metric_kind not in {"completion", "essay_quality"}:
        raise ValueError("当前仅支持作业完成率或作文质量快照，不能混用指标")
    if metric_kind == "essay_quality" and evidence["knowledge_id"] != "argument":
        raise ValueError("作文质量快照必须对应作文知识点")
    selected = {k: deepcopy(raw[k]) for k in ("schema_version", "tenant_id", "metric_version", "captured_at", "source") if k in raw}
    selected["metric_kind"] = metric_kind
    selected.update(snapshot_id=f"{raw['snapshot_id']}:{class_id}", rows=[deepcopy(evidence)],
                    source_snapshot_id=raw["snapshot_id"], source_parent_hash=raw["source_hash"])
    selected["source_hash"] = digest(selected)
    return selected, {**deepcopy(evidence), "metric_kind": metric_kind}


def proposal_for(payload, evidence, model=None):
    attribution = evidence.get('attribution_summary') or {}
    timing_check = any(clue.get('status') == 'supported' and clue.get('id') in {'late_release', 'deadline_open'}
                       for clue in attribution.get('clues', []))
    is_essay = evidence.get("metric_kind") == "essay_quality"
    weak = [d for d in evidence.get("weak_dimensions", []) if isinstance(d, dict)
            and d.get("name") and isinstance(d.get("score_rate"), (int, float)) and 0 <= d["score_rate"] < .7] if is_essay else []
    feedback_only = is_essay and not weak
    student_count = integer(evidence.get("student_count"), "已关联学生人数", 1, 1000) if is_essay else 1000
    minutes = integer(payload.get("new_minutes", 0 if timing_check or feedback_only else 15), "新增作业分钟")
    participants = integer(payload.get("participants", min(12, student_count)), "参与人数（不超过分析中已关联的学生人数）" if is_essay else "参与人数", 1, student_count)
    if feedback_only and minutes:
        raise ValueError("本次作文分析未识别低于70%的人工评分薄弱维度，只创建反馈复核，不新增练习；如需练习请先补齐相应分析依据")
    delivery = payload.get("delivery_mode", "classroom" if is_essay else "shared_room")
    if delivery not in {"classroom", "shared_room"}:
        raise ValueError("请选择本班课堂练习或跨班资源调配")
    teacher = "teacher-chen" if evidence["school_id"] == "school-sy" else "teacher-li"
    room = "room-2" if evidence["school_id"] == "school-sy" else "room-1"
    resources = payload.get("resources", [teacher] if delivery == "classroom" else [room, teacher])
    title = payload.get("title") or f"{evidence['class_id']} · {'作文反馈复核' if feedback_only else '作文分层练习' if is_essay else '分层巩固方案'}"
    raw = {"title": title, "rationale": "依据分析快照定位需要帮助的班级；先用短任务验证学习困难，不把相关性当成因果结论。",
           "actions": ["任课教师查看匿名分组结果并确认参与范围", "针对薄弱知识点布置一组分层练习", "次日回看完成率和错误类型，决定继续、调整或停止"],
           "new_minutes": minutes, "participants": participants, "resources": resources, "recipients": ["teacher-chen" if evidence["school_id"] == "school-sy" else "teacher-li"]}
    if is_essay:
        scope = f"本次 {evidence.get('record_count', 0)} 篇已发布作文、{student_count} 名已关联学生"
        if feedback_only:
            raw.update(rationale=f"{scope}。未发现有人工评分依据且低于70%的薄弱维度；先复核评分与个别反馈，不据此追加练习。",
                       actions=["任课教师核对本次已发布作文、学生范围与已有维度评分", "向参与学生说明本次评分与可改进之处；缺少维度时先补充独立评阅", "回看学生反馈和修改情况，确认是否需要另行分析并安排后续练习"])
        else:
            dimension = "、".join(d["name"] for d in weak)
            raw.update(rationale=f"依据已发布作文的同口径统计（{scope}），围绕{dimension}安排短练习；总分变化不直接当成因果效果。",
                       actions=["任课教师核对已发布作文的评分维度与参与学生", f"围绕{dimension}完成一组改写与互评练习", "完成后记录维度变化与教师观察，决定继续、调整或停止"])
    elif attribution.get('next_steps'):
        followup = attribution['next_steps'][0]
        raw.update(title=payload.get('title') or f"{evidence['class_id']} · {'任务时间核查与跟进' if timing_check else '任务核查与跟进'}",
                   rationale='依据本班已复算任务的变化贡献与观察线索，先核查记录再决定行动；线索相关性不等于已证明因果，不自动认定学生能力下降。',
                   actions=['核对本班任务记录、变化贡献和待核实线索', followup['detail'],
                            '同一提交窗口结束后重新核对完成率，记录观察结果，再决定继续、调整或停止'])
    # This is a preset simulation. An injected model or legacy mode cannot make calls.
    try:
        return {**Proposal.model_validate(raw).model_dump(), "delivery_mode": delivery}, "预设方案 + 固定演示流程"
    except (ValueError, TypeError):
        raise ValueError("方案字段未通过结构校验，未提交") from None


def validate_resources(state, proposal, cls):
    expected = {cls["teacher_id"]}
    if proposal.get("delivery_mode", "shared_room") == "shared_room":
        expected.add("room-2" if cls["school_id"] == "school-sy" else "room-1")
    if set(proposal["resources"]) != expected or any(state["resources"].get(key, {}).get("school_id") != cls["school_id"] for key in proposal["resources"]):
        raise ValueError("必须使用当前学校与活动方式对应的资源，不能跨校借用或绕过容量检查")


def orchestration(state, plan):
    cls = state["classes"][plan["class_id"]]
    policy = policy_for(state, cls)
    decision = rule_check(cls, plan["proposal"], policy)
    decision["message"] = RULE_REASONS[decision["reason"]]
    decision.update(existing_minutes=cls["existing_minutes"], new_minutes=plan["proposal"]["new_minutes"], total_minutes=cls["existing_minutes"] + plan["proposal"]["new_minutes"], max_minutes=policy.get("max_minutes") if policy else None)
    plan["rule_result"] = decision
    plan["policy_version"] = decision["policy_version"]
    plan["plan_hash"] = digest({k: plan[k] for k in ("id", "version", "class_id", "school_id", "knowledge_id", "snapshot", "proposal", "policy_version")})
    if plan.get("wiki_refs"):
        plan["plan_hash"] = digest({"plan_hash":plan["plan_hash"], "wiki_refs":plan["wiki_refs"]})
    proposal = plan["proposal"]
    plan["requires_lead"] = proposal.get("delivery_mode", "shared_room") != "classroom" or proposal["new_minutes"] > 15 or proposal["participants"] > 15
    plan["approval_reason"] = "涉及跨班资源调配或超出日常小组练习范围" if plan["requires_lead"] else "本班反馈与核查：不占跨班资源，不新增作业时长" if proposal["new_minutes"] == 0 else "本班小组练习：不占跨班资源，至多15人和15分钟"
    plan["state"] = ("awaiting_lead" if plan["requires_lead"] else "awaiting_teacher") if decision["passed"] else "rules_rejected"
    plan["stages"] = [
        {"role": "分析角色", "status": "passed", "input": {"snapshot_id": plan["snapshot"]["snapshot_id"], "source_hash": plan["snapshot"]["source_hash"]}, "output": plan["evidence"]},
        {"role": "方案角色", "status": "passed", "input": {"class_id": plan["class_id"], "knowledge_id": plan["knowledge_id"]}, "output": plan["proposal"], "mode": plan["mode"]},
        {"role": "策略校验", "status": "passed" if decision["passed"] else "rejected", "input": {"current_class": deepcopy(cls), "policy": deepcopy(policy)}, "output": decision},
        {"role": "人工确认", "status": "paused" if decision["passed"] else "blocked", "input": {"version": plan["version"], "plan_hash": plan["plan_hash"], "reason":plan["approval_reason"]}, "output": ("等待负责人审批，再由任课教师确认" if plan["requires_lead"] else "日常练习由任课教师确认，不需校长逐次审批") if decision["passed"] else "规则失败，先修改方案"}]


def view(state):
    return {"classes": deepcopy(state["classes"]), "policies": deepcopy(state["policies"]), "resources": deepcopy(state["resources"]), "actors": ACTORS,
            "plans": [{**deepcopy(p), "state_label": LABELS[p["state"]]} for p in reversed(state["plans"])], "active_id": state["active_id"], "sample_snapshot": deepcopy(state["sample_snapshot"]),
            "executions": deepcopy(state["executions"]), "completions": deepcopy(state.get("completions",[])), "drafts": deepcopy(state["drafts"]), "orchestration": "固定演示流程：分析→方案→规则与风险分流→教师确认→模拟执行→反馈与资源释放；不调用模型"}


def handle(state, action, payload=None, model=None):
    payload = payload or {}
    if action == "get":
        return view(state)
    if action in {"create", "create_from_analysis"}:
        class_id = payload.get("class_id", "7A")
        raw = payload.get("snapshot") if action == "create_from_analysis" else state["sample_snapshot"]
        snapshot, evidence = validate_snapshot(state, raw, class_id)
        proposal, mode = proposal_for(payload, evidence, model)
        validate_resources(state, proposal, state["classes"][class_id])
        plan = {"id": str(uuid4()), "version": 1, "class_id": class_id, "school_id": evidence["school_id"], "knowledge_id": evidence["knowledge_id"], "metric_kind":snapshot["metric_kind"], "snapshot": snapshot, "evidence": evidence, "proposal": proposal, "mode": mode,
                "source": "本次问数演示快照" if action == "create_from_analysis" else "独立合成示例快照", "created_at": now(), "history": [], "wiki_refs": deepcopy(payload.get("wiki_refs", []))}
        orchestration(state, plan)
        state["plans"].append(plan);state["active_id"] = plan["id"]
        emit(state, plan, "create", "analyst", "按分析快照生成方案并执行规则校验")
        return {"plan": deepcopy(plan)}
    if action == "set_capacity":
        actor_of(payload, {"lead"})
        resource = state["resources"].get(payload.get("resource_id"))
        if not resource:
            raise ValueError("资源不存在")
        capacity = integer(payload.get("capacity"), "资源容量", resource["used"], 1000)
        resource["capacity"] = capacity
        return {"resource": deepcopy(resource)}
    plan = plan_of(state, payload)
    if action == "execute":
        actor = actor_of(payload, {state["classes"][plan["class_id"]]["teacher_id"]})
        key = text(payload.get("key"), "执行幂等键", 100)
        if plan["state"] == "revoked":
            raise ValueError("批准已撤回，不能执行或重放")
        previous = next((e for e in state["executions"] if e["key"] == key), None)
        if previous:
            if previous["plan_id"] != plan["id"] or previous["version"] != payload.get("version"):
                raise ValueError("相同幂等键不能用于不同方案或版本")
            return {"execution": deepcopy(previous), "replayed": True, "plan": deepcopy(plan)}
        check_version(plan, payload)
        if plan["state"] != "ready":
            raise ValueError("需要负责人审批及另一位任课教师确认后才能执行")
        required = ("lead_approval", "teacher_confirmation") if plan.get("requires_lead",True) else ("teacher_confirmation",)
        if not all(plan.get(k, {}).get("plan_hash") == plan["plan_hash"] for k in required):
            raise ValueError("批准与当前方案不匹配")
        cls = state["classes"][plan["class_id"]]
        validate_resources(state, plan["proposal"], cls)
        policy = policy_for(state, cls)
        decision = rule_check(cls, plan["proposal"], policy)
        if not decision["passed"] or decision["policy_version"] != plan["policy_version"]:
            raise ValueError("当前任务时长或政策已经变化，请重新检查方案并审批")
        quantity = plan["proposal"]["participants"]
        selected = [state["resources"][key] for key in sorted(plan["proposal"]["resources"])]
        if any(r["used"] + quantity > r["capacity"] for r in selected):
            raise ValueError("资源容量不足；未占用任何资源，也未增加作业时长")
        # The root stores the entire workspace in one serialized transaction. Validate all before any effect.
        effect = {"id": str(uuid4()), "plan_id": plan["id"], "version": plan["version"], "plan_hash": plan["plan_hash"], "key": key, "class_id": plan["class_id"], "participants": quantity, "new_minutes": plan["proposal"]["new_minutes"], "resources": plan["proposal"]["resources"], "executed_at": now()}
        for resource in selected:
            resource["used"] += quantity
        cls["existing_minutes"] += plan["proposal"]["new_minutes"]
        state["executions"].append(effect);plan["state"] = "executed";plan["execution_id"] = effect["id"]
        plan["stages"].append({"role": "执行角色", "status": "passed", "input": {"plan_hash": plan["plan_hash"], "idempotency_key": key}, "output": effect})
        emit(state, plan, "execute", actor, "原子提交：资源占用与任务分钟一起写入；通知未发送")
        return {"execution": deepcopy(effect), "replayed": False, "plan": deepcopy(plan)}
    if action == "complete":
        actor = actor_of(payload, {state["classes"][plan["class_id"]]["teacher_id"]})
        key = text(payload.get("key"), "完成幂等键", 100)
        outcome = payload.get("outcome")
        if outcome not in {"improved", "unchanged", "worse", "stopped"}:
            raise ValueError("请选择改善、无明显变化、变差或提前停止")
        feedback = text(payload.get("feedback"), "本次结果与回看说明", 1000)
        completions = state.get("completions", [])
        prior = next((c for c in completions if c["key"] == key), None)
        if prior:
            if any(prior[k] != value for k,value in {"plan_id":plan["id"], "version":payload.get("version"), "outcome":outcome, "feedback":feedback}.items()):
                raise ValueError("相同完成键不能用于不同方案、版本或反馈")
            return {"completion":deepcopy(prior), "plan":deepcopy(plan), "replayed":True}
        check_version(plan,payload)
        effect = next((e for e in state["executions"] if e["id"] == plan.get("execution_id")),None)
        if not effect or plan["state"] not in {"executed", "revoked"} or any(c["plan_id"] == plan["id"] for c in completions):
            raise ValueError("只有尚未完成的已执行方案能回看并释放资源")
        cls = state["classes"][effect["class_id"]]
        selected = [state["resources"][rid] for rid in effect["resources"]]
        if any(r["used"] < effect["participants"] for r in selected) or cls["existing_minutes"] < effect["new_minutes"]:
            raise ValueError("资源占用记录不一致，未释放任何资源")
        completion = {"id":str(uuid4()),"plan_id":plan["id"],"execution_id":effect["id"],"version":plan["version"],"key":key,"school_id":plan["school_id"],"class_id":plan["class_id"],"metric_kind":plan.get("metric_kind","completion"),"outcome":outcome,"feedback":feedback,"actor":actor,"at":now(),"released_resources":deepcopy(effect["resources"]),"released_participants":effect["participants"],"released_minutes":effect["new_minutes"]}
        for resource in selected: resource["used"] -= effect["participants"]
        cls["existing_minutes"] -= effect["new_minutes"]
        state.setdefault("completions",[]).append(completion);plan["state"]="completed"
        plan["completion_id"]=completion["id"]
        plan["stages"].append({"role":"教师回看","status":"passed","input":{"execution_id":effect["id"]},"output":deepcopy(completion)})
        emit(state,plan,"complete",actor,"记录本次观察并精确释放本次资源与任务分钟；执行历史保留，不声称因果效果")
        return {"completion":deepcopy(completion),"plan":deepcopy(plan),"replayed":False}
    if action == "draft":
        actor = actor_of(payload, {state["classes"][plan["class_id"]]["teacher_id"]})
        key = text(payload.get("key"), "草稿幂等键", 100)
        if plan["state"] != "executed":
            raise ValueError("仅已执行且未撤回的方案可生成通知草稿")
        check_version(plan, payload)
        previous = next((d for d in state["drafts"] if d["key"] == key), None)
        if previous:
            if previous["plan_id"] != plan["id"] or previous["version"] != plan["version"]:
                raise ValueError("草稿幂等键已经被其他方案使用")
            return {"draft": deepcopy(previous), "replayed": True}
        proposal = plan["proposal"]
        arrangement = f"安排 {proposal['participants']} 人、新增 {proposal['new_minutes']} 分钟任务" if proposal["new_minutes"] else f"覆盖 {proposal['participants']} 人，不新增作业时长，按方案核对记录并回看结果"
        draft = {"id": str(uuid4()), "plan_id": plan["id"], "version": plan["version"], "key": key, "status": "draft_only", "recipients": proposal["recipients"],
                 "text": f"“{proposal['title']}”已执行，{arrangement}。请按已确认方案跟进，并记录实施反馈。此为待发送草稿，请核对后另行通知；本系统不发送外部消息。", "created_at": now()}
        state["drafts"].append(draft);emit(state, plan, "draft", actor, "仅生成草稿，不调用短信、邮件或消息服务")
        return {"draft": deepcopy(draft), "replayed": False}
    check_version(plan, payload)
    if action == "revise":
        actor_of(payload, set(ACTORS))
        if plan["state"] == "revoked":
            raise ValueError("已撤回方案保留原审批记录，不能重新开启；请新建方案")
        if plan["state"] == "executed" or plan.get("execution_id"):
            raise ValueError("已执行记录不可改写；请另建方案")
        if payload.get("class_id", plan["class_id"]) != plan["class_id"]:
            raise ValueError("修改当前方案不能切换班级；请为新班级另建方案")
        merged = {**plan["proposal"], **{k: v for k, v in payload.items() if k in {"title", "new_minutes", "participants", "resources", "delivery_mode"}}, "mode": "rules"}
        if "delivery_mode" in payload and "resources" not in payload:
            merged.pop("resources",None)
        proposal, mode = proposal_for(merged, plan["evidence"])
        validate_resources(state, proposal, state["classes"][plan["class_id"]])
        plan.update(proposal=proposal, mode=mode, version=plan["version"] + 1)
        plan.pop("lead_approval", None);plan.pop("teacher_confirmation", None)
        orchestration(state, plan);emit(state, plan, "revise", payload.get("actor", "analyst"), "方案新版本，原负责人和任课教师批准全部失效")
    elif action == "approve":
        actor = actor_of(payload, {"lead"})
        if plan["state"] != "awaiting_lead":
            raise ValueError("规则通过且方案等待负责人时才能审批")
        plan["lead_approval"] = {"actor": actor, "plan_hash": plan["plan_hash"], "at": now()};plan["state"] = "awaiting_teacher"
        plan["stages"][3]["output"] = "负责人已批准，暂停等待任课教师确认"
        emit(state, plan, "approve", actor, "负责人批准当前内容哈希与版本")
    elif action == "confirm":
        actor = actor_of(payload, {state["classes"][plan["class_id"]]["teacher_id"]})
        if plan["state"] != "awaiting_teacher" or actor == plan.get("lead_approval", {}).get("actor"):
            raise ValueError("负责人审批后，由不同的任课教师确认")
        plan["teacher_confirmation"] = {"actor": actor, "plan_hash": plan["plan_hash"], "at": now()};plan["state"] = "ready"
        plan["stages"][3].update(status="passed", output="所需审批与任课教师确认已完成，等待教师执行")
        emit(state, plan, "confirm", actor, "任课教师确认当前版本，未自动执行")
    elif action == "revoke":
        actor = actor_of(payload, {"lead"})
        if plan["state"] == "completed":
            raise ValueError("已完成方案保留结果，不再撤回；请另建后续方案")
        plan.pop("lead_approval", None);plan.pop("teacher_confirmation", None);plan["state"] = "revoked";plan["version"] += 1
        plan["stages"][3].update(status="revoked", output="批准已撤回，不能再次执行；历史执行效果保留")
        emit(state, plan, "revoke", actor, "撤回批准；已发生的资源与任务效果不会伪装成回滚")
    else:
        raise ValueError("不支持的干预操作")
    return {"plan": deepcopy(plan)}
