"""P1: interactive, synthetic teaching-material demonstration.

State is persisted by the portal's workspace transaction.  This module never
opens files, reads credentials, or calls a network service.
"""
from __future__ import annotations

from collections import Counter, deque
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import sha256
import copy
import json
import math
import re
from uuid import uuid4

from backend.vendor.rag_core import Chunk, chunk_pages, rrf_fuse


RETRIEVAL_VERSION = "demo-retrieval-fact-guard-v5"

SCHOOLS = [{"id": "school-qx", "name": "青溪实验学校（合成）"},
           {"id": "school-sy", "name": "松原中学（合成）"}]
TOPICS = [
    {"id": "fraction", "name": "分数运算", "type": "knowledge", "aliases": ["分数", "通分", "异分母", "分母不一样", "约分", "公倍数"]},
    {"id": "linear", "name": "一元一次方程", "type": "knowledge", "aliases": ["方程", "移项", "等式", "解方程", "未知数"]},
    {"id": "argument", "name": "议论文论证", "type": "knowledge", "aliases": ["议论文", "论点", "论据", "论证", "作文"]},
    {"id": "7A", "name": "七年级 A 班", "type": "class", "aliases": ["7A", "七年级A班"], "school_ids": ["school-qx"]},
    {"id": "7B", "name": "七年级 B 班", "type": "class", "aliases": ["7B", "七年级B班"], "school_ids": ["school-qx"]},
    {"id": "8A", "name": "八年级 A 班", "type": "class", "aliases": ["8A", "八年级A班"], "school_ids": ["school-sy"]},
    {"id": "teacher-li", "name": "李老师（合成）", "type": "teacher", "aliases": ["李老师"], "school_ids": ["school-qx"]},
    {"id": "room-1", "name": "研学教室 1（合成）", "type": "resource", "aliases": ["研学教室", "教室1"], "school_ids": ["school-qx"]},
]
RELATIONS = [
    ("fraction", "linear", "prerequisite", "分数运算是含分数系数方程的前置知识"),
    ("7A", "fraction", "studies", "七年级 A 班当前学习分数运算"),
    ("7B", "linear", "studies", "七年级 B 班当前学习一元一次方程"),
    ("8A", "argument", "studies", "八年级 A 班当前学习议论文论证"),
    ("teacher-li", "7A", "teaches", "李老师负责七年级 A 班"),
    ("7A", "room-1", "uses", "分数研学活动使用研学教室 1"),
]
RELATION_STATEMENTS = {
    ("fraction", "linear", "prerequisite"): "含分数系数的方程，先补齐分数运算与通分知识。",
    ("7A", "fraction", "studies"): "七年级 A 班（7A）由李老师负责，在研学教室 1 开展分数活动。",
    ("7B", "linear", "studies"): "七年级 B 班（7B）学习一元一次方程，练习前先复习分数运算。",
    ("8A", "argument", "studies"): "八年级 A 班（8A）写作训练由教师复核。",
    ("teacher-li", "7A", "teaches"): "七年级 A 班（7A）由李老师负责，在研学教室 1 开展分数活动。",
    ("7A", "room-1", "uses"): "七年级 A 班（7A）由李老师负责，在研学教室 1 开展分数活动。",
}
from backend import wiki_learning
TOPICS.extend(wiki_learning.TOPICS)
RELATIONS.append(wiki_learning.RELATION)
RELATION_STATEMENTS[wiki_learning.RELATION[:3]] = wiki_learning.STATEMENT

def teaching_topics():
    return [t for t in TOPICS if t["type"] == "knowledge"]

STOP = {"怎么", "什么", "多少", "老师", "请问", "我们", "进行", "可以", "学校", "教材", "学生", "这个", "一个", "对于", "需要", "如何", "方式", "步骤", "要求", "为什么", "介绍", "讲讲", "解释", "问题", "处理", "以及", "哪些", "具体", "按照", "学习", "教学", "演示", "合成", "资料"}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _id():
    return str(uuid4())


def _hash(value):
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def _text(value, label, limit=20000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"{label}不能为空，且不能超过 {limit} 字符")
    return value.strip()


def _event(state, action, detail):
    state["events"].append({"id": _id(), "at": _now(), "action": action, "detail": detail})
    state["events"] = state["events"][-100:]


def _make_document(title, school, version, topic, text, status="draft", series_id=None):
    document_id = _id()
    pages = [(n + 1, page.strip()) for n, page in enumerate(text.split("\f")) if page.strip()]
    # Preserve source page and paragraph boundaries. Long paragraphs are split at
    # sentence boundaries; no text is dropped to satisfy a chunk budget.
    normalized = []
    for page_no, body in pages:
        units = []
        for paragraph in re.split(r"\n\s*\n", body):
            paragraph = paragraph.strip()
            if len(paragraph) <= 700:
                units.append(paragraph)
            else:
                sentences = re.findall(r"[^。！？!?]+[。！？!?]?", paragraph)
                if any(len(sentence) > 700 for sentence in sentences):
                    raise ValueError("单句超过 700 字，请分段后导入，避免切掉关键条件")
                units.extend(sentences)
        normalized.append((page_no, "\n\n".join(units)))
    chunks = [asdict(c) for c in chunk_pages(school, version, document_id, normalized, 700)]
    return {"id": document_id, "series_id": series_id or _id(), "title": title, "school_id": school,
            "version": version, "topic_id": topic, "status": status, "text": text,
            "chunks": chunks, "source_hash": _hash(text), "created_at": _now(), "synthetic": True, "relation_assertions": []}


def initial_state():
    documents = []
    for school in SCHOOLS:
        school_id = school["id"]
        for topic in TOPICS[:3]:
            series = _id()
            for version in ["2025", "2026"]:
                new = version == "2026"
                if topic["id"] == "fraction":
                    example = "1/2 + 1/3 = 3/6 + 2/6 = 5/6" if new else "1/4 + 1/2 = 1/4 + 2/4 = 3/4"
                    school_rule = "先用纸条分割展示公分母，再写算式" if school_id == "school-qx" else "先用数轴对齐刻度，再写算式"
                    activity = "七年级 A 班（7A）由李老师负责，在研学教室 1 开展分数活动。" if school_id == "school-qx" else "本校分数活动由校内数学教师组织，不借用其他学校的班级、教师与教室标识。"
                    text = f"分数运算 · {version} 版 · {school['name']}\n异分母分数相加，先求分母的公倍数，把两个分数通分，再把分子相加，分母保持不变，最后约分。不能把分子、分母分别直接相加。\n\n例：{example}。教师检查通分过程和约分结果。\f本校教学约定：{school_rule}。{activity}\n\n{'2026 版新增：分数除法先把除数倒数，再转成乘法；除数不能为零。' if new else '2025 版本节只覆盖加减法，分数除法安排在后续课时。'}"
                elif topic["id"] == "linear":
                    class_note = "七年级 B 班（7B）学习一元一次方程，练习前先复习分数运算。" if school_id == "school-qx" else "八年级 A 班（8A）复习一元一次方程，先检查分数运算基础。"
                    text = f"一元一次方程 · {version} 版 · {school['name']}\n解方程先去分母、去括号，再移项、合并同类项，最后把未知数系数化为 1。移项实质是等式两边同时加减同一个数，移项要变号。\n\n例：2x+3=11，两边减 3 得 2x=8，再除以 2 得 x=4；把 x=4 代回原式检验。\f含分数系数的方程，先补齐分数运算与通分知识。{class_note}\n\n{'2026 版要求记录原式的取值限制，去分母后仍需回代原式检查。' if new else '2025 版通过整数系数例题学习移项；暂不包含分式方程。'}"
                else:
                    class_note = "本校写作训练由语文教师复核。" if school_id == "school-qx" else "八年级 A 班（8A）写作训练由教师复核。"
                    text = f"议论文论证 · {version} 版 · {school['name']}\n一段论证包含观点、证据和解释。论点是要表达的判断，论据是支持判断的事实或材料，论证说明证据为什么能支持观点。不要只堆砌事例而不解释联系。\n\n例：观点是阅读能拓宽视野；可用比较两篇不同背景作品后的观察作为论据，再说明不同视角如何改变理解。\f{class_note}初评给分数和修改建议，教师复核确认后还需由有权限的人显式发布，不能自动把初评发给学生。\n\n{'2026 版新增：反方观点要被准确复述，再回应其理由；引用材料标明作者与出处。' if new else '2025 版重点练习观点与论据对应，反方论证留在拓展课。'}"
                document = _make_document(f"{topic['name']}教学手册", school_id, version, topic["id"], text, "published", series)
                document["seed_document"] = True
                document["relation_assertions"] = [{"source": source, "target": target, "type": kind, "label": label, "statement": RELATION_STATEMENTS[(source, target, kind)]}
                                                   for source, target, kind, label in RELATIONS if RELATION_STATEMENTS[(source, target, kind)] in text]
                documents.append(document)
    return {"synthetic": True, "schools": copy.deepcopy(SCHOOLS), "documents": documents,
            "current_versions": {s["id"]: "2026" for s in SCHOOLS}, "last_search": None, "events": [],
            "wiki": {"schema": {"revision": 1, "entity_types": ["knowledge", "class", "teacher", "resource"],
                                "relation_types": ["prerequisite", "studies", "teaches", "uses"],
                                "required_fields": ["title", "body", "sources", "school_id", "version"]},
                     "raw": [], "pages": [], "conflicts": [], "revisions": []}}


def _scope(state, payload):
    school = payload.get("school_id", "school-qx")
    if school not in {s["id"] for s in state["schools"]}:
        raise ValueError("请选择演示学校")
    version = str(payload.get("version") or state["current_versions"].get(school, "2026"))
    if len(version) > 40 or not version.strip():
        raise ValueError("教材版本不能为空且不能超过 40 字符")
    return school, version


def _visible(state, school, version):
    return [d for d in state["documents"] if d["school_id"] == school and d["version"] == version and d["status"] == "published"]


def _terms(text):
    result = []
    for run in re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]+", text.lower()):
        if re.fullmatch(r"[a-z0-9]+", run):
            if len(run) > 1:
                result.append(run)
        else:
            result.extend(run[i:i + 2] for i in range(len(run) - 1) if run[i:i + 2] not in STOP)
    return result


def _entities(question):
    lower = question.lower()
    return [n["id"] for n in TOPICS if any(alias.lower() in lower for alias in [n["name"], *n["aliases"]])]


def graph_data(state, school, version, seed_ids=None, hops=2):
    docs = _visible(state, school, version)
    scoped_nodes = [n for n in TOPICS if "school_ids" not in n or school in n["school_ids"]]
    evidence = {n["id"]: [] for n in scoped_nodes}
    for document in docs:
        for chunk in document["chunks"]:
            for node in scoped_nodes:
                if node["id"] == document["topic_id"] or any(alias.lower() in chunk["text"].lower() for alias in [node["name"], *node["aliases"]]):
                    evidence[node["id"]].append({"chunk_id": chunk["chunk_id"], "document_id": document["id"], "title": document["title"], "page": chunk["page"], "version": version, "school_id": school})
    # Co-occurrence identifies nodes only. A typed relation requires a registered
    # assertion and its exact source sentence; imported negation never creates
    # an affirmative edge merely because two entity names appear together.
    edge_map = {}
    for document in docs:
        for assertion in document.get("relation_assertions", []):
            source, target, kind = assertion["source"], assertion["target"], assertion["type"]
            if not evidence.get(source) or not evidence.get(target):
                continue
            sources = [{"chunk_id": c["chunk_id"], "document_id": document["id"], "title": document["title"], "page": c["page"], "version": version, "school_id": school, "statement": assertion["statement"]}
                       for c in document["chunks"] if assertion["statement"] in c["text"]]
            if sources:
                edge = edge_map.setdefault((source, target, kind), {"source": source, "target": target, "type": kind, "label": assertion["label"], "sources": []})
                edge["sources"].extend(sources)
    edges = list(edge_map.values())
    visited = {x: 0 for x in (seed_ids or []) if evidence.get(x)}
    queue = deque(visited)
    while queue:
        current = queue.popleft()
        if visited[current] >= hops:
            continue
        for edge in edges:
            other = edge["target"] if edge["source"] == current else edge["source"] if edge["target"] == current else None
            if other and other not in visited:
                visited[other] = visited[current] + 1
                queue.append(other)
    nodes = [{**n, "sources": evidence[n["id"]], "distance": visited.get(n["id"])} for n in scoped_nodes if evidence[n["id"]] and (not seed_ids or n["id"] in visited)]
    allowed = {n["id"] for n in nodes}
    return {"nodes": nodes, "edges": [e for e in edges if e["source"] in allowed and e["target"] in allowed],
            "school_id": school, "version": version, "hops": hops, "seed_ids": seed_ids or [],
            "method": "本地有类型关系扩展（轻量 GraphRAG），未实现社区发现或全局 Map-Reduce"}


def _search_scope_signature(state, school, version):
    documents = [{key: d.get(key) for key in ("id", "source_hash", "chunks", "relation_assertions")} for d in _visible(state, school, version)]
    return _hash(sorted(documents, key=lambda d: d["id"]))


def search_view(state, result):
    """Keep the historic answer inspectable without presenting it as current."""
    if result is None:
        return None
    view = copy.deepcopy(result)
    docs = {d["id"]: d for d in state["documents"]}
    reasons = []
    if view.get("retrieval_version") != RETRIEVAL_VERSION:
        reasons.append("检索规则已更新")
    if any(docs.get(c["document_id"], {}).get("status") != "published" for c in view.get("citations", [])):
        reasons.append("引用来源已撤回")
    if view.get("scope_signature") and view["scope_signature"] != _search_scope_signature(state, view["school_id"], view["version"]):
        reasons.append("本校该版本的已发布资料已更新")
    if "policy_run_id" in view and view["policy_run_id"] != (state.get("active_policy") or {}).get("run_id"):
        reasons.append("检索配置已变更")
    for ref in view.get("wiki_refs", []):
        page = next((p for p in state["wiki"]["pages"] if p["id"] == ref["page_id"]), None)
        if not page or page["revision"] != ref["revision"] or not _page_view(state, page)["usable"]:
            reasons.append("引用知识页已修订或失效")
            break
    if reasons:
        view.update(stale=True, stale_reason="；".join(reasons) + "，请重新检索")
    return view


def retrieve(state, question, school_id="school-qx", version="2026", strategy="hybrid", top_k=6):
    """Select preset synthetic examples; local ranking only drives the demo UI."""
    if strategy not in {"keyword", "hybrid", "graph"}:
        raise ValueError("检索策略只能是 keyword、hybrid 或 graph")
    docs = _visible(state, school_id, version)
    by_id = {d["id"]: d for d in docs}
    chunks = {c["chunk_id"]: Chunk(**c) for d in docs for c in d["chunks"]}
    query = Counter(_terms(question))
    corpora = {cid: Counter(_terms(by_id[c.document_id]["title"] + " " + c.text)) for cid, c in chunks.items()}
    lengths = {cid: sum(terms.values()) for cid, terms in corpora.items()}
    avgdl = sum(lengths.values()) / max(1, len(lengths))
    df = Counter(term for terms in corpora.values() for term in terms)
    keyword, similarity = [], []
    query_norm = math.sqrt(sum(v * v for v in query.values()))
    for cid, terms in corpora.items():
        bm25 = 0.0
        for term in query:
            freq = terms.get(term, 0)
            if freq:
                idf = math.log(1 + (len(corpora) - df[term] + .5) / (df[term] + .5))
                bm25 += idf * freq * 2.5 / (freq + 1.5 * (.25 + .75 * lengths[cid] / max(1, avgdl)))
        cosine = sum(query[t] * terms[t] for t in query) / (query_norm * math.sqrt(sum(v * v for v in terms.values()))) if query_norm and terms else 0
        if bm25 > 0:
            keyword.append((cid, bm25))
        if cosine > 0:
            similarity.append((cid, cosine))
    keyword.sort(key=lambda x: (-x[1], x[0]))
    similarity.sort(key=lambda x: (-x[1], x[0]))
    keyword_scores, similarity_scores = dict(keyword), dict(similarity)
    if strategy == "keyword":
        ranked_ids = [(cid, score, n + 1, None) for n, (cid, score) in enumerate(keyword)]
    else:
        fused = rrf_fuse([(cid, n + 1) for n, (cid, _) in enumerate(keyword)],
                         [(cid, n + 1) for n, (cid, _) in enumerate(similarity)], chunks)
        ranked_ids = [(r.chunk.chunk_id, r.score, r.keyword_rank, r.vector_rank) for r in fused]
    seeds = _entities(question)
    expansion = graph_data(state, school_id, version, seeds, 2) if strategy == "graph" and seeds else None
    graph_reasons = {}
    if expansion:
        for node in expansion["nodes"]:
            for source in node["sources"]:
                graph_reasons.setdefault(source["chunk_id"], []).append({"entity": node["name"], "distance": node["distance"]})
        existing = {r[0] for r in ranked_ids}
        # Expansion adds evidence beyond text matching; exact entity evidence is
        # scored ahead of a two-hop neighbor, never treated as identical facts.
        for cid, reasons in graph_reasons.items():
            if cid not in existing:
                ranked_ids.append((cid, .012 / (1 + min(r["distance"] for r in reasons)), None, None))
        ranked_ids.sort(key=lambda r: (-r[1], r[0]))
    # Isolated common fragments are not sufficient evidence of answerability.
    significant_overlap = bool(keyword) and (len(set(query) & set(corpora[keyword[0][0]])) >= 2 or bool(seeds))
    if not significant_overlap and not (expansion and expansion["nodes"]):
        ranked_ids = []
    hits = []
    for cid, score, kr, vr in ranked_ids[:top_k]:
        c = chunks[cid]
        hits.append({**c.evidence(), "title": by_id[c.document_id]["title"], "school_id": c.tenant_id,
                     "text": c.text, "score": round(score, 6), "bm25": round(keyword_scores.get(cid, 0), 6),
                     "char_similarity": round(similarity_scores.get(cid, 0), 6), "keyword_rank": kr,
                     "similarity_rank": vr, "graph_paths": graph_reasons.get(cid, [])})
    # Preset answers are selected by subject/intent and current school/version.
    # Source excerpts remain inspectable. No model or project backend is used.
    # Related teaching text is not automatically evidence for a requested date,
    # duration or count. Keep the retrieval trace, but only answer from a source
    # that actually carries the requested kind of fact.
    selected = [h for h in hits if _supports_requested_facts(question, h["text"])][:1]
    excerpt = selected[0]["text"] if selected else ""
    answer_sources = selected[:]
    if selected and by_id[selected[0]["document_id"]].get("seed_document"):
        # Preset phrasing uses the selected document's teaching content. Include
        # its supporting pages even if ranking selected only one fragment.
        document = by_id[selected[0]["document_id"]]
        answer_sources += [{**Chunk(**c).evidence(), "title": document["title"]} for c in document["chunks"] if c["chunk_id"] != selected[0]["chunk_id"]]
    answer = _demo_answer(question, selected[0], by_id[selected[0]["document_id"]]) if selected else "当前范围内没有找到足够的资料。可以检查学校和教材版本，或先补充相关资料再查询。"
    return {"question": question, "school_id": school_id, "version": version, "strategy": strategy, "retrieval_version": RETRIEVAL_VERSION,
            "mode": "模拟问答 · 预设资料演示", "model_calls": 0, "simulated": True, "refused": not bool(selected), "answer": answer, "source_excerpt": excerpt,
            "hits": hits, "citations": [{k: h[k] for k in ("chunk_id", "document_id", "version_id", "page", "section", "title")} for h in answer_sources],
            "graph": expansion, "trace": [{"step": "先限定资料", "detail": f"仅 {school_id} / {version} 已发布资料：{len(docs)} 份，{len(chunks)} 个片段"},
                                           {"step": "模拟检索", "detail": f"演示排序：关键词匹配 {len(keyword)} 段，字符匹配 {len(similarity)} 段；策略 {strategy}"},
                                           {"step": "展示预设回答", "detail": "按问题主题、学校和教材版本选择演示回答，附预设资料出处；未连接实际模型或项目后端"}],
            "synthetic": True, "at": _now()}


def _supports_requested_facts(question, text):
    """Small deterministic demo guard; it does not claim semantic QA ability."""
    number = r"(?:[0-9]+|[一二三四五六七八九十两百]+)"
    if re.search(r"什么时候|何时|(?:每)?周几|星期几|哪(?:一)?天|几点", question):
        if not re.search(r"(?:每)?(?:星期|周)[一二三四五六日天1-7]|[0-9]{1,2}月[0-9]{1,2}[日号]|" + number + r"点", text) and not (re.search(r"发布|初评|复核", question) and re.search(r"(?:完成|复核|确认|发布).{0,8}(?:之后|以后|后)", text)):
            return False
    if re.search(r"多久|多长时间|几分钟|多少分钟|几小时|多少小时", question):
        if not re.search(number + r"\s*(?:分钟|小时|课时|天|周)", text):
            return False
    for unit in re.findall(r"(?:几|多少)\s*([道题次名人页])", question):
        if not re.search(number + r"\s*" + unit, text):
            return False
    return True


def _demo_answer(question, hit, document):
    if not document.get("seed_document"):
        return "这份资料中的说明是：\n" + hit["text"]
    topic, version, school = document["topic_id"], document["version"], document["school_id"]
    if topic == "fraction":
        if any(word in question for word in ["教学约定", "纸条", "数轴", "李老师"]):
            return "青溪的教学安排是先用纸条分割展示公分母，再写算式。七年级 A 班由李老师负责，在研学教室 1 开展活动。" if school == "school-qx" else "松原的教学安排是先用数轴对齐刻度，再写算式。分数活动由本校数学教师组织，班级与资源单独管理。"
        if "除法" in question or "相除" in question:
            return "2026 版中，分数除法先把除数取倒数，再转成乘法；除数不能为零。" if version == "2026" else "2025 版这一章节只讲分数加减法，分数除法放在后面的课时。切换到 2026 版可以看到新增内容。"
        example = "1/2 加 1/3，通分后是 3/6 加 2/6，结果为 5/6。" if version == "2026" else "1/4 加 1/2，先把 1/2 改写为 2/4，结果为 3/4。"
        return "分母不一样，先通分，再把分子相加，分母保持不变，最后约分。比如" + example + "这里重点检查学生有没有把分母也直接相加。"
    if topic == "linear":
        return "移项不是凭空换符号，而是等式两边同时加减同一个数。比如 2x+3=11，两边减 3 得到 2x=8，再除以 2 得到 x=4，最后代回原式检查。遇到分数系数，先复习通分再处理。"
    if any(word in question for word in ["发布", "初评", "复核", "AI"]):
        return "初评提供分数和修改建议，教师负责复核；确认后还需要显式发布，不能自动发给学生。普通练习由任课教师发布，正式测评按独立复核和审批流程处理。"
    return "论点是你要表达的判断，论据是支撑它的材料，论证是把两者之间的道理讲清楚。比如说阅读能拓宽视野，要给出阅读不同背景作品后的具体观察，再解释这些观察怎样支持你的观点。"


def _wiki_revision(state, page, reason):
    state["wiki"]["revisions"].append({"id": _id(), "page_id": page["id"], "revision": page["revision"],
                                        "title": page["title"], "body": page["body"], "sources": copy.deepcopy(page["sources"]),
                                        "at": _now(), "reason": reason})
    state["wiki"]["revisions"] = state["wiki"]["revisions"][-100:]


def _wiki_sources(documents):
    return [{"document_id": d["id"], "title": d["title"], "version": d["version"], "source_hash": d["source_hash"],
             "chunk_id": c["chunk_id"], "page": c["page"], "text": c["text"]} for d in documents for c in d["chunks"]]


def _source_signature(sources):
    return _hash([(s["chunk_id"], s["source_hash"]) for s in sources])


def _page_view(state, page):
    result = copy.deepcopy(page)
    documents = {d["id"]: d for d in state["documents"]}
    withdrawn, changed = set(), set()
    for source in page["sources"]:
        doc = documents.get(source["document_id"])
        if not doc or doc.get("status") != "published":
            withdrawn.add(source["document_id"])
        elif doc["school_id"] != page["school_id"] or doc["version"] != page["version"] or source["source_hash"] != doc["source_hash"] or not any(
            c["chunk_id"] == source["chunk_id"] and c["text"] == source["text"] and c["page"] == source["page"] for c in doc["chunks"]
        ):
            changed.add(source["document_id"])
    current_sources = _wiki_sources([d for d in _visible(state, page["school_id"], page["version"]) if d["topic_id"] == page["topic_id"]])
    if _source_signature(current_sources) != page["source_hash"]:
        changed.update(s["document_id"] for s in current_sources)
        if not changed and not withdrawn: changed.add("source-set-changed")
    result["stale_sources"] = sorted(withdrawn | changed)
    result["source_status"] = "withdrawn" if withdrawn else "changed" if changed else "current"
    result["publication"] = page.get("publication", "draft")
    result["review_required"] = result["publication"] != "published" or page.get("reviewed_revision") != page["revision"]
    result["display_mode"] = "人工修订 · 待核对" if page.get("edited") else page["mode"]
    # Historical content stays inspectable, but a withdrawn source is never
    # represented as a currently valid knowledge page.
    result["usable"] = not result["stale_sources"] and not result["review_required"]
    return result


def _wiki_view(state):
    result = copy.deepcopy(state["wiki"])
    result["pages"] = [_page_view(state, p) for p in state["wiki"]["pages"]]
    return result


def compile_wiki(state, payload, model=None):
    school, version = _scope(state, payload)
    docs = _visible(state, school, version)
    if not docs:
        raise ValueError("这个学校和版本没有已发布资料，先导入并发布再编译")
    wiki = state["wiki"]
    created = updated = conflicts = unchanged = 0
    graph = graph_data(state, school, version)
    for topic in teaching_topics():
        related = [d for d in docs if d["topic_id"] == topic["id"]]
        if not related:
            continue
        sources = _wiki_sources(related)
        source_hash = _source_signature(sources)
        for document in related:
            if not any(raw["document_id"] == document["id"] for raw in wiki["raw"]):
                wiki["raw"].append({"document_id": document["id"], "title": document["title"], "school_id": school,
                                    "version": version, "text": document["text"], "source_hash": document["source_hash"], "compiled_at": _now()})
        existing = next((p for p in wiki["pages"] if p["topic_id"] == topic["id"] and p["school_id"] == school and p["version"] == version), None)
        if existing and existing["source_hash"] == source_hash and existing["mode"] == "演示知识页 · 来源摘录":
            unchanged += 1
            continue
        body = "\n\n".join(f"{s['text']}\n〔{s['title']} · 第 {s['page']} 页 · {version}〕" for s in sources)
        mode = "演示知识页 · 来源摘录"
        links = [{"topic_id": e["target"] if e["source"] == topic["id"] else e["source"], "relation": e["type"], "label": e["label"]}
                 for e in graph["edges"] if topic["id"] in (e["source"], e["target"])]
        proposal = {"title": topic["name"], "body": body, "sources": sources, "source_hash": source_hash, "links": links, "mode": mode}
        if existing and existing.get("edited") and existing["body"] != body:
            for conflict in wiki["conflicts"]:
                if conflict["page_id"] == existing["id"] and conflict["status"] == "open" and (conflict["proposal"]["source_hash"] != source_hash or conflict.get("page_revision") != existing["revision"]):
                    conflict.update(status="superseded", superseded_at=_now())
            if not any(c["page_id"] == existing["id"] and c["status"] == "open" and c["proposal"]["source_hash"] == source_hash for c in wiki["conflicts"]):
                wiki["conflicts"].append({"id": _id(), "page_id": existing["id"], "title": existing["title"], "status": "open", "reason": "人工修改页与新来源编译内容不同", "current_body": existing["body"], "page_revision": existing["revision"], "proposal": proposal, "at": _now()})
            conflicts += 1
        elif existing:
            _wiki_revision(state, existing, "来源更新前快照")
            existing.update(proposal, revision=existing["revision"] + 1, edited=False, publication="draft", reviewed_revision=None, updated_at=_now())
            updated += 1
        else:
            wiki["pages"].append({"id": _id(), **proposal, "topic_id": topic["id"], "school_id": school, "version": version,
                                  "revision": 1, "edited": False, "publication": "draft", "updated_at": _now()})
            created += 1
    _event(state, "wiki_compile", {"school_id": school, "version": version, "created": created, "updated": updated, "conflicts": conflicts})
    return {"created": created, "updated": updated, "conflicts": conflicts, "unchanged": unchanged, "wiki": _wiki_view(state), "simulated": True, "model_calls": 0}


def handle(state, action, payload=None, model=None):
    payload = payload or {}
    if action in {"wiki_example", "source_revise", "wiki_submit", "wiki_review", "wiki_ask"}:
        return wiki_learning.handle(state, action, payload)
    if action == "get":
        school, version = _scope(state, payload)
        wiki = _wiki_view(state)
        return {"synthetic": True, "schools": state["schools"], "topics": teaching_topics(),
                "versions": sorted({d["version"] for d in state["documents"]}, reverse=True),
                "suggested_questions": copy.deepcopy(state.get("suggested_questions", [])),
                "current_versions": state["current_versions"], "documents": [{k: v for k, v in d.items() if k != "chunks"} | {"chunk_count": len(d["chunks"])} for d in state["documents"]],
                "last_search": search_view(state, state["last_search"]), "active_policy": copy.deepcopy(state.get("active_policy")), "graph": graph_data(state, school, version), "wiki": wiki, "events": state["events"][-20:]}
    if action == "import":
        school, version = _scope(state, payload)
        title = _text(payload.get("title"), "文档标题", 100)
        body = _text(payload.get("text"), "文档正文")
        topic = payload.get("topic_id", "fraction")
        if topic not in {t["id"] for t in teaching_topics()}:
            raise ValueError("请选择对应知识点")
        if any(d["school_id"] == school and d["version"] == version and d["source_hash"] == _hash(body) and d["status"] != "withdrawn" for d in state["documents"]):
            raise ValueError("相同学校和版本已存在这份内容，无需重复导入")
        if len(state["documents"]) >= 60:
            raise ValueError("演示工作区最多保留 60 份文档，请重置后再试")
        doc = _make_document(title, school, version, topic, body)
        state["documents"].append(doc)
        _event(state, "import", {"document_id": doc["id"], "chunks": len(doc["chunks"])})
        return {"document": doc, "message": "文档已分段保存为草稿，发布后才参与检索"}
    if action in {"publish", "withdraw"}:
        doc = next((d for d in state["documents"] if d["id"] == payload.get("document_id")), None)
        if not doc:
            raise ValueError("没有找到这份文档")
        if action == "publish":
            if doc["status"] == "withdrawn":
                raise ValueError("已撤回的版本不可重新发布，请导入新版本保留审计记录")
            replacement = next((d for d in state["documents"] if d["id"] == doc.get("replaces_document_id")), None)
            if replacement:
                replacement["status"] = "withdrawn"
            doc["status"] = "published"
            if payload.get("make_current", False):
                state["current_versions"][doc["school_id"]] = doc["version"]
        else:
            doc["status"] = "withdrawn"
        detail = {"document_id": doc["id"], "version": doc["version"]}
        if action == "publish": detail["make_current"] = bool(payload.get("make_current", False))
        _event(state, action, detail)
        # A previously rendered answer must not keep implying a withdrawn source
        # is current. Preserve it for traceability but mark the source invalid.
        last = state.get("last_search")
        if action == "withdraw" and last and any(c["document_id"] == doc["id"] for c in last["citations"]):
            last["stale"] = True
            last["stale_reason"] = "引用来源已撤回，请重新检索"
        if action == "withdraw":
            for conflict in state["wiki"]["conflicts"]:
                if conflict["status"] == "open" and any(s["document_id"] == doc["id"] for s in conflict["proposal"]["sources"]):
                    conflict.update(status="superseded", superseded_at=_now())
        return {"document": doc, "message": "已发布，下一次检索立即可见" if action == "publish" else "已撤回，下一次检索立即排除"}
    if action == "search":
        school, version = _scope(state, payload)
        question = _text(payload.get("question"), "问题", 1000)
        active = state.get("active_policy") or {}
        strategy, top_k = active.get("strategy", "hybrid"), active.get("top_k", 6)
        if payload.get("strategy", strategy) != strategy or payload.get("top_k", top_k) != top_k:
            raise ValueError("检索策略与条数由管理员评测后启用，普通查询不能覆盖")
        result = retrieve(state, question, school, version, strategy, top_k)
        result.update(scope_signature=_search_scope_signature(state, school, version), top_k=top_k, policy_run_id=active.get("run_id"), policy_needs_review=active.get("needs_review", False))
        state["last_search"] = result
        _event(state, "search", {"question": question, "school_id": school, "version": version, "hit_count": len(result["hits"])})
        return result
    if action == "graph":
        school, version = _scope(state, payload)
        seed = payload.get("seed_id")
        if seed and seed not in {n["id"] for n in TOPICS}:
            raise ValueError("请选择有效图谱节点")
        return graph_data(state, school, version, [seed] if seed else None, 2)
    if action == "wiki_compile":
        return compile_wiki(state, payload, model)
    if action == "wiki_edit":
        page = next((p for p in state["wiki"]["pages"] if p["id"] == payload.get("page_id")), None)
        if not page:
            raise ValueError("知识页不存在，请先编译")
        body = _text(payload.get("body"), "知识页正文", 20000)
        _wiki_revision(state, page, "人工修改前快照")
        page.update(body=body, revision=page["revision"] + 1, edited=True, publication="draft", reviewed_revision=None, updated_at=_now())
        _event(state, "wiki_edit", {"page_id": page["id"], "revision": page["revision"]})
        return {"page": _page_view(state, page)}
    if action == "wiki_resolve":
        conflict = next((c for c in state["wiki"]["conflicts"] if c["id"] == payload.get("conflict_id")), None)
        if not conflict or conflict["status"] != "open":
            raise ValueError("未找到待处理冲突")
        if payload.get("choice") not in {"accept_source", "keep_edit"}:
            raise ValueError("请选择采用来源或保留人工修改")
        page = next(p for p in state["wiki"]["pages"] if p["id"] == conflict["page_id"])
        if conflict.get("page_revision") != page["revision"]:
            raise ValueError("知识页已在冲突产生后修订，请重新整理并核对新冲突")
        current_documents = [d for d in _visible(state, page["school_id"], page["version"]) if d["topic_id"] == page["topic_id"]]
        if _source_signature(_wiki_sources(current_documents)) != conflict["proposal"]["source_hash"]:
            raise ValueError("冲突提案的来源已发生变化，请重新编译后再处理")
        _wiki_revision(state, page, "解决冲突前快照")
        if payload["choice"] == "accept_source":
            page.update(conflict["proposal"], edited=False)
        else:
            page.update(source_hash=conflict["proposal"]["source_hash"], sources=conflict["proposal"]["sources"], edited=True)
        page.update(revision=page["revision"] + 1, publication="draft", reviewed_revision=None, updated_at=_now())
        conflict.update(status="resolved", resolution=payload["choice"], resolved_at=_now())
        _event(state, "wiki_resolve", {"conflict_id": conflict["id"], "choice": payload["choice"]})
        return {"page": _page_view(state, page), "conflict": conflict}
    if action == "wiki_schema":
        schema = state["wiki"]["schema"]
        if payload:
            required = payload.get("required_fields")
            if not isinstance(required, list) or not {"title", "body", "sources", "school_id", "version"}.issubset(required) or any(x not in {"title", "body", "sources", "school_id", "version", "links", "topic_id"} for x in required):
                raise ValueError("必填字段需保留标题、正文、来源、学校、版本，可增加 links 或 topic_id")
            schema.update(required_fields=required, revision=schema["revision"] + 1)
        return {"schema": schema, "issues": [{"page_id": p["id"], "field": field, "message": "缺少必填内容"} for p in state["wiki"]["pages"] for field in schema["required_fields"] if not p.get(field)]}
    raise ValueError("不支持的知识库操作")
