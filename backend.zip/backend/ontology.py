"""Typed business objects connect retrieval, verified analysis and approved actions."""
OBJECTS = [
    {'id':'school-qx','type':'School','name':'青溪实验学校','properties':{'data':'合成演示','tenant_boundary':True}},
    {'id':'school-sy','type':'School','name':'松原学校','properties':{'data':'合成演示','tenant_boundary':True}},
    {'id':'7A','type':'Class','name':'七年级 A 班','properties':{'grade':7,'school_id':'school-qx'}},
    {'id':'7B','type':'Class','name':'七年级 B 班','properties':{'grade':7,'school_id':'school-qx'}},
    {'id':'8A','type':'Class','name':'八年级 A 班','properties':{'grade':8,'school_id':'school-sy'}},
    {'id':'fraction','type':'KnowledgePoint','name':'分数运算','properties':{'subject':'数学'}},
    {'id':'linear','type':'KnowledgePoint','name':'一元一次方程','properties':{'subject':'数学'}},
    {'id':'argument','type':'KnowledgePoint','name':'论证与表达','properties':{'subject':'语文'}},
    {'id':'room-1','type':'Resource','name':'青溪辅导教室','properties':{'kind':'room'}},
    {'id':'teacher-li','type':'Resource','name':'李老师','properties':{'kind':'teacher'}},
]
LINKS = [
    {'source':'7A','target':'school-qx','type':'belongs_to'},
    {'source':'7B','target':'school-qx','type':'belongs_to'},
    {'source':'8A','target':'school-sy','type':'belongs_to'},
    {'source':'7A','target':'fraction','type':'studies'},
    {'source':'7B','target':'fraction','type':'studies'},
    {'source':'8A','target':'linear','type':'studies'},
    {'source':'teacher-li','target':'school-qx','type':'available_in'},
    {'source':'room-1','target':'school-qx','type':'available_in'},
]


def describe(state):
    analysis = state['modules']['analytics'].get('latest_verified_snapshot')
    objects = list(OBJECTS)
    links = list(LINKS)
    if analysis:
        sid = analysis.get('snapshot_id','verified-analysis')
        objects.append({'id':sid,'type':'AnalysisSnapshot','name':'已复算学情快照','properties':analysis})
        for row in analysis.get('rows',[]):
            cid = row.get('class_id')
            if cid and not any(x['source']==sid and x['target']==cid for x in links):
                links.append({'source':sid,'target':cid,'type':'analyzes'})
    return {'objects':objects,'links':links, 'actions':[
        {'name':'查询教材依据','object_type':'KnowledgePoint','module':'knowledge','description':'按学校和教材版本召回原文，图谱关系只能提供检索路径，不能代替出处。'},
        {'name':'分析班级学情','object_type':'Class','module':'analytics','description':'绑定指标、统计粒度与窗口，经过只读查询和独立复算生成快照。'},
        {'name':'创建干预方案','object_type':'AnalysisSnapshot','module':'intervention','description':'只接收本工作区已通过复算的快照；方案变化后审批失效，执行前重新检查容量。'},
        {'name':'教师复核作文','object_type':'Assessment','module':'essay','description':'评分与原文引用先校验，再经过独立复核与发布动作。'}],
        'definition':'对象 + 有类型的关系 + 带前置条件的动作。这里是可运行的轻量业务本体，不是 Palantir 产品接入。'}
