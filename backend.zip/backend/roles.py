"""Server-enforced demo personas over shared canonical business state."""
from copy import deepcopy
from backend.vendor.intervention_core import digest

KNOWLEDGE = ['get','search','graph','import','publish','withdraw','wiki_compile','wiki_edit','wiki_resolve','wiki_schema','wiki_example','source_revise','wiki_submit','wiki_review','wiki_ask']
EVALUATION = ['get','gold_add','run','export']
ESSAY = ['get','create','revise','score','second','third','approve','release','calibrate']
ANALYTICS = ['get','plan','query','run']
INTERVENTION = ['get','create','create_from_analysis','revise','approve','confirm','execute','draft','revoke','set_capacity']
SHARED = ('knowledge','evaluation','essay','intervention')
BUSINESS_SHARED = ('essay','intervention')
ESSAY_ACTORS = {'teacher-a':'李老师 · 二评','teacher-b':'周老师 · 三评','lead':'负责人'}
INTERVENTION_ACTORS = {'analyst':'分析员','lead':'教研负责人','teacher-li':'李老师 · 任课教师'}

ROLES = {
 'researcher': {'id':'researcher','label':'教研员','description':'审核教学资料、维护标准题集与教学质量验收，处理升级评阅；不代替校长审批或教师执行。',
  'school_ids':['school-qx','school-sy'],'class_ids':['7A','7B','8A'],
  'allowed_actions':{'knowledge':KNOWLEDGE,'evaluation':['get','gold_add','gold_update','business_accept','export'],'essay':['get','third','calibrate'],'analytics':ANALYTICS,'intervention':['get']},
  'recommended':['knowledge','evaluation','essay'],'essay_actors':{'teacher-b':'周老师 · 独立教研复核'},'intervention_actors':{'analyst':'教研观察 · 只读'},'essay_actor':'teacher-b','intervention_actor':'analyst'},
 'principal': {'id':'principal','label':'校长','description':'查看本校学情、审批正式成绩与共享资源干预，跟进执行效果；日常评阅由教师完成。',
  'school_ids':['school-qx'],'class_ids':['7A','7B'],
  'allowed_actions':{'knowledge':['get','search','graph','wiki_ask'],'evaluation':['get'],'essay':['get','approve','release','withdraw'],'analytics':ANALYTICS,'intervention':['get','approve','revoke','set_capacity']},
  'recommended':['analytics','intervention'],'essay_actors':{'lead':'校长 · 重要事项批准'},'intervention_actors':{'lead':'校长 · 资源审批'},'essay_actor':'lead','intervention_actor':'lead'},
 'teacher': {'id':'teacher','label':'教师','description':'李老师的 7A 班：检索资料、复核并发布普通练习、分析学情，提出并落实本班干预和反馈。',
  'school_ids':['school-qx'],'class_ids':['7A'],
  'allowed_actions':{'knowledge':['get','search','graph','wiki_ask'],'evaluation':['get'],'essay':['get','create','confirm_text','revise','score','second','release','withdraw'],'analytics':ANALYTICS,'intervention':['get','create','create_from_analysis','revise','confirm','execute','complete','draft']},
  'recommended':['knowledge','essay','analytics'],'essay_actors':{'teacher-a':'李老师 · 本人评阅'},'intervention_actors':{'analyst':'李老师 · 提出建议','teacher-li':'李老师 · 任课执行'},'essay_actor':'teacher-a','intervention_actor':'teacher-li'},
 'admin': {'id':'admin','label':'系统管理员','description':'运行技术评测、启用经教研验收的检索策略，管理连接、范围与审计；不代批教学业务。',
  'school_ids':['school-qx','school-sy'],'class_ids':['7A','7B','8A'],
  'allowed_actions':{'knowledge':['get'],'evaluation':['get','run','activate','export'],'essay':['get'],'analytics':['get'],'intervention':['get']},
  'recommended':['evaluation','admin'],'essay_actors':{'teacher-a':'系统只读视图'},'intervention_actors':{'analyst':'系统只读视图'},'essay_actor':'teacher-a','intervention_actor':'analyst'},
}
for _role in ROLES.values():
    _role.update(simulation=True,type='system' if _role['id']=='admin' else 'business')


def current(state):
    return ROLES[state.get('persona_id','principal')]


def describe_personas(state):
    return {'current':deepcopy(current(state)), 'roles':deepcopy(list(ROLES.values())),
            'simulation':True, 'scope_note':'三个业务身份与独立系统管理员；角色切换是演示视角，不是组织账号或 SSO。资料、评测、作文和干预在本访客工作区内共享交接，学校班级范围由服务端过滤。'}


def _visible(row, role):
    return row.get('school_id') in role['school_ids'] and row.get('class_id') in role['class_ids']


def scope_modules(modules, role_id, fresh=False):
    """Only personal analytics is scoped in storage; canonical data is projected at reads."""
    role = ROLES[role_id]
    schools, classes = set(role['school_ids']), set(role['class_ids'])
    analytics = modules['analytics']
    if fresh:
        from backend.modules.analytics import _events
        analytics['events'] = _events()
    analytics['events'] = [x for x in analytics['events'] if _visible(x,role)]
    if set(analytics.get('allowed_classes',[])) - classes:
        analytics.update(plan=None,result=None,history=[],latest_verified_snapshot=None)
    analytics['allowed_classes'] = role['class_ids'][:]
    analytics['default_classes'] = [x for x in ('7A','7B') if x in classes]
    return modules


def _legacy_row_order(row):
    stamps = [str(row.get(k) or '') for k in ('at','created_at','updated_at','published_at','executed_at')]
    stamps += [str(event.get('at') or '') for event in row.get('history',[])]
    return (row.get('version',row.get('approved_version',0)) or 0, max(stamps))


def _legacy_active_effects(source):
    released = {row.get('execution_id') for row in source.get('completions',[])}
    return [row for row in source.get('executions',[]) if row['id'] not in released]


def _merge_legacy_business(sources, fresh):
    """Merge v1 role copies without letting an untouched view erase a ledger."""
    merged = deepcopy(fresh)
    ledgers = {'records','formal','plans','executions','completions','drafts','events'}
    for source in sources:
        for key,value in source.items():
            if key in ledgers and isinstance(value,list):
                rows = {row['id']:row for row in merged.get(key,[])}
                for row in value:
                    old = rows.get(row['id'])
                    if old is None or _legacy_row_order(row) >= _legacy_row_order(old):
                        rows[row['id']] = deepcopy(row)
                merged[key] = list(rows.values())
            elif key in {'resources','classes','policies'} and isinstance(value,dict):
                for identity,fields in value.items():
                    target = merged.setdefault(key,{}).setdefault(identity,{})
                    defaults = fresh.get(key,{}).get(identity,{})
                    for field,setting in fields.items():
                        # A fresh teacher copy cannot reset an edited capacity/policy.
                        if field not in target or setting != defaults.get(field):
                            target[field] = deepcopy(setting)
            elif isinstance(value,dict):
                merged.setdefault(key,{}).update(deepcopy(value))
            else:
                merged[key] = deepcopy(value)
    if 'executions' in merged:
        # Effects are deduplicated first. Rebuild reservations from the surviving
        # ledger, rather than summing duplicated role counters or keeping zeroes.
        active = _legacy_active_effects(merged)
        for rid,resource in merged['resources'].items():
            baselines = [max(0,source['resources'][rid].get('used',0) - sum(
                effect['participants'] for effect in _legacy_active_effects(source)
                if rid in effect['resources'])) for source in sources if rid in source.get('resources',{})]
            resource['used'] = max(baselines,default=0) + sum(
                effect['participants'] for effect in active if rid in effect['resources'])
        for cid,cls in merged['classes'].items():
            baselines = [source['classes'][cid]['existing_minutes'] - sum(
                effect['new_minutes'] for effect in _legacy_active_effects(source)
                if effect['class_id']==cid) for source in sources if cid in source.get('classes',{})]
            cls['existing_minutes'] = max(baselines,default=cls['existing_minutes']) + sum(
                effect['new_minutes'] for effect in active if effect['class_id']==cid)
    return merged


def migrate(state, seed):
    content_migration=getattr(seed,'migrate_content',None)
    if state.get('persona_schema') == 3 and state.get('persona_id') in ROLES:
        return bool(content_migration and content_migration(state))
    # P3/P5 already share a canonical ledger in schema 2. Only legacy v1 needs merging.
    if state.get('persona_schema',1)<2:
        slots=[*state.get('persona_states',{}).values(),state]
        for name in BUSINESS_SHARED:
            sources=[slot.get('modules',{}).get(name,{}) for slot in slots]
            state['modules'][name]=_merge_legacy_business(sources,seed()['modules'][name])
    from backend.workspace_migration import migrate_shared
    migrate_shared(state)
    role_id=state.get('persona_id','principal')
    state['persona_id']=role_id if role_id in ROLES else 'principal'
    state['persona_states']={k:{'modules':{n:v for n,v in slot.get('modules',{}).items() if n not in SHARED},'events':slot.get('events',[])} for k,slot in state.get('persona_states',{}).items() if k in ROLES}
    scope_modules(state['modules'],state['persona_id'])
    state['persona_schema']=3
    if content_migration:content_migration(state)
    return True


def switch(state, role_id, seed):
    if role_id not in ROLES:
        raise ValueError('请选择教研员、校长、教师或系统管理员')
    old = state.get('persona_id','principal')
    if role_id == old:
        return
    shared = {name:state['modules'][name] for name in SHARED}
    saved = state.setdefault('persona_states',{})
    saved[old] = {'modules':{k:v for k,v in state['modules'].items() if k not in SHARED}, 'events':state['events']}
    target = saved.pop(role_id,None)
    if target is None:
        target = {'modules':seed(role_id)['modules'], 'events':[]}
    state.update(persona_id=role_id, modules={**target['modules'],**shared}, events=target['events'])


def reset_current(state, seed):
    shared = {name:state['modules'][name] for name in SHARED}
    state['modules'] = {**seed(state['persona_id'])['modules'],**shared}
    state['events'] = []
    state.setdefault('knowledge_views',{}).pop(state['persona_id'],None)


def reset_all(state, seed):
    if state['persona_id'] != 'admin':
        raise PermissionError('只有系统管理员可以重置本访客的全部演示数据')
    fresh = seed('admin')
    identity={k:state[k] for k in ('id','created_at') if k in state}
    state.clear()
    state.update(identity, **fresh, events=[], model_usage=[])


def intervention_source_stale(state, plan):
    if plan.get('wiki_refs'):
        from backend.wiki_learning import references
        try:references(state['modules']['knowledge'],plan['wiki_refs'],plan['school_id'])
        except (ValueError, PermissionError):return True
    if plan.get('metric_kind')!='essay_quality':return False
    referenced=set(plan.get('evidence',{}).get('formal_ids',[]))
    current={r['id'] for r in state['modules']['essay']['formal'] if r.get('status','published')=='published'}
    return not referenced or not referenced.issubset(current)


def authorize(state, module, action, payload):
    role = current(state)
    if action not in role['allowed_actions'].get(module,[]):
        raise PermissionError(f"{role['label']}视角不能执行这项操作，请切换到有权限的演示角色")
    payload = deepcopy(payload)
    if 'school_id' in payload and payload['school_id'] not in role['school_ids']:
        raise PermissionError('所选学校不在当前角色范围内')
    if 'class_id' in payload and payload['class_id'] not in role['class_ids']:
        raise PermissionError('所选班级不在当前角色范围内')
    if 'class_ids' in payload and (not isinstance(payload['class_ids'],list) or not all(x in role['class_ids'] for x in payload['class_ids'])):
        raise PermissionError('所选班级不在当前角色范围内')
    if ((module=='knowledge' and action in {'get','import','search','graph','wiki_compile','wiki_example','wiki_ask'}) or (module=='evaluation' and action in {'gold_add','gold_update'})) and 'school_id' not in payload:
        payload['school_id'] = role['school_ids'][0]
    if module in BUSINESS_SHARED:
        actor = payload.get('actor',role[module+'_actor'])
        if actor not in role[module+'_actors']:
            raise PermissionError('当前全局角色不能切换到这位审批人或评阅人')
        payload['actor'] = actor
        if action in {'create','create_from_analysis'} and 'class_id' not in payload:
            payload['class_id'] = role['class_ids'][0]
        if action not in {'get','create','create_from_analysis','calibrate','set_capacity'}:
            target = state['modules'][module]
            rows = target['records' if module=='essay' else 'plans']
            rid = payload.get('id')
            if not rid:
                visible = [r for r in rows if _visible(r,role)]
                rid = next((r['id'] for r in visible if r['id']==target.get('active_id')),visible[-1]['id'] if visible else None)
            row = next((r for r in rows if r['id']==rid),None)
            if row is not None and not _visible(row,role):
                raise PermissionError('这条记录不在当前角色的学校班级范围内')
            payload['id'] = rid or '__no_visible_record__'
            if module=='intervention' and row is not None and action in {'approve','confirm','execute'} and row.get('state') not in {'executed','completed'} and intervention_source_stale(state,row):
                raise ValueError('方案来源成绩或知识页已撤回或更新，请重新分析并创建新方案；历史记录保留。')
        if module=='intervention' and action=='set_capacity':
            resource = state['modules'][module]['resources'].get(payload.get('resource_id'))
            if resource and resource.get('school_id') not in role['school_ids']:
                raise PermissionError('该资源不在当前学校范围内')
    if module=='evaluation' and action=='gold_update':
        gold=next((g for g in state['modules']['evaluation']['gold'] if g['id']==payload.get('gold_id')),None)
        if gold and gold['school_id'] not in role['school_ids']:
            raise PermissionError('标准题不在当前学校范围内')
    if module=='knowledge':
        payload['_reviewer']=role['id']
        kb=state['modules']['knowledge']
        row=None
        if payload.get('document_id'):
            row=next((d for d in kb['documents'] if d['id']==payload['document_id']),None)
        elif payload.get('page_id'):
            row=next((d for d in kb['wiki']['pages'] if d['id']==payload['page_id']),None)
        elif payload.get('conflict_id'):
            conflict=next((c for c in kb['wiki']['conflicts'] if c['id']==payload['conflict_id']),None)
            if conflict:row=next((d for d in kb['wiki']['pages'] if d['id']==conflict['page_id']),None)
        if row and row['school_id'] not in role['school_ids']:
            raise PermissionError('资料不在当前学校范围内')
    if module=='knowledge' and payload.get('seed_id') in {'7A','7B','8A'} and payload['seed_id'] not in role['class_ids']:
        raise PermissionError('图谱班级不在当前角色范围内')
    return payload


def _snapshot_scope(snapshot, role):
    out=deepcopy(snapshot)
    if isinstance(out,dict) and isinstance(out.get('rows'),list):
        out['rows']=[row for row in out['rows'] if _visible(row,role)]
        out['source_hash']=digest({k:v for k,v in out.items() if k!='source_hash'})
    return out


def project_result(state, module, result):
    role=current(state)
    out=deepcopy(result)
    if module=='knowledge':
        from backend.modules.evaluation import _active_view
        policy=_active_view(state['modules']['evaluation'],state['modules']['knowledge'])
        if 'active_policy' in out:out['active_policy']=policy
        schools=set(role['school_ids'])
        if 'schools' in out:out['schools']=[x for x in out['schools'] if x['id'] in schools]
        if 'documents' in out:out['documents']=[x for x in out['documents'] if x['school_id'] in schools]
        if 'suggested_questions' in out:out['suggested_questions']=[x for x in out['suggested_questions'] if x['school_id'] in schools]
        if 'current_versions' in out:out['current_versions']={k:v for k,v in out['current_versions'].items() if k in schools}
        if 'versions' in out:out['versions']=sorted({d['version'] for d in state['modules']['knowledge']['documents'] if d['school_id'] in schools},reverse=True)
        if 'last_search' in out:
            from backend.modules.knowledge import search_view
            out['last_search']=search_view({**state['modules']['knowledge'],'active_policy':policy},state.get('knowledge_views',{}).get(role['id']))
        wiki=out.get('wiki')
        if wiki:
            for key in ('raw','pages'):wiki[key]=[r for r in wiki[key] if r.get('school_id') in schools]
            ids={r['id'] for r in wiki['pages']}
            for key in ('conflicts','revisions'):wiki[key]=[r for r in wiki[key] if r.get('page_id') in ids]
        if 'events' in out:
            docs={d['id']:d for d in state['modules']['knowledge']['documents']}
            pages={p['id']:p for p in state['modules']['knowledge']['wiki']['pages']}
            def event_visible(e):
                detail=e.get('detail',{})
                if not isinstance(detail,dict):return False
                sid=detail.get('school_id') or docs.get(detail.get('document_id'),{}).get('school_id') or pages.get(detail.get('page_id'),{}).get('school_id')
                return sid in schools
            out['events']=[e for e in out['events'] if event_visible(e)]
    if module=='evaluation':
        schools=set(role['school_ids'])
        if 'gold_history' in out:out['gold_history']=[g for g in out['gold_history'] if g.get('school_id') in schools]
        if 'gold' in out:out['gold']=[g for g in out['gold'] if g['school_id'] in schools]
        def scoped_run(run):
            if not run:return
            rows=run.get('gold_snapshot',[])
            ids={g['id'] for g in rows if g['school_id'] in schools}
            if 'gold_snapshot' in run:run['gold_snapshot']=[g for g in rows if g['id'] in ids]
            for side in ('baseline','candidate'):
                for key in ('answers','per_item','outputs'):
                    if isinstance(run.get(side,{}).get(key),list):run[side][key]=[r for r in run[side][key] if r['id'] in ids]
            run['scope_note']='平台共享评测汇总，明细仅显示当前学校；整体指标不是本校独立评分'
        scoped_run(out.get('last_run'))
        for run in out.get('runs',[]):scoped_run(run)
        # Pre-migration reports are historical audit evidence, not active quality approval.
        out.pop('legacy_runs',None)
    if module in BUSINESS_SHARED:
        records=state['modules'][module]['records' if module=='essay' else 'plans']
        allowed={row['id'] for row in records if _visible(row,role)}
        list_key='records' if module=='essay' else 'plans'
        if list_key in out: out[list_key]=[row for row in out[list_key] if row['id'] in allowed]
        if out.get('active_id') not in allowed:
            rows=out.get(list_key,[])
            out['active_id']=rows[0]['id'] if rows else None
        if 'actors' in out: out['actors']=deepcopy(role[module+'_actors'])
        for key,foreign in [('formal','essay_id'),('executions','plan_id'),('drafts','plan_id'),('completions','plan_id'),('events','object_id')]:
            if isinstance(out.get(key),list): out[key]=[row for row in out[key] if row.get(foreign) in allowed]
        if module=='essay' and 'current_published_count' in out:
            out['current_published_count']=len({r['essay_id'] for r in out.get('formal',[]) if r.get('status','published')=='published'})
        if module=='intervention':
            if 'classes' in out: out['classes']={k:v for k,v in out['classes'].items() if _visible(v,role)}
            if 'resources' in out: out['resources']={k:v for k,v in out['resources'].items() if v.get('school_id') in role['school_ids']}
            if 'policies' in out:
                keys={f"{v['grade']}-{v['region']}" for v in state['modules'][module]['classes'].values() if _visible(v,role)}
                out['policies']={k:v for k,v in out['policies'].items() if k in keys}
            if 'sample_snapshot' in out: out['sample_snapshot']=_snapshot_scope(out['sample_snapshot'],role)
            # Older saved plans may predate single-class derived snapshots.
            for plan in out.get('plans',[]) + ([out['plan']] if 'plan' in out else []):
                plan['source_stale']=intervention_source_stale(state,plan)
                if any(not _visible(row,role) for row in plan.get('snapshot',{}).get('rows',[])):
                    plan['snapshot']=_snapshot_scope(plan['snapshot'],role)
                    plan['snapshot_projection']=True
    def graph_scope(obj):
        if not isinstance(obj,dict): return
        if isinstance(obj.get('nodes'),list) and isinstance(obj.get('edges'),list):
            obj['nodes']=[x for x in obj['nodes'] if x.get('id') not in {'7A','7B','8A'} or x['id'] in role['class_ids']]
            ids={x['id'] for x in obj['nodes']}
            obj['edges']=[x for x in obj['edges'] if x['source'] in ids and x['target'] in ids]
        for value in obj.values():
            if isinstance(value,dict): graph_scope(value)
    if module=='knowledge': graph_scope(out)
    return out


def ontology_projection(state, data):
    role=current(state)
    data=deepcopy(data)
    resources={k for k,v in state['modules']['intervention']['resources'].items() if v.get('school_id') in role['school_ids']}
    data['objects']=[o for o in data['objects'] if (o['type']!='School' or o['id'] in role['school_ids']) and (o['type']!='Class' or o['id'] in role['class_ids']) and (o['type']!='Resource' or o['id'] in resources) and (not o.get('properties',{}).get('school_id') or o['properties']['school_id'] in role['school_ids'])]
    ids={o['id'] for o in data['objects']}
    data['links']=[x for x in data['links'] if x['source'] in ids and x['target'] in ids]
    data['actions']=[x for x in data['actions'] if len(role['allowed_actions'].get(x['module'],[]))>1]
    return data


def export_current(state):
    result=deepcopy(state)
    result.pop('persona_states',None)
    result.pop('migration_archive',None)
    result.pop('knowledge_views',None)
    from backend.modules.essay import view as essay_view
    result['modules']['essay'] = {**essay_view(state['modules']['essay'],current(state)['essay_actor']), 'events':state['modules']['essay']['events']}
    for name in ('knowledge','evaluation','essay','intervention'):
        result['modules'][name]=project_result(state,name,result['modules'][name])
    if 'integrations' in state:
        from backend.integrations import view as integration_view
        result['integrations']=integration_view(state)
    return result


def audit_events(state):
    if state['persona_id'] != 'admin':
        return deepcopy(state['events'])
    slots={**state.get('persona_states',{}),state['persona_id']:state}
    logs=[{**event,'persona_id':role_id} for role_id,slot in slots.items() for event in slot.get('events',[])]
    return sorted(logs,key=lambda x:x.get('at',0))


def admin_summary(state):
    if state['persona_id']!='admin':
        raise PermissionError('只有系统管理员可以打开管理设置')
    slots={**state.get('persona_states',{}),state['persona_id']:state}
    logs=audit_events(state)
    return {'simulation':True,'model_enabled':False,'model_calls':0,'workspace_id':state['id'],
            'roles':deepcopy(list(ROLES.values())),
            'persona_counts':{rid:{'events':len(slot.get('events',[])),'documents':len(state['modules']['knowledge']['documents'])} for rid,slot in slots.items()},
            'shared_counts':{'essays':len(state['modules']['essay']['records']),'published_essays':len({r['essay_id'] for r in state['modules']['essay']['formal'] if r.get('status','published')=='published'}),
                             'plans':len(state['modules']['intervention']['plans']),'executions':len(state['modules']['intervention']['executions'])},
            'recent_events':sorted(logs,key=lambda x:x.get('at',0))[-20:],
            'reset_scope':'只重置本访客工作区的全部演示记录，不影响其他访客；不操作外部系统。'}
