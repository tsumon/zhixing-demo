"""Persistent local workspaces and audit; short writes use SQLite transactions."""
import hashlib
import json
import secrets
import sqlite3
import threading
import time
from contextlib import contextmanager, closing
from pathlib import Path


class Store:
    def __init__(self, path, seed):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.seed = seed
        self.lock = threading.RLock()
        self.local = threading.local()
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('CREATE TABLE IF NOT EXISTS workspaces (id TEXT PRIMARY KEY, token_hash TEXT UNIQUE, created REAL, updated REAL, state TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS audit (workspace_id TEXT NOT NULL, id TEXT NOT NULL, actor_id TEXT NOT NULL, at REAL NOT NULL, event TEXT NOT NULL, PRIMARY KEY(workspace_id,id))')
            db.execute('CREATE INDEX IF NOT EXISTS audit_workspace_actor ON audit(workspace_id,actor_id,at)')
        # Preserve pre-V6 history before any ordinary workspace reset can clear it.
        with self.transaction() as db:
            for (raw,) in db.execute('SELECT state FROM workspaces').fetchall():
                state = json.loads(raw)
                self.capture_events(state)
                for actor_id, slot in state.get('persona_states', {}).items():
                    self.capture_events({**slot, 'id':state['id'], 'persona_id':actor_id})

    @contextmanager
    def connect(self):
        active = getattr(self.local, 'db', None)
        if active is not None:
            yield active
            return
        with closing(sqlite3.connect(self.path, timeout=30)) as db:
            with db:
                yield db

    @contextmanager
    def transaction(self):
        """Serialize the entire read-modify-write, including other processes.

        Nested helpers share this connection and cannot commit the outer write.
        Only local synthetic operations belong inside this short transaction.
        """
        active = getattr(self.local, 'db', None)
        if active is not None:
            yield active
            return
        with self.lock, self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self.local.db = db
            try:
                yield db
            except BaseException:
                db.rollback()
                raise
            else:
                db.commit()
            finally:
                self.local.db = None

    def create(self):
        with self.transaction() as db:
            now = time.time()
            if db.execute('SELECT COUNT(*) FROM workspaces').fetchone()[0] >= 300:
                raise ValueError('工作区已满，请联系管理员归档现有工作区。')
            token = secrets.token_urlsafe(32)
            wid = 'ws-' + secrets.token_hex(6)
            state = self.seed()
            state.update({'id':wid, 'created_at':now, 'events':[], 'model_usage':[]})
            db.execute('INSERT INTO workspaces VALUES(?,?,?,?,?)', (wid, hashlib.sha256(token.encode()).hexdigest(), now, now, json.dumps(state, ensure_ascii=False)))
            return token, wid

    def load(self, token):
        if not token or len(token) > 128:
            raise KeyError('请先进入工作区。')
        with self.connect() as db:
            row = db.execute('SELECT state FROM workspaces WHERE token_hash=?',
                (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
        if not row:
            raise KeyError('未找到此工作区，请重新进入。')
        return json.loads(row[0])

    def load_id(self, workspace_id):
        with self.connect() as db:
            row = db.execute('SELECT state FROM workspaces WHERE id=?', (workspace_id,)).fetchone()
        if not row:
            raise KeyError('未找到任务所属工作区。')
        return json.loads(row[0])

    def append_audit(self, workspace_id, actor_id, event):
        record = {**event, 'actor_id':actor_id, 'persona_id':actor_id}
        with self.connect() as db:
            db.execute('INSERT OR IGNORE INTO audit VALUES(?,?,?,?,?)',
                (workspace_id, event['id'], actor_id, event.get('at',time.time()), json.dumps(record,ensure_ascii=False)))

    def capture_events(self, state):
        for event in state.get('events', []):
            self.append_audit(state['id'],state.get('persona_id','principal'),event)

    def audit(self, workspace_id, actor_id):
        with self.connect() as db:
            if actor_id == 'admin':
                rows = db.execute('SELECT event FROM audit WHERE workspace_id=? ORDER BY at,id', (workspace_id,)).fetchall()
            else:
                rows = db.execute('SELECT event FROM audit WHERE workspace_id=? AND actor_id=? ORDER BY at,id', (workspace_id,actor_id)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def save(self, state):
        with self.transaction() as db:
            db.execute('UPDATE workspaces SET state=?,updated=? WHERE id=?',
                (json.dumps(state, ensure_ascii=False), time.time(), state['id']))
            self.capture_events(state)

    def ready(self):
        with self.connect() as db:
            db.execute('SELECT id FROM workspaces LIMIT 1').fetchone()
            db.execute('SELECT id FROM audit LIMIT 1').fetchone()
            db.execute('SELECT id FROM tasks LIMIT 1').fetchone()

    def reset(self, state):
        fresh = self.seed()
        fresh.update({'id':state['id'], 'created_at':state['created_at'], 'events':[], 'model_usage':state.get('model_usage',[])})
        self.save(fresh)
        return fresh
