"""Actor-specific business inbox derived from canonical state, not channel copies."""
from backend import roles


def view(state):
    role=roles.current(state); rid=role['id']; rows=[]
    def add(module,row,title,owner,action,status,done=False):
        allowed=action in role['allowed_actions'].get(module,[])
        mine=not done and owner==rid and allowed
        rows.append({'id':row['id'],'module':module,'title':title,'scope':row.get('class_id',row.get('school_id','平台')),
                     'version':row.get('version',row.get('gold_revision',1)),'status':status,'owner_role':owner,
                     'owner_label':roles.ROLES.get(owner,{}).get('label','—'),'action':action if mine else None,
                     'bucket':'done' if done else 'mine' if mine else 'waiting','can_act':mine})
    for r in state['modules']['essay']['records']:
        if not roles._visible(r,role):continue
        status=r['state']; owner='teacher'; action='second'
        if status=='awaiting_correction':action='confirm_text'
        elif status=='awaiting_ai':action='score'
        elif status=='withdrawn':action='revise'
        elif status=='third_required':owner,action='researcher','third'
        elif status=='awaiting_approval':owner,action='principal','approve'
        elif status=='approved':owner,action=('principal' if r.get('assessment_type','formal')=='formal' else 'teacher'),'release'
        from backend.modules.essay import STATE_LABELS as LABELS
        add('essay',r,r.get('title','作文评阅'),owner,action,LABELS.get(status,status),status=='published')
    for p in state['modules']['intervention']['plans']:
        if not roles._visible(p,role):continue
        status=p['state']; owner,action={'awaiting_lead':('principal','approve'),'awaiting_teacher':('teacher','confirm'),
            'ready':('teacher','execute'),'executed':('teacher','complete'),'rules_rejected':('teacher','revise')}.get(status,('teacher',None))
        from backend.modules.intervention import LABELS
        needs_release=status=='revoked' and bool(p.get('execution_id')) and not p.get('completion_id')
        if needs_release:owner,action='teacher','complete'
        if status not in {'executed','completed','revoked'} and roles.intervention_source_stale(state,p):
            add('intervention',p,p['proposal']['title'],'teacher','create_from_analysis','来源成绩已撤回 · 待重新分析')
            continue
        add('intervention',p,p['proposal']['title'],owner,action,'已撤销 · 待释放本次资源' if needs_release else LABELS.get(status,status),status=='completed' or (status=='revoked' and not needs_release))
    for d in state['modules']['knowledge']['documents']:
        if d['school_id'] in role['school_ids'] and d['status']=='draft':
            add('knowledge',d,d['title'],'researcher','publish','待资料审核')
    run=state['modules']['evaluation'].get('last_run')
    if run and rid in {'researcher','admin'}:
        from backend.modules.evaluation import handle
        current=handle({'knowledge':state['modules']['knowledge'],'evaluation':state['modules']['evaluation']},'get')['last_run']
        activation=current.get('activation',{})
        if activation.get('fresh') and current['gate']['passed']:
            accepted=activation.get('business_accepted')
            done=activation.get('active',False)
            add('evaluation',current,'检索方案质量验收与启用','admin' if accepted else 'researcher',
                'activate' if accepted else 'business_accept','已启用' if done else '待管理员启用' if accepted else '待教研验收',done)
    return {'items':rows,'counts':{key:sum(r['bucket']==key for r in rows) for key in ('mine','waiting','done')},
            'simulation':True,'role_id':rid}
