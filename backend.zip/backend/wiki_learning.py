"""Local, source-bound Wiki workflow. No model calls or student records."""
from copy import deepcopy
import re

TOPICS = [
    {'id':'coordinates','name':'坐标与变化率','type':'knowledge','aliases':['坐标点','横轴','纵轴','变化率']},
    {'id':'function_graph','name':'一次函数图像','type':'knowledge','aliases':['一次函数','斜率','截距','看图像','代公式']},
]
RELATION = ('coordinates','function_graph','prerequisite','坐标与变化率支撑一次函数图像解释')
STATEMENT = '坐标点与变化率是解释一次函数图像的前置知识。'
EXAMPLES = [
    ('coordinates','坐标与变化率·补讲依据',
     '坐标点 (x,y) 把横轴输入和纵轴输出对应起来。先读坐标轴单位，再用表格列出点并描点。\n\n'
     '比较相邻点时，说清横向增加多少、纵向变化多少；纵向变化量除以横向变化量得到变化率。\f'
     '补讲先让学生把表格、坐标点和图像互相转换，再口述点在图像上的含义。' + STATEMENT),
    ('function_graph','一次函数·从公式到图像',
     '一次函数 y=kx+b 中，k 表示斜率：k>0 时随 x 增大而上升，k<0 时下降；b 是 x=0 时的 y 值，对应纵轴交点。\n\n'
     '会代公式但不会看图像，可先把坐标对应、斜率增减趋势、截距位置列为诊断候选，不能直接断言某个学生缺哪项能力。\f'
     '补讲顺序：先把代入得到的数对标成坐标点，再对比相同 b 不同 k 的图像，最后固定 k 改变 b，解释纵轴交点怎样移动。\n\n'
     '让学生独立完成描点、读趋势、找截距并说明理由，依据作答证据判断个体原因；知识页不保存班级实时成绩。' + STATEMENT),
]


def references(kb, requested, school):
    from backend.modules import knowledge as k
    if not isinstance(requested,list) or len(requested)>8:
        raise ValueError('知识页引用必须是至多 8 项的列表')
    result=[]
    for ref in requested:
        if not isinstance(ref,dict):raise ValueError('知识页引用格式无效')
        page=next((p for p in kb['wiki']['pages'] if p['id']==ref.get('page_id')),None)
        if not page or page['school_id']!=school:raise PermissionError('知识页不在当前学校范围内')
        if page['version']!=ref.get('version') or page['revision']!=ref.get('revision') or not k._page_view(kb,page)['usable']:
            raise ValueError('知识页版本或来源已失效，请重新查询并选择已发布版本')
        result.append({'page_id':page['id'],'title':page['title'],'revision':page['revision'],'version':page['version'],
                       'school_id':school,'sources':deepcopy(page['sources'])})
    return result


def handle(kb, action, payload):
    from backend.modules import knowledge as k
    if action=='wiki_example':
        school,version=k._scope(kb,payload)
        documents=[]
        for topic,title,body in EXAMPLES:
            marker=f'wiki-learning-v8:{school}:{version}:{topic}'
            doc=next((d for d in kb['documents'] if d.get('learning_key')==marker),None)
            if doc is None:
                doc=k._make_document(title,school,version,topic,f'{title} · {version} 版\n'+body)
                doc.update(learning_key=marker,relation_assertions=[{'source':RELATION[0],'target':RELATION[1],'type':RELATION[2],'label':RELATION[3],'statement':STATEMENT}])
                kb['documents'].append(doc)
            documents.append(doc)
        k._event(kb,action,{'school_id':school,'version':version})
        return {'documents':documents,'message':'已准备 2 份一次函数来源草稿，请先核对并发布来源，再整理知识页。'}
    if action=='source_revise':
        old=next((d for d in kb['documents'] if d['id']==payload.get('document_id')),None)
        if not old:raise ValueError('来源不存在')
        if len(kb['documents'])>=60:raise ValueError('最多保留 60 份资料')
        body=k._text(payload.get('text'),'修订正文')
        doc=k._make_document(old['title'],old['school_id'],old['version'],old['topic_id'],body,series_id=old['series_id'])
        doc.update(replaces_document_id=old['id'],relation_assertions=[a for a in old.get('relation_assertions',[]) if a['statement'] in body])
        kb['documents'].append(doc)
        k._event(kb,action,{'document_id':doc['id'],'replaces_document_id':old['id']})
        return {'document':doc,'message':'修订已保存为新来源草稿。发布时替换旧来源，依赖知识页需重新整理审核。'}
    if action in {'wiki_submit','wiki_review'}:
        page=next((p for p in kb['wiki']['pages'] if p['id']==payload.get('page_id')),None)
        if not page:raise ValueError('知识页不存在')
        if type(payload.get('revision')) is not int or payload['revision']!=page['revision']:
            raise ValueError('知识页修订已变化，请刷新后核对')
        view=k._page_view(kb,page)
        if view['stale_sources']:raise ValueError('来源已变化，请先重新整理知识页')
        if any(c['page_id']==page['id'] and c['status']=='open' for c in kb['wiki']['conflicts']):
            raise ValueError('请先解决来源与人工修订冲突')
        if action=='wiki_submit':
            if page.get('publication')=='published':raise ValueError('当前版本已经发布')
            page.update(publication='pending_review',submitted_at=k._now())
        else:
            if page.get('publication')!='pending_review':raise ValueError('请先提交教研审核')
            decision=payload.get('decision')
            if decision not in {'publish','return'}:raise ValueError('请选择发布或退回')
            note=k._text(payload.get('note'),'审核意见',1000)
            page.update(publication='published' if decision=='publish' else 'returned',reviewed_revision=page['revision'] if decision=='publish' else None,
                        review={'note':note,'decision':decision,'by':payload.get('_reviewer','researcher'),'at':k._now(),'revision':page['revision']})
        k._event(kb,action,{'page_id':page['id'],'revision':page['revision'],'publication':page['publication']})
        return {'page':k._page_view(kb,page),'message':'已提交教研审核' if action=='wiki_submit' else '审核通过，知识页已发布' if payload['decision']=='publish' else '已退回修订'}
    if action=='wiki_ask':return ask(kb,payload)
    raise ValueError('不支持的知识页操作')


def ask(kb,payload):
    from backend.modules import knowledge as k
    school,version=k._scope(kb,payload)
    question=k._text(payload.get('question'),'问题',1000)
    result={'question':question,'school_id':school,'version':version,'strategy':'wiki','route':'wiki','retrieval_version':k.RETRIEVAL_VERSION,
            'mode':'知识页综合问答','model_calls':0,'simulated':True,'synthetic':True,'at':k._now(),
            'refused':True,'answer':'当前主题还没有完成审核且来源有效的知识页，请联系教研员整理并发布。','hits':[],'citations':[],'wiki_refs':[],
            'trace':[],'scope_signature':k._search_scope_signature(kb,school,version)}
    if re.search(r'本周|今天|实时|完成率|成绩|名单|多少人|\b[78][AB]\b',question):
        result.update(route='analytics',answer='这类学生或班级事实请到学情问数读取当前授权数据。知识页只提供教学参考，不保存实时学情。')
    else:
        topics=set(k._entities(question))
        if 'function_graph' in topics:topics.update({'coordinates','function_graph'})
        pages=[p for p in kb['wiki']['pages'] if p['school_id']==school and p['version']==version and p['topic_id'] in topics]
        usable=[p for p in pages if k._page_view(kb,p)['usable']]
        # Missing a prerequisite must not silently produce a partial diagnostic path.
        if topics and topics.issubset({p['topic_id'] for p in usable}):
            usable.sort(key=lambda p:(p['topic_id']!='coordinates',p['title']))
            sources={s['chunk_id']:s for p in usable for s in p['sources']}
            docs={d['id']:d for d in k._visible(kb,school,version)}
            for source in sources.values():
                chunk=next(c for c in docs[source['document_id']]['chunks'] if c['chunk_id']==source['chunk_id'])
                result['hits'].append({**k.Chunk(**chunk).evidence(),'title':source['title'],'school_id':school,'text':source['text'],
                                       'score':1.0,'bm25':0.0,'char_similarity':0.0,'keyword_rank':None,'similarity_rank':None,'graph_paths':[]})
            result['citations']=[{key:h[key] for key in ('chunk_id','document_id','version_id','page','section','title')} for h in result['hits']]
            result['wiki_refs']=references(kb,[{'page_id':p['id'],'version':version,'revision':p['revision']} for p in usable],school)
            result.update(refused=False,answer='补讲路径：'+' → '.join(p['title'] for p in usable)+'\n\n'+'\n\n'.join(f'【{p["title"]} · 修订 {p["revision"]}】\n{p["body"]}' for p in usable),
                          citation_check='知识页已通过教研审核；以下每段原文仍可展开核对。关系仅形成诊断候选，个体原因需作答证据。')
    result['trace']=[{'step':'先限定学校与版本','detail':f'{school} / {version}；仅使用已发布且来源有效的知识页'},
                     {'step':'组织讲解路径','detail':'使用审核后的知识页与依赖关系；不读取或写入学生事实'},
                     {'step':'回到原文','detail':f'{len(result["citations"])} 段当前有效出处'}]
    kb['last_search']=result
    k._event(kb,'wiki_ask',{'school_id':school,'version':version,'refused':result['refused']})
    return result
