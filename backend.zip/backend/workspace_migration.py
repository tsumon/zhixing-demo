"""One-time convergence of the old per-persona demo copies.

Historical evidence is archived verbatim; only live references are remapped.
No old evaluation report can authorize a new retrieval release.
"""
from copy import deepcopy
from backend.modules import knowledge, evaluation


def migrate_essay_formal(state):
    """Backfill published ledger scope from its original essay, never invent grades."""
    essay = state.get('modules', {}).get('essay', {})
    records = {row['id']: row for row in essay.get('records', [])}
    for formal in essay.get('formal', []):
        record = records.get(formal.get('essay_id'))
        if record is None:
            # Preserve orphan history for review; it is not an authorized class score.
            formal.setdefault('migration_note', '原作文记录缺失，保留旧成绩但不推定学校班级或学生')
            continue
        for key in ('school_id', 'class_id', 'max_score', 'knowledge_id'):
            if key not in formal and key in record:
                formal[key] = deepcopy(record[key])
        formal.setdefault('assessment_type', record.get('assessment_type', 'formal'))
        formal.setdefault('knowledge_id', 'argument')
        formal.setdefault('version', formal.get('approved_version'))
        formal.setdefault('student_id', record.get('student_id'))
        formal.setdefault('student_linked', bool(formal.get('student_id')))
        formal.setdefault('dimensions', [])
        formal.setdefault('dimension_source', 'legacy_total_only')
        formal.setdefault('metadata_source', '原作文记录关联补齐；无学生关联的不计准确人数')


def migrate_shared(state):
    slots=[*state.get('persona_states',{}).values(),state]
    sources=[slot.get('modules',{}).get('knowledge',{}) for slot in slots]
    state['migration_archive']={'schema':state.get('persona_schema',1),
        'knowledge_evaluation':[{'knowledge':deepcopy(s.get('modules',{}).get('knowledge',{})),
                                 'evaluation':deepcopy(s.get('modules',{}).get('evaluation',{}))} for s in slots]}
    kb=knowledge.initial_state()
    # Seed identities are stable semantically across the previous UUID copies.
    groups={}
    for source in [*sources,kb]:
        mutations={}
        for event in source.get('events',[]):
            if event.get('action') in {'publish','withdraw'}:
                mutations[event.get('detail',{}).get('document_id')]=event.get('at','')
        for row in source.get('documents',[]):
            key=(row['school_id'],row['title'],row['version']) if row.get('seed_document') else ('custom',row['id'])
            if source is kb and key in groups:continue
            groups.setdefault(key,[]).append((row,mutations.get(row['id'],'')))
    docs=[]; aliases={}
    for rows in groups.values():
        # A confirmed withdrawal cannot be revived by an untouched seed copy.
        chosen=max(rows,key=lambda item:(item[0]['status']=='withdrawn',bool(item[1]),item[1],item[0].get('created_at','')))[0]
        docs.append(deepcopy(chosen))
        for old,_ in rows:
            aliases[old['id']]=chosen['id']; aliases[old['series_id']]=chosen['series_id']
            for a,b in zip(old['chunks'],chosen['chunks']):
                if a['text']==b['text']:aliases[a['chunk_id']]=b['chunk_id']
    def remap(value):
        if isinstance(value,str):return aliases.get(value,value)
        if isinstance(value,list):return [remap(v) for v in value]
        if isinstance(value,dict):return {aliases.get(k,k):remap(v) for k,v in value.items()}
        return value
    kb['documents']=docs
    all_events={}
    pointer_candidates={}
    for source in sources:
        source_docs={d['id']:d for d in source.get('documents',[])}
        for school,version in source.get('current_versions',{}).items():
            evidence=[e for e in source.get('events',[]) if e.get('action')=='publish'
                      and source_docs.get(e.get('detail',{}).get('document_id'),{}).get('school_id')==school
                      and str(e.get('detail',{}).get('version'))==str(version)]
            stamp=max((e.get('at','') for e in evidence),default='')
            pointer_candidates.setdefault(school,[]).append((bool(evidence),stamp,version))
        for row in source.get('events',[]):all_events[row['id']]=remap(row)
    for school,candidates in pointer_candidates.items():
        kb['current_versions'][school]=max(candidates,key=lambda c:(c[0],c[1]))[2]
    kb['events']=sorted(all_events.values(),key=lambda r:r.get('at',''))
    pages={}
    for source in sources:
        for p in source.get('wiki',{}).get('pages',[]):
            key=(p['school_id'],p['version'],p['topic_id'])
            prior=pages.get(key)
            if not prior or (bool(p.get('edited')),p.get('updated_at',''))>(bool(prior.get('edited')),prior.get('updated_at','')):
                pages[key]=deepcopy(p)
    # Keep winning manual pages and their conflict/history records; all discarded
    # alternate revisions are still preserved in the verbatim migration archive.
    page_ids={p['id'] for p in pages.values()}
    kb['wiki']['pages']=[remap(p) for p in pages.values()]
    for p in kb['wiki']['pages']:p['source_hash']=knowledge._source_signature(p['sources'])
    for key in ('raw','conflicts','revisions'):
        merged={}
        for source in sources:
            for row in source.get('wiki',{}).get(key,[]):
                if key!='raw' and row.get('page_id') not in page_ids:continue
                item=remap(row); merged[item.get('id',item.get('document_id'))]=item
        kb['wiki'][key]=list(merged.values())
    schemas=[s.get('wiki',{}).get('schema') for s in sources if s.get('wiki',{}).get('schema')]
    if schemas:kb['wiki']['schema']=deepcopy(max(schemas,key=lambda x:x.get('revision',0)))
    ev=evaluation.initial_state(); gold={}; legacy={}
    for slot in slots:
        old=slot.get('modules',{}).get('evaluation',{})
        for item in old.get('gold',[]):
            item=remap(item)
            key=(item['school_id'],item['version_id'],item['question'],tuple(sorted(item['relevance'])))
            gold[key]=item
        for run in old.get('runs',[]):legacy[run['id']]=deepcopy(run)
    ev['gold']=list(gold.values()); ev['gold_revision']=max([s.get('modules',{}).get('evaluation',{}).get('gold_revision',1) for s in slots])+1
    ev['legacy_runs']=list(legacy.values())
    if not ev['gold']:evaluation.handle({'knowledge':kb,'evaluation':ev},'get')
    state['modules'].update(knowledge=kb,evaluation=ev)
    state['knowledge_views']={rid:remap(slot.get('modules',{}).get('knowledge',{}).get('last_search')) for rid,slot in state.get('persona_states',{}).items()}
    state['knowledge_views'][state.get('persona_id','principal')]=remap(sources[-1].get('last_search'))
    migrate_essay_formal(state)
