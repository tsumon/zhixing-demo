"""Pyodide in-browser bridge for 知行教育 AI 中台 (zero server, zero external LLM)."""
import json
import os

os.environ["ZHIXING_SYNC_TASKS"] = "1"
os.environ["DEMO_DATA_DIR"] = "/tmp/zhixing-demo-data"
os.environ["DEMO_ACCESS_CODE"] = ""

from fastapi import Request  # noqa: E402
from backend.app import create_app  # noqa: E402

_APP = None


async def init_app():
    global _APP
    if _APP is None:
        _APP = create_app(data_dir="/tmp/zhixing-demo-data", access_code="")
        await _APP.startup()
    return _APP


async def handle_request(method: str, full_path: str, headers_json: str = "{}", body_text: str = "") -> str:
    app = await init_app()
    headers = json.loads(headers_json) if headers_json else {}
    body_bytes = body_text.encode("utf-8") if body_text else b""
    req = Request(method, full_path, headers=headers, body=body_bytes)
    resp = await app.handle(req)
    return json.dumps(
        {
            "status": resp.status_code,
            "headers": dict(resp.headers),
            "body": resp.render_body(),
        },
        ensure_ascii=False,
    )
