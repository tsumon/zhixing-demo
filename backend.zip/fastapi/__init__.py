"""Minimal pure-Python FastAPI shim for running backend/app.py inside Pyodide."""
import inspect
import json
import re
from types import SimpleNamespace
from urllib.parse import parse_qsl, urlsplit

from .responses import FileResponse, JSONResponse, _CaseInsensitiveHeaders


class HTTPException(Exception):
    def __init__(self, status_code: int, detail=None, headers=None):
        super().__init__(str(detail))
        self.status_code = int(status_code)
        self.detail = detail
        self.headers = headers or {}


class Request:
    def __init__(self, method: str, full_path: str, headers: dict | None = None, body: bytes = b""):
        parts = urlsplit(full_path)
        self.method = method.upper()
        self.url = SimpleNamespace(path=parts.path, query=parts.query)
        self.query_params = dict(parse_qsl(parts.query))
        self.headers = _CaseInsensitiveHeaders(headers or {})
        self.client = SimpleNamespace(host="browser")
        self._body = body if isinstance(body, (bytes, bytearray)) else str(body).encode("utf-8")

    async def body(self) -> bytes:
        return self._body

    async def json(self):
        if not self._body:
            return {}
        return json.loads(self._body.decode("utf-8"))


def _compile_route(template: str):
    parts = []
    param_names = []
    pos = 0
    for m in re.finditer(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}", template):
        parts.append(re.escape(template[pos : m.start()]))
        name = m.group(1)
        param_names.append(name)
        parts.append(f"(?P<{name}>[^/]+)")
        pos = m.end()
    parts.append(re.escape(template[pos:]))
    return re.compile("^" + "".join(parts) + "$"), param_names


class FastAPI:
    def __init__(self, title="", docs_url=None, redoc_url=None, openapi_url=None, lifespan=None):
        self.title = title
        self.lifespan = lifespan
        self.state = SimpleNamespace()
        self._routes = []
        self._middlewares = []
        self._mounts = []
        self._lifespan_cm = None

    def mount(self, path, app, name=None):
        self._mounts.append((path, app, name))

    def middleware(self, middleware_type: str):
        def decorator(fn):
            self._middlewares.append(fn)
            return fn
        return decorator

    def _add_route(self, method: str, path: str, fn):
        regex, param_names = _compile_route(path)
        sig = inspect.signature(fn)
        self._routes.append((method.upper(), path, regex, param_names, fn, sig))
        return fn

    def get(self, path: str):
        return lambda fn: self._add_route("GET", path, fn)

    def post(self, path: str):
        return lambda fn: self._add_route("POST", path, fn)

    def put(self, path: str):
        return lambda fn: self._add_route("PUT", path, fn)

    def delete(self, path: str):
        return lambda fn: self._add_route("DELETE", path, fn)

    async def startup(self):
        if self.lifespan is not None and self._lifespan_cm is None:
            self._lifespan_cm = self.lifespan(self)
            await self._lifespan_cm.__aenter__()

    async def shutdown(self):
        if self._lifespan_cm is not None:
            await self._lifespan_cm.__aexit__(None, None, None)
            self._lifespan_cm = None

    async def _dispatch_route(self, request: Request):
        path = request.url.path
        matched_other_method = False
        for method, _tpl, regex, _names, fn, sig in self._routes:
            m = regex.match(path)
            if not m:
                continue
            if method != request.method:
                matched_other_method = True
                continue
            path_params = m.groupdict()
            kwargs = {}
            for pname, param in sig.parameters.items():
                if pname in path_params:
                    kwargs[pname] = path_params[pname]
                elif param.annotation is Request or pname == "request":
                    kwargs[pname] = request
                elif param.annotation is dict or pname == "payload":
                    raw = await request.body()
                    if raw:
                        try:
                            data = json.loads(raw.decode("utf-8"))
                        except Exception:
                            return JSONResponse({"detail": "请求 JSON 格式无效。"}, status_code=400)
                        if not isinstance(data, dict):
                            return JSONResponse({"detail": "请求体必须为 JSON 对象。"}, status_code=400)
                        kwargs[pname] = data
                    else:
                        kwargs[pname] = {}
            try:
                res = fn(**kwargs)
                if inspect.isawaitable(res):
                    res = await res
            except HTTPException as exc:
                return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)
            if isinstance(res, (JSONResponse, FileResponse)):
                return res
            return JSONResponse(res, status_code=200)

        if matched_other_method:
            return JSONResponse({"detail": "Method Not Allowed"}, status_code=405)
        return JSONResponse({"detail": "Not Found"}, status_code=404)

    async def handle(self, request: Request):
        async def call_chain(idx, req):
            if idx < len(self._middlewares):
                mw = self._middlewares[idx]
                return await mw(req, lambda r: call_chain(idx + 1, r))
            return await self._dispatch_route(req)

        return await call_chain(0, request)


__all__ = ["FastAPI", "Request", "HTTPException", "JSONResponse", "FileResponse"]
