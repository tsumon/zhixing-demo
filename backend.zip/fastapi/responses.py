"""Minimal pure-Python FastAPI responses shim for Pyodide browser runtime."""
import json
from pathlib import Path


class _CaseInsensitiveHeaders(dict):
    def __init__(self, initial=None):
        super().__init__()
        if initial:
            for k, v in initial.items():
                self[k] = v

    def __setitem__(self, key, value):
        super().__setitem__(str(key).lower(), str(value))

    def __getitem__(self, key):
        return super().__getitem__(str(key).lower())

    def get(self, key, default=None):
        return super().get(str(key).lower(), default)

    def __contains__(self, key):
        return super().__contains__(str(key).lower())


class JSONResponse:
    def __init__(self, content, status_code=200, headers=None):
        self.content = content
        self.status_code = int(status_code)
        self.headers = _CaseInsensitiveHeaders(headers)
        if "content-type" not in self.headers:
            self.headers["content-type"] = "application/json; charset=utf-8"

    def render_body(self) -> str:
        return json.dumps(self.content, ensure_ascii=False)


class FileResponse:
    def __init__(self, path, status_code=200, headers=None):
        self.path = Path(path)
        self.status_code = int(status_code)
        self.headers = _CaseInsensitiveHeaders(headers)

    def render_body(self) -> str:
        return self.path.read_text(encoding="utf-8")
