"""Minimal StaticFiles stub for Pyodide browser runtime."""


class StaticFiles:
    def __init__(self, directory=None, **kwargs):
        self.directory = directory
