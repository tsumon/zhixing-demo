"""Minimal pure-Python StateGraph shim for Pyodide browser runtime."""

END = "__end__"


class _CompiledGraph:
    def __init__(self, nodes, entry, edges, conditional_edges):
        self._nodes = nodes
        self._entry = entry
        self._edges = edges
        self._conditional = conditional_edges

    def invoke(self, state):
        current_state = dict(state)
        node = self._entry
        steps = 0
        while node is not None and node != END:
            steps += 1
            if steps > 128:
                raise RuntimeError("StateGraph exceeded max steps")
            fn = self._nodes[node]
            update = fn(current_state)
            if isinstance(update, dict):
                current_state.update(update)
            if node in self._conditional:
                router, mapping = self._conditional[node]
                branch = router(current_state)
                node = mapping.get(branch, END) if mapping is not None else branch
            else:
                node = self._edges.get(node, END)
        return current_state


class StateGraph:
    def __init__(self, state_schema=None):
        self._schema = state_schema
        self._nodes = {}
        self._entry = None
        self._edges = {}
        self._conditional = {}

    def add_node(self, name, fn):
        self._nodes[name] = fn
        return self

    def set_entry_point(self, name):
        self._entry = name
        return self

    def add_edge(self, src, dst):
        self._edges[src] = dst
        return self

    def add_conditional_edges(self, src, router, mapping=None):
        self._conditional[src] = (router, mapping)
        return self

    def compile(self):
        return _CompiledGraph(
            dict(self._nodes),
            self._entry,
            dict(self._edges),
            dict(self._conditional),
        )
